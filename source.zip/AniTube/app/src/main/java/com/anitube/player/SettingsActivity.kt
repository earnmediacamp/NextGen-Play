package com.anitube.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Settings screen. 3-dot menu > Settings. Home par pages ki list, page par us page ki settings.
 * Har change turant save hota hai (library wapas aate hi onResume me naya value utha leti hai).
 */
class SettingsActivity : Activity() {
    companion object {
        const val PAGE = "page"
        const val P_LIST = "list"
        const val P_AUDIO = "audio"
        const val P_SUB = "subtitle"
        const val P_GENERAL = "general"
        const val P_PLAYER = "player"
        const val P_DECODER = "decoder"
        const val P_SCREEN = "screen"
        const val P_CONTROLS = "controls"
        const val P_NAV = "navigation"
        const val P_PLAYBACK = "playback"
    }

    private val page: String? by lazy { intent.getStringExtra(PAGE) }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun attr(a: Int): Int { val tv = TypedValue(); theme.resolveAttribute(a, tv, true); return tv.data }

    private var themeSig = ""
    private var txt = 0
    private var txt2 = 0
    private var acc = 0
    private lateinit var body: LinearLayout

    override fun onCreate(b: Bundle?) {
        setTheme(if (Themes.light(this)) R.style.Theme_AniTube_Light else R.style.Theme_AniTube)
        Themes.applyAccent(this)
        themeSig = Themes.sig(this)
        super.onCreate(b)
        txt = attr(R.attr.appText); txt2 = attr(R.attr.appText2); acc = attr(R.attr.appAccent)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(28)) }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_back); setColorFilter(txt); setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); setOnClickListener { finish() }
            })
            addView(TextView(context).apply {
                text = pageTitle(); setTextColor(txt); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, 0)
            })
        })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        root.addView(body)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (themeSig != Themes.sig(this)) { recreate(); return }     // ThemeActivity me theme / accent badla
        Updater.resume(this)
        render()
    }

    private fun pageTitle() = when (page) {
        P_LIST -> "List"
        P_AUDIO -> "Audio"
        P_SUB -> "Subtitle"
        P_GENERAL -> "General"
        P_PLAYER -> "Player"
        P_DECODER -> "Decoder"
        P_SCREEN -> "Screen"
        P_CONTROLS -> "Controls"
        P_NAV -> "Navigation"
        P_PLAYBACK -> "Playback"
        else -> "Settings"
    }

    private fun open(p: String) = startActivity(Intent(this, SettingsActivity::class.java).putExtra(PAGE, p))

    // ---------- small UI helpers ----------
    private fun section(t: String) = TextView(this).apply {
        text = t.uppercase(); setTextColor(acc); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(4), dp(18), 0, dp(4))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t; setTextColor(txt2); textSize = 12f; setPadding(dp(4), dp(4), dp(4), dp(8))
    }

    private fun divider() = View(this).apply {
        setBackgroundColor((txt2 and 0xFFFFFF) or 0x22000000)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1))
    }

    private fun texts(title: String, sub: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(context).apply { text = title; setTextColor(txt); textSize = 16f })
        if (!sub.isNullOrEmpty()) addView(TextView(context).apply {
            text = sub; setTextColor(txt2); textSize = 13f; setPadding(0, dp(3), 0, 0)
        })
    }

    private fun ripple(v: View) {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        if (tv.resourceId != 0) v.setBackgroundResource(tv.resourceId)
    }

    /** Tap karne wali row. onClick null ho to sirf info. */
    private fun row(title: String, sub: String?, onClick: (() -> Unit)?): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(13), dp(4), dp(13))
        addView(texts(title, sub).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        if (onClick != null) {
            addView(TextView(context).apply { text = "\u203A"; setTextColor(txt2); textSize = 24f; setPadding(dp(8), 0, dp(4), 0) })
            ripple(this)
            setOnClickListener { onClick() }
        }
    }

    private fun switchRow(title: String, sub: String?, on: Boolean, f: (Boolean) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(10), dp(4), dp(10))
        addView(texts(title, sub).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        val sw = Switch(context)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, c -> f(c) }
        addView(sw)
        ripple(this)
        setOnClickListener { sw.toggle() }
    }

    private fun seekRow(title: String, lo: Int, hi: Int, cur: Int, fmt: (Int) -> String, f: (Int) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(4), dp(12), dp(4), dp(8))
        val label = TextView(context).apply { text = "$title: " + fmt(cur); setTextColor(txt); textSize = 16f }
        addView(label)
        addView(SeekBar(context).apply {
            this.max = hi - lo
            progress = cur - lo
            progressTintList = ColorStateList.valueOf(acc)
            thumbTintList = ColorStateList.valueOf(acc)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: " + fmt(p + lo)
                    if (fromUser) f(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun defSwitch(title: String, sub: String?, d: BoolDef): View =
        switchRow(title, sub, d.get(this)) { d.set(this, it) }

    /** Index based choice (0..n-1) ko IntDef me save karta hai. */
    private fun choiceRow(title: String, d: IntDef, labels: List<String>): View {
        val cur = d.get(this).coerceIn(0, labels.size - 1)
        return row(title, labels[cur]) { pick(title, labels, cur) { w -> d.set(this, w); render() } }
    }

    private fun colorRow(title: String, d: IntDef): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(13), dp(4), dp(13))
        addView(texts(title, null).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        addView(View(context).apply {
            background = GradientDrawable().apply { setColor(d.get(this@SettingsActivity)); cornerRadius = dp(6).toFloat(); setStroke(dp(1), 0x88888888.toInt()) }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(26))
        })
        ripple(this)
        setOnClickListener { colorDialog(d) }
    }

    private fun colorDialog(d: IntDef) {
        val palette = longArrayOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFFFFC107, 0xFFFF9800, 0xFFFF5252, 0xFFFF4081,
            0xFFE040FB, 0xFF7C4DFF, 0xFF448AFF, 0xFF40C4FF, 0xFF18FFFF, 0xFF69F0AE,
            0xFF76FF03, 0xFF22FF22, 0xFFBDBDBD, 0xFF616161, 0xFF212121, 0xFF000000).map { it.toInt() }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(6)) }
        var dialog: AlertDialog? = null
        palette.chunked(6).forEach { r ->
            grid.addView(LinearLayout(this).apply {
                r.forEach { c ->
                    addView(View(context).apply {
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(1), 0x88888888.toInt()) }
                        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
                        setOnClickListener { d.set(this@SettingsActivity, c); dialog?.dismiss(); render() }
                    })
                }
            })
        }
        val dlg = AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Colour").setView(grid)
            .setNegativeButton("Cancel", null).create()
        dialog = dlg
        dlg.show()
    }

    private fun pick(title: String, items: List<String>, cur: Int, f: (Int) -> Unit) {
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle(title)
            .setSingleChoiceItems(items.toTypedArray(), cur) { d, w -> f(w); d.dismiss() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun langPick(title: String, cur: String?, f: (String?) -> Unit) {
        val items = listOf("Auto (last chosen)") + AppSettings.LANGS.map { it.second }
        val idx = if (cur == null) 0 else AppSettings.LANGS.indexOfFirst { it.first == cur }.let { if (it < 0) -1 else it + 1 }
        pick(title, items, idx) { w -> f(if (w == 0) null else AppSettings.LANGS[w - 1].first) }
    }

    // ---------- pages ----------
    private fun render() {
        body.removeAllViews()
        when (page) {
            P_LIST -> listPage()
            P_AUDIO -> audioPage()
            P_SUB -> subPage()
            P_GENERAL -> generalPage()
            P_PLAYER -> playerPage()
            P_DECODER -> decoderPage()
            P_SCREEN -> screenPage()
            P_CONTROLS -> controlsPage()
            P_NAV -> navPage()
            P_PLAYBACK -> playbackPage()
            else -> homePage()
        }
    }

    private fun homePage() {
        body.addView(row("List", "View mode, layout, sort, fields, Continue Watching, NEW badge") { open(P_LIST) })
        body.addView(divider())
        body.addView(row("Player", "Screen, controls, navigation, playback") { open(P_PLAYER) })
        body.addView(divider())
        body.addView(row("Decoder", "HW, HW+ or SW, fallback, audio offset") { open(P_DECODER) })
        body.addView(divider())
        body.addView(row("Audio", "Equalizer, volume boost, audio language, audio delay") { open(P_AUDIO) })
        body.addView(divider())
        body.addView(row("Subtitle", "Style, layout, encoding, sync, language") { open(P_SUB) })
        body.addView(divider())
        body.addView(row("General", "Theme, hidden folders, updates, reset") { open(P_GENERAL) })
    }

    private fun listPage() {
        val modes = listOf("All folders", "Files", "Folders")
        val grid = Lib.sp(this).getBoolean("grid", false)
        body.addView(section("Library"))
        body.addView(row("View mode, layout, sort and fields",
            modes[Lib.vmode(this)] + "  \u00B7  " + (if (grid) "Grid" else "List") + "  \u00B7  " + Lib.sortLabel(this)) {
            LibraryMenu.show(this, Themes.dialog(this), txt, txt2, acc, grid) { render() }
        })
        body.addView(divider())
        body.addView(switchRow("Continue Watching row", "Show the row at the top of the library", AppSettings.CONT_RECENT.get(this)) {
            AppSettings.CONT_RECENT.set(this, it)
        })
        body.addView(divider())
        val days = listOf(1, 2, 3, 5, 7, 14, 30)
        val cur = AppSettings.NEW_DAYS.get(this)
        body.addView(row("NEW badge duration", "Videos you have not started show NEW for " + cur + (if (cur == 1) " day" else " days")) {
            pick("NEW badge duration", days.map { if (it == 1) "1 day" else "$it days" }, days.indexOf(cur)) { w ->
                AppSettings.NEW_DAYS.set(this, days[w]); render()
            }
        })
    }

    private fun audioPage() {
        body.addView(section("Defaults"))
        body.addView(switchRow("Equalizer on", "Applies to every video. Band levels are set in the player's Equalizer panel.", AppSettings.EQ_ON.get(this)) {
            AppSettings.EQ_ON.set(this, it)
        })
        body.addView(divider())
        body.addView(seekRow("Volume boost", 0, 15, AppSettings.BOOST_DB.get(this), { "$it dB" }) { AppSettings.BOOST_DB.set(this, it) })
        body.addView(note("High boost can distort sound and hurt your ears on earphones. Raise it slowly."))
        body.addView(divider())
        body.addView(row("Reset equalizer bands to flat", null) {
            AppSettings.resetEq(this)
            Toast.makeText(this, "Equalizer bands reset", Toast.LENGTH_SHORT).show()
        })
        body.addView(section("Language"))
        val cur = AppSettings.PREF_AUDIO_LANG.get(this)
        body.addView(row("Preferred audio language", AppSettings.langLabel(cur)) {
            langPick("Preferred audio language", cur) { AppSettings.PREF_AUDIO_LANG.set(this, it); render() }
        })
        body.addView(note("Picking an audio track inside the player also updates this."))
        body.addView(section("Sync"))
        body.addView(switchRow("Remember audio delay per video", "Off: audio delay resets when the player closes", AppSettings.REM_ADELAY.get(this)) {
            AppSettings.REM_ADELAY.set(this, it)
        })
        body.addView(note("Changes apply the next time you open a video."))
    }

    private fun subPage() {
        body.addView(section("Display"))
        body.addView(switchRow("Show subtitles", "Default for every video", AppSettings.SHOW_SUBS.get(this)) {
            AppSettings.SHOW_SUBS.set(this, it)
        })
        body.addView(divider())
        body.addView(switchRow("Animated ASS", "Karaoke and moving text. Uses more battery.", AppSettings.ASS_ANIM.get(this)) {
            AppSettings.ASS_ANIM.set(this, it)
        })
        body.addView(section("Text"))
        body.addView(seekRow("Size", 10, 60, AppSettings.SUB_SIZE.get(this), { "$it" }) { AppSettings.SUB_SIZE.set(this, it) })
        body.addView(colorRow("Colour", AppSettings.SUB_COLOR))
        body.addView(divider())
        body.addView(defSwitch("Bold", null, AppSettings.SUB_BOLD))
        body.addView(divider())
        body.addView(defSwitch("Border", "Outline around the text", AppSettings.SUB_BORDER))
        body.addView(divider())
        body.addView(defSwitch("Background", "Dark box behind the text", AppSettings.SUB_BG))
        body.addView(section("Layout"))
        body.addView(choiceRow("Alignment", AppSettings.SUB_ALIGN, listOf("Left", "Center", "Right")))
        body.addView(seekRow("Bottom margin", 0, 40, AppSettings.SUB_POS.get(this), { "$it" }) { AppSettings.SUB_POS.set(this, it) })
        body.addView(defSwitch("Fit subtitles into video size", null, AppSettings.SUB_FIT))
        body.addView(note("Font, font folder and the live preview are in the player's subtitle panel. ASS/SSA subtitles use their own style, so these apply to SRT/VTT."))
        body.addView(section("Timing and encoding"))
        val enc = AppSettings.SUB_ENC.get(this)
        val encItems = listOf("Auto") + AppSettings.ENCODINGS
        body.addView(row("Character encoding", enc ?: "Auto (UTF-8, else Windows-1252)") {
            pick("Character encoding", encItems, if (enc == null) 0 else encItems.indexOf(enc)) { w ->
                AppSettings.SUB_ENC.set(this, if (w == 0) null else encItems[w]); render()
            }
        })
        body.addView(note("Used when you add a subtitle file. Pick the right one if the letters look broken."))
        body.addView(seekRow("Default sync (delay)", -100, 100, AppSettings.SUB_SYNC.get(this),
            { String.format(java.util.Locale.US, "%+.1f s", it / 10.0) }) { AppSettings.SUB_SYNC.set(this, it) })
        body.addView(note("Applied to every video's added subtitle. Embedded tracks only support a positive delay."))
        body.addView(section("Effects"))
        body.addView(defSwitch("Italic effect", "A line starting with / is shown in italic", AppSettings.SUB_ITALIC))
        body.addView(divider())
        body.addView(defSwitch("Force LTR for RTL subtitles", "Arabic, Urdu: keeps punctuation on the correct side", AppSettings.SUB_LTR))
        body.addView(section("Language"))
        val cur = AppSettings.PREF_SUB_LANG.get(this)
        body.addView(row("Preferred subtitle language", AppSettings.langLabel(cur)) {
            langPick("Preferred subtitle language", cur) { AppSettings.PREF_SUB_LANG.set(this, it); render() }
        })
        body.addView(note("Picking a subtitle track inside the player also updates this. Changes apply the next time you open a video."))
    }

    private fun decoderPage() {
        val names = AppSettings.DEC_NAMES
        body.addView(section("Default decoder"))
        val loc = AppSettings.decMode(this, false)
        body.addView(row("Local files", names[loc]) {
            pick("Local files", names, loc) { w -> AppSettings.DEC_LOCAL.set(this, w); render() }
        })
        body.addView(divider())
        val net = AppSettings.decMode(this, true)
        body.addView(row("Network streams", names[net]) {
            pick("Network streams", names, net) { w -> AppSettings.DEC_NET.set(this, w); render() }
        })
        body.addView(note("HW: phone's hardware decoders (FFmpeg audio only if the phone has no decoder for it).\nHW+: hardware video, FFmpeg audio preferred (AC3, EAC3, DTS, TrueHD, FLAC...).\nSW: software video decoders. Slower, but works when hardware fails.\nThe HW / HW+ / SW button in the player changes the default for that kind of file."))
        body.addView(section("When a decoder fails"))
        body.addView(defSwitch("Try HW+ if HW fails", null, AppSettings.TRY_HWPLUS))
        body.addView(divider())
        body.addView(defSwitch("Try HW if HW+ fails", null, AppSettings.TRY_HW))
        body.addView(note("SW is always the last step. A toast says \"Try next decoder\" each time it switches. The switch lasts for the current playback only."))
        body.addView(section("Software"))
        body.addView(defSwitch("Software audio in SW mode", "Off: only video uses software decoders", AppSettings.SW_AUDIO))
        body.addView(section("Sync"))
        body.addView(seekRow("Calibrate playback position", -100, 100, AppSettings.AUDIO_CAL.get(this),
            { String.format(java.util.Locale.US, "%+.1f s", it / 10.0) }) { AppSettings.AUDIO_CAL.set(this, it) })
        body.addView(note("Audio offset applied to every video, for phones or earphones that lag. A delay you set in the player for one video overrides it."))
        body.addView(note("Applies the next time you open a video."))
    }

    private fun playerPage() {
        body.addView(row("Screen", "Orientation, interface at start, battery and clock") { open(P_SCREEN) })
        body.addView(divider())
        body.addView(row("Controls", "Touch action, lock mode, gestures, shortcuts, auto-hide") { open(P_CONTROLS) })
        body.addView(divider())
        body.addView(row("Navigation", "Swipe seek speed, skip buttons, target position") { open(P_NAV) })
        body.addView(divider())
        body.addView(row("Playback", "Resume, default speed, back button") { open(P_PLAYBACK) })
    }

    private fun screenPage() {
        body.addView(choiceRow("Orientation", AppSettings.ORIENT, listOf("Follow video", "Auto (sensor)", "Landscape", "Portrait")))
        body.addView(divider())
        body.addView(defSwitch("Show interface at start", "Off: controls stay hidden until you tap", AppSettings.SHOW_UI_START))
        body.addView(divider())
        body.addView(defSwitch("Battery and clock", "Small overlay at the top of the video", AppSettings.CLOCK))
        body.addView(note("The screen already stays on while a video plays. Changes apply the next time you open a video."))
    }

    private fun controlsPage() {
        body.addView(section("Touch"))
        body.addView(choiceRow("Touch action", AppSettings.TAP_ACTION, listOf("Show / hide interface", "Play / pause")))
        body.addView(divider())
        body.addView(choiceRow("Lock mode", AppSettings.LOCK_MODE, listOf("Block everything", "Block buttons, allow volume and brightness swipes")))
        body.addView(section("Gestures"))
        body.addView(defSwitch("Swipe to seek", "Horizontal swipe", AppSettings.G_SEEK))
        body.addView(divider())
        body.addView(defSwitch("Pinch to zoom", null, AppSettings.G_PINCH))
        body.addView(divider())
        body.addView(defSwitch("Volume swipe", "Right half, vertical", AppSettings.G_VOL))
        body.addView(divider())
        body.addView(defSwitch("Brightness swipe", "Left half, vertical", AppSettings.G_BRI))
        body.addView(divider())
        body.addView(defSwitch("Double-tap to play / pause", "Middle of the screen", AppSettings.G_DT_PLAY))
        body.addView(divider())
        body.addView(defSwitch("Double-tap to fast forward / rewind", "Left and right sides", AppSettings.G_DT_SEEK))
        body.addView(divider())
        body.addView(defSwitch("Long press for 2x speed", null, AppSettings.G_LONG))
        body.addView(section("Quick shortcuts"))
        body.addView(defSwitch("Mute", null, AppSettings.SC_MUTE))
        body.addView(defSwitch("Sleep timer", null, AppSettings.SC_SLEEP))
        body.addView(defSwitch("Night mode", null, AppSettings.SC_NIGHT))
        body.addView(defSwitch("Frame back / forward", null, AppSettings.SC_FRAME))
        body.addView(defSwitch("Rotate", "Button at the bottom right", AppSettings.SC_ROTATE))
        body.addView(defSwitch("Picture in picture", "Button at the bottom right", AppSettings.SC_PIP))
        body.addView(defSwitch("Playback speed", null, AppSettings.SC_SPEED))
        body.addView(defSwitch("Screenshot", null, AppSettings.SC_SHOT))
        body.addView(defSwitch("Equalizer", null, AppSettings.SC_EQ))
        body.addView(defSwitch("Mirror (horizontal flip)", null, AppSettings.SC_MIRROR))
        body.addView(defSwitch("Vertical flip", null, AppSettings.SC_VFLIP))
        body.addView(note("Loop, shuffle and A-B repeat stay in the player's Playback panel."))
        body.addView(section("Interface"))
        body.addView(seekRow("Auto-hide controls after", 1, 10, AppSettings.AUTOHIDE.get(this), { "$it s" }) { AppSettings.AUTOHIDE.set(this, it) })
        body.addView(defSwitch("Smooth fade", "Seekbar and all buttons fade in and out together", AppSettings.UI_ANIM))
        body.addView(note("Applies the next time you open a video."))
    }

    private fun navPage() {
        body.addView(seekRow("Swipe seek speed", 2, 60, AppSettings.SEEK_SPCM.get(this), { "$it s per cm" }) { AppSettings.SEEK_SPCM.set(this, it) })
        body.addView(divider())
        body.addView(seekRow("Skip button interval", 5, 180, AppSettings.SKIP_S.get(this), { "$it s" }) { AppSettings.SKIP_S.set(this, it) })
        body.addView(defSwitch("Backward skip button", "Shows a button that jumps back by the same interval", AppSettings.BACK_BTN))
        body.addView(divider())
        body.addView(defSwitch("Previous / next buttons", null, AppSettings.PREV_NEXT))
        body.addView(divider())
        body.addView(defSwitch("Show target position while seeking", null, AppSettings.SHOW_TARGET))
    }

    private fun playbackPage() {
        body.addView(choiceRow("Resume", AppSettings.RESUME, listOf("Always resume", "Ask every time", "Never (start from the beginning)")))
        body.addView(divider())
        val sp = listOf(50, 75, 100, 125, 150, 200)
        val cur = AppSettings.DEF_SPEED.get(this)
        body.addView(row("Default playback speed", (cur / 100.0).toString().removeSuffix(".0") + "x") {
            pick("Default playback speed", sp.map { (it / 100.0).toString().removeSuffix(".0") + "x" }, sp.indexOf(cur)) { w ->
                AppSettings.DEF_SPEED.set(this, sp[w]); render()
            }
        })
        body.addView(note("Videos where you picked a speed yourself keep that speed."))
        body.addView(switchRow("Background play", "Keep playing the audio when you leave the app, with notification controls. Picture in picture is skipped when this is on.",
            AppSettings.BG_PLAY.get(this)) {
            AppSettings.BG_PLAY.set(this, it)
            if (it && android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)      // notification dikhane ke liye
        })
        body.addView(divider())
        body.addView(defSwitch("Double-tap back to close the player", "First back press shows a hint", AppSettings.DBL_BACK))
        body.addView(note("Only the first video of a queue resumes from its saved position."))
    }

    private fun generalPage() {
        val themeNames = listOf("Dark", "Light", "Follow system")
        body.addView(section("Appearance"))
        body.addView(row("Theme and accent colour", themeNames[AppSettings.sp(this).getInt("theme", 0).coerceIn(0, 2)]) {
            startActivity(Intent(this, ThemeActivity::class.java))
        })

        body.addView(section("Library"))
        val hidCount = (AppSettings.sp(this).getStringSet("hid", null) ?: emptySet<String>()).size
        body.addView(row("Hidden folders", if (hidCount == 0) "None hidden" else "$hidCount hidden. Tap to unhide.") { hiddenDialog() })

        body.addView(section("App"))
        body.addView(row("Check for updates", "Current version: v" + Updater.curName(this)) { Updater.check(this, true) })
        body.addView(divider())
        body.addView(row("Reset all settings to default", "Favourites, hidden folders and watch history are kept.") { resetDialog() })
    }

    private fun hiddenDialog() {
        val names = (AppSettings.sp(this).getStringSet("hid", null) ?: emptySet<String>()).sorted().toTypedArray()
        if (names.isEmpty()) { Toast.makeText(this, "No hidden folders", Toast.LENGTH_SHORT).show(); return }
        val checked = BooleanArray(names.size) { true }
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Hidden folders (untick to unhide)")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val keep = HashSet<String>()
                names.forEachIndexed { i, n -> if (checked[i]) keep.add(n) }
                AppSettings.sp(this).edit().putStringSet("hid", keep).apply()
                render()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun resetDialog() {
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Reset all settings?")
            .setMessage("Every setting goes back to its default. Favourites, hidden folders and watch history are not touched.")
            .setPositiveButton("Reset") { _, _ ->
                AppSettings.resetAll(this)
                Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
                recreate()
            }
            .setNegativeButton("Cancel", null).show()
    }
}
