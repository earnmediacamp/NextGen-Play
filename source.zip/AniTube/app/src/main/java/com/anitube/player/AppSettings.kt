package com.anitube.player

import android.content.Context

/** Ek setting = ek key + default + type. Library, player aur SettingsActivity sab yahin se padhte hain (prefs file "set"). */
class BoolDef(val key: String, val def: Boolean) {
    fun get(c: Context): Boolean = AppSettings.sp(c).getBoolean(key, def)
    fun set(c: Context, v: Boolean) { AppSettings.sp(c).edit().putBoolean(key, v).apply() }
}

class IntDef(val key: String, val def: Int, val min: Int, val max: Int) {
    fun get(c: Context): Int = AppSettings.sp(c).getInt(key, def).coerceIn(min, max)
    fun set(c: Context, v: Int) { AppSettings.sp(c).edit().putInt(key, v.coerceIn(min, max)).apply() }
}

/** null = set nahi (Auto). */
class StrDef(val key: String) {
    fun get(c: Context): String? = AppSettings.sp(c).getString(key, null)
    fun set(c: Context, v: String?) {
        val e = AppSettings.sp(c).edit()
        if (v == null) e.remove(key) else e.putString(key, v)
        e.apply()
    }
}

object AppSettings {
    const val FILE = "set"
    fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- List / library ----
    val CONT_RECENT = BoolDef("c_recent", true)          // Continue Watching row
    val NEW_DAYS = IntDef("newDays", 3, 1, 30)           // NEW badge kitne din

    // ---- Audio ----
    val EQ_ON = BoolDef("eqon", false)
    val BOOST_DB = IntDef("vb", 0, 0, 15)
    val PREF_AUDIO_LANG = StrDef("pal")
    val REM_ADELAY = BoolDef("rem_adelay", false)        // audio delay har video ke liye yaad rakho

    // ---- Subtitle ----
    val SHOW_SUBS = BoolDef("son", true)
    val ASS_ANIM = BoolDef("ass_anim", false)
    val PREF_SUB_LANG = StrDef("ptl")

    // ---- Player > Screen ----
    val ORIENT = IntDef("scr_orient", 0, 0, 3)           // 0 follow video, 1 auto, 2 landscape, 3 portrait
    val SHOW_UI_START = BoolDef("scr_showui", true)
    val CLOCK = BoolDef("scr_clock", false)              // battery + clock overlay

    // ---- Player > Controls ----
    val TAP_ACTION = IntDef("g_tap", 0, 0, 1)            // 0 interface show/hide, 1 play/pause
    val LOCK_MODE = IntDef("lock_mode", 0, 0, 1)         // 0 sab block, 1 volume / brightness swipe chalega
    val G_SEEK = BoolDef("g_seek", true)
    val G_PINCH = BoolDef("g_pinch", true)
    val G_VOL = BoolDef("g_vol", true)
    val G_BRI = BoolDef("g_bri", true)
    val G_DT_PLAY = BoolDef("g_dtpp", true)
    val G_DT_SEEK = BoolDef("g_dtff", true)
    val G_LONG = BoolDef("g_lp", true)
    val AUTOHIDE = IntDef("ui_hide", 3, 1, 10)           // seconds
    val UI_ANIM = BoolDef("ui_anim", true)               // controls ek saath smooth fade
    val SC_MUTE = BoolDef("sc_mute", true)
    val SC_SLEEP = BoolDef("sc_sleep", true)
    val SC_NIGHT = BoolDef("sc_night", true)
    val SC_FRAME = BoolDef("sc_frame", true)
    val SC_ROTATE = BoolDef("sc_rot", true)
    val SC_PIP = BoolDef("sc_pip", true)
    val SC_SPEED = BoolDef("sc_speed", false)
    val SC_SHOT = BoolDef("sc_shot", false)
    val SC_EQ = BoolDef("sc_eq", false)
    val SC_MIRROR = BoolDef("sc_mirror", false)
    val SC_VFLIP = BoolDef("sc_vflip", false)

    // ---- Player > Navigation ----
    val SEEK_SPCM = IntDef("nav_sps", 12, 2, 60)         // swipe seek: seconds per cm
    val SKIP_S = IntDef("skipS", 85, 5, 180)             // forward / backward button interval
    val BACK_BTN = BoolDef("nav_back", false)
    val PREV_NEXT = BoolDef("nav_pn", true)
    val SHOW_TARGET = BoolDef("nav_tgt", true)

    // ---- Player > Playback ----
    val RESUME = IntDef("pb_resume", 0, 0, 2)            // 0 always, 1 ask, 2 never
    val DEF_SPEED = IntDef("pb_speed", 100, 50, 200)     // percent
    val DBL_BACK = BoolDef("pb_dbl", false)
    val BG_PLAY = BoolDef("bg_play", false)              // app se bahar jaane par audio chalta rahe

    // ---- Subtitle text / layout (same keys the player already uses) ----
    val SUB_SIZE = IntDef("ss", 20, 10, 60)
    val SUB_POS = IntDef("spos", 8, 0, 40)
    val SUB_ALIGN = IntDef("salign", 1, 0, 2)
    val SUB_BOLD = BoolDef("sbold", false)
    val SUB_BORDER = BoolDef("sbd", true)
    val SUB_BG = BoolDef("sb", false)
    val SUB_FIT = BoolDef("sfit", true)
    val SUB_COLOR = IntDef("sc", 0xFFFFFFFF.toInt(), Int.MIN_VALUE, Int.MAX_VALUE)
    // ---- Subtitle new ----
    val SUB_ENC = StrDef("sub_enc")                      // null = auto (UTF-8, warna Windows-1252)
    val SUB_SYNC = IntDef("sub_sync", 0, -100, 100)      // default delay, 0.1 s units
    val SUB_ITALIC = BoolDef("sub_ital", false)          // "/" se shuru hone wali line italic
    val SUB_LTR = BoolDef("sub_ltr", false)              // RTL subtitle ko LTR me dikhao

    // ---- Decoder (0 = HW, 1 = HW+, 2 = SW) ----
    val DEC_LOCAL = IntDef("dec_local", -1, -1, 2)       // -1 = set nahi: purana "sw" toggle dekho
    val DEC_NET = IntDef("dec_net", -1, -1, 2)
    val TRY_HWPLUS = BoolDef("dec_try_plus", true)       // HW fail -> HW+ try karo
    val TRY_HW = BoolDef("dec_try_hw", true)             // HW+ fail -> HW try karo
    val SW_AUDIO = BoolDef("dec_sw_audio", true)         // SW mode me audio bhi software decoder se
    val AUDIO_CAL = IntDef("dec_cal", 0, -100, 100)      // Calibrate playback position = default audio offset, 0.1 s units
    val DEC_NAMES = listOf("HW", "HW+", "SW")

    fun decMode(c: Context, net: Boolean): Int {
        val v = (if (net) DEC_NET else DEC_LOCAL).get(c)
        return if (v in 0..2) v else if (sp(c).getBoolean("sw", false)) 2 else 0
    }

    val ENCODINGS = listOf("UTF-8", "Windows-1252", "UTF-16", "ISO-8859-1", "Windows-1250", "Windows-1251", "Windows-1253",
        "Windows-1254", "Windows-1255", "Windows-1256", "Windows-1257", "Windows-1258", "GBK", "Big5", "Shift_JIS", "EUC-KR", "TIS-620")

    /** Equalizer bands "eqb0".."eqbN" (N phone par depend karta hai). */
    private const val EQ_BAND_MAX = 32

    /** Library menu + theme ki keys (Lib / Themes inhe padhte hain). Reset me ye bhi aati hain. */
    private val OTHER_KEYS = listOf("theme", "acc", "vmode", "grid", "vsort", "vdesc",
        "ssc", "sop", "sec", "sbc", "swc", "swon", "sw") + Lib.FIELDS.map { it.second }

    private val DEFS: List<Any> get() = listOf(CONT_RECENT, NEW_DAYS, EQ_ON, BOOST_DB, PREF_AUDIO_LANG, REM_ADELAY,
        SHOW_SUBS, ASS_ANIM, PREF_SUB_LANG,
        ORIENT, SHOW_UI_START, CLOCK,
        TAP_ACTION, LOCK_MODE, UI_ANIM, G_SEEK, G_PINCH, G_VOL, G_BRI, G_DT_PLAY, G_DT_SEEK, G_LONG, AUTOHIDE,
        SC_MUTE, SC_SLEEP, SC_NIGHT, SC_FRAME, SC_ROTATE, SC_PIP, SC_SPEED, SC_SHOT, SC_EQ, SC_MIRROR, SC_VFLIP,
        SEEK_SPCM, SKIP_S, BACK_BTN, PREV_NEXT, SHOW_TARGET,
        RESUME, DEF_SPEED, DBL_BACK, BG_PLAY,
        SUB_SIZE, SUB_POS, SUB_ALIGN, SUB_BOLD, SUB_BORDER, SUB_BG, SUB_FIT, SUB_COLOR,
        SUB_ENC, SUB_SYNC, SUB_ITALIC, SUB_LTR,
        DEC_LOCAL, DEC_NET, TRY_HWPLUS, TRY_HW, SW_AUDIO, AUDIO_CAL)

    fun resetEq(c: Context) {
        val e = sp(c).edit()
        for (i in 0 until EQ_BAND_MAX) e.remove("eqb$i")
        e.apply()
    }

    /** Sirf settings default par aati hain. Favourites, hidden folders, history, added subtitles ko haath nahi lagta. */
    fun resetAll(c: Context) {
        val e = sp(c).edit()
        DEFS.forEach {
            when (it) {
                is BoolDef -> e.remove(it.key)
                is IntDef -> e.remove(it.key)
                is StrDef -> e.remove(it.key)
                else -> e
            }
        }
        OTHER_KEYS.forEach { e.remove(it) }
        for (i in 0 until EQ_BAND_MAX) e.remove("eqb$i")
        e.apply()
    }

    /** Language picker list: BCP-47 code to naam. */
    val LANGS = listOf(
        "ja" to "Japanese", "en" to "English", "hi" to "Hindi", "ko" to "Korean", "zh" to "Chinese",
        "es" to "Spanish", "fr" to "French", "de" to "German", "pt" to "Portuguese", "ru" to "Russian",
        "ar" to "Arabic", "id" to "Indonesian", "th" to "Thai", "vi" to "Vietnamese", "ta" to "Tamil",
        "te" to "Telugu", "ur" to "Urdu", "it" to "Italian", "tr" to "Turkish"
    )

    fun langLabel(code: String?): String =
        if (code == null) "Auto (last chosen)" else (LANGS.firstOrNull { it.first == code }?.second ?: code)
}
