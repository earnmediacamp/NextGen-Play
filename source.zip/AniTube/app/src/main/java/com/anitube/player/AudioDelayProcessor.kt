package com.anitube.player

import android.content.Context
import android.os.Handler
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.video.VideoRendererEventListener
import java.util.ArrayList
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import java.nio.ByteBuffer

/**
 * Audio delay (MX Player jaisa).
 *  delayMs > 0  -> awaaz video se LATE aayegi (silence daalte hain)
 *  delayMs < 0  -> awaaz video se PEHLE aayegi (audio ke frames skip karte hain)
 * Sirf 16-bit PCM par chalta hai (almost sab decoded audio yahi hota hai);
 * passthrough (AC3/DTS direct) par kaam nahi karega.
 */
@OptIn(UnstableApi::class)
class AudioDelayProcessor : BaseAudioProcessor() {

    @Volatile
    var delayMs: Long = 0

    private var applied = 0L      // ab tak apply hue frames
    private var pending = 0L      // >0: silence frames daalne hain, <0: frames drop karne hain
    private var frameSize = 4
    private var rate = 48000

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat =
        if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT) inputAudioFormat
        else AudioProcessor.AudioFormat.NOT_SET

    override fun onFlush() {
        // seek / naya stream: delay dobara shuru se lagega
        applied = 0
        pending = 0
        frameSize = inputAudioFormat.bytesPerFrame
        rate = inputAudioFormat.sampleRate
    }

    override fun onReset() {
        applied = 0
        pending = 0
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val target = delayMs * rate / 1000
        pending += target - applied
        applied = target

        var silence = 0
        if (pending > 0) {
            silence = (pending * frameSize).coerceAtMost(8_000_000L).toInt()
            silence -= silence % frameSize
            pending -= silence / frameSize
        } else if (pending < 0) {
            val frames = minOf(-pending, (inputBuffer.remaining() / frameSize).toLong())
            inputBuffer.position(inputBuffer.position() + (frames * frameSize).toInt())
            pending += frames
        }

        val out = replaceOutputBuffer(silence + inputBuffer.remaining())
        if (silence > 0) out.put(ByteArray(silence))
        out.put(inputBuffer)
        out.flip()
    }
}

/** NextRenderersFactory (= DefaultRenderersFactory + ffmpeg decoders) jisme audio sink ke andar AudioDelayProcessor laga hai. */
@OptIn(UnstableApi::class)
class DelayRenderersFactory(ctx: Context, private val proc: AudioDelayProcessor?) : NextRenderersFactory(ctx) {
    // ON = pehle phone ka apna decoder, na mile to ffmpeg
    init { setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON) }

    /**
     * HW+ = EXTENSION_RENDERER_MODE_PREFER sirf AUDIO ke liye chahiye. NextLib video ke liye bhi FFmpeg renderer jodta hai,
     * aur PREFER me wo phone ke hardware video decoder se pehle aa jata (software video, slow). Isliye video ke liye PREFER ko ON bana dete hain:
     * video hamesha pehle hardware, FFmpeg sirf tab jab hardware decoder na ho.
     */
    override fun buildVideoRenderers(
        context: Context,
        extensionRendererMode: Int,
        mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean,
        eventHandler: Handler,
        eventListener: VideoRendererEventListener,
        allowedVideoJoiningTimeMs: Long,
        out: ArrayList<Renderer>
    ) {
        val m = if (extensionRendererMode == DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON else extensionRendererMode
        super.buildVideoRenderers(context, m, mediaCodecSelector, enableDecoderFallback, eventHandler, eventListener, allowedVideoJoiningTimeMs, out)
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink? = if (proc == null) super.buildAudioSink(context, enableFloatOutput, enableAudioTrackPlaybackParams)
    else DefaultAudioSink.Builder(context)
        .setEnableFloatOutput(enableFloatOutput)
        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
        .setAudioProcessors(arrayOf<AudioProcessor>(proc))
        .build()
}
