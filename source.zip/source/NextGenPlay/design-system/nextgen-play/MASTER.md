# NextGen Play design system v2 ("Cinematic ink")

Source of truth for visual decisions. Tokens live in `res/values/colors.xml`, `dimens.xml`, `themes.xml` and the shape drawables.

- **Style:** dark-first, tonal surfaces, one electric-blue accent (#32A8FF), glass only over video.
- **Rhythm:** 4/8dp. Screen gutter 16dp (10dp grid padding + 6dp item padding). Card gap 8dp. Section gap 12-16dp.
- **Radius:** thumb 16, card 20, chip/pill 22-24, sheet 28.
- **Targets:** every tappable control >= 48dp (secondary chips >= 40dp).
- **Type:** Poppins. Title 30/17 bold, body 15, meta 12, caption 11. Secondary text >= 4.5:1.
- **Surfaces:** bg #070B12, surface #111A28, surface2 #192539, hairline #1FFFFFFF. Light theme mirrors with l_* tokens.
- **Controls over video:** translucent black #66000000 + 1dp white hairline; pressed = accent ring; selected = accent tint.
- **Hero action:** play button 80dp accent gradient with soft ring. Transport prev/next 56dp.
- **Icons:** vector only, no emoji. Pin uses `ic_pin`. Play triangle forced to text style.
- **Motion:** 150-250ms ease, panels slide from right, never block input.
