package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Settings screen. 3-dot menu > Settings. Home par pages ki list, page par us page ki settings.
 * Har change turant save hota hai (library wapas aate hi onResume me naya value utha leti hai).
 */
class SettingsActivity : Activity() {
    companion object {
        const val PAGE = "page"
        const val P_LIST = "list"
        const val P_AUDIO = "audio"
        const val P_SUB = "subtitle"
        const val P_GENERAL = "general"
        const val P_PLAYER = "player"
        const val P_DECODER = "decoder"
        const val P_PRIVACY = "privacy"
        const val P_DEV = "development"
        private const val REQ_EXPORT = 71
        private const val REQ_IMPORT = 72
        const val P_SCREEN = "screen"
        const val P_CONTROLS = "controls"
        const val P_NAV = "navigation"
        const val P_PLAYBACK = "playback"
    }

    private val page: String? by lazy { intent.getStringExtra(PAGE) }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun attr(a: Int): Int { val tv = TypedValue(); theme.resolveAttribute(a, tv, true); return tv.data }

    private var themeSig = ""
    private var txt = 0
    private var txt2 = 0
    private var acc = 0
    private lateinit var body: LinearLayout

    override fun onCreate(b: Bundle?) {
        setTheme(if (Themes.light(this)) R.style.Theme_NextGenPlay_Light else R.style.Theme_NextGenPlay)
        Themes.applyAccent(this)
        themeSig = Themes.sig(this)
        super.onCreate(b)
        txt = attr(R.attr.appText); txt2 = attr(R.attr.appText2); acc = attr(R.attr.appAccent)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(28)) }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_back); setColorFilter(txt); setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); setOnClickListener { finish() }
            })
            addView(TextView(context).apply {
                text = pageTitle(); setTextColor(txt); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, 0)
            })
        })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        root.addView(body)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (themeSig != Themes.sig(this)) { recreate(); return }     // ThemeActivity me theme / accent badla
        Updater.resume(this)
        render()
    }

    private fun pageTitle() = when (page) {
        P_LIST -> "List"
        P_AUDIO -> "Audio"
        P_SUB -> "Subtitle"
        P_GENERAL -> "General"
        P_PLAYER -> "Player"
        P_DECODER -> "Decoder"
        P_PRIVACY -> "Privacy"
        P_DEV -> "Development"
        P_SCREEN -> "Screen"
        P_CONTROLS -> "Controls"
        P_NAV -> "Navigation"
        P_PLAYBACK -> "Playback"
        else -> "Settings"
    }

    private fun open(p: String) = startActivity(Intent(this, SettingsActivity::class.java).putExtra(PAGE, p))

    // ---------- small UI helpers ----------
    private fun section(t: String) = TextView(this).apply {
        tag = "sec"
        text = t.uppercase(); setTextColor(acc); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
        setPadding(dp(8), dp(22), 0, dp(8))
    }

    private fun note(t: String) = TextView(this).apply {
        tag = "note"
        text = t; setTextColor(txt2); textSize = 12.5f; setLineSpacing(0f, 1.1f); setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    private fun divider() = View(this).apply {
        tag = "div"
        setBackgroundColor((txt2 and 0xFFFFFF) or 0x22000000)
        layoutParams = LinearLayout.LayoutParams(-1, dp(1))
    }

    /**
     * Pages are written as a flat list (section, rows, dividers, notes). Here the rows between two
     * headings / notes are wrapped into one rounded card, so every page reads as clear groups.
     */
    private fun groupIntoCards() {
        val kids = (0 until body.childCount).map { body.getChildAt(it) }
        body.removeAllViews()
        var card: LinearLayout? = null
        var pendingDiv: View? = null
        fun closeCard() { card = null; pendingDiv = null }
        for (v in kids) {
            when (v.tag) {
                "sec", "note" -> { closeCard(); body.addView(v) }
                "div" -> if (card != null) pendingDiv = v
                else -> {
                    if (card == null) {
                        card = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            setBackgroundResource(R.drawable.card_bg)
                            setPadding(dp(14), dp(4), dp(10), dp(4))
                            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2); bottomMargin = dp(2) }
                        }
                        body.addView(card)
                    } else pendingDiv?.let { card!!.addView(it) }
                    pendingDiv = null
                    card!!.addView(v)
                }
            }
        }
    }

    /** Home page row: round icon, title + subtitle, arrow. */
    private fun homeRow(icon: Int, title: String, sub: String, onClick: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(14), dp(6), dp(14))
        addView(ImageView(context).apply {
            setImageResource(icon); setColorFilter(acc); setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor((acc and 0xFFFFFF) or 0x26000000) }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(16) }
        })
        addView(texts(title, sub).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        addView(TextView(context).apply { text = "\u203A"; setTextColor(txt2); textSize = 24f; setPadding(dp(8), 0, dp(4), 0) })
        ripple(this)
        setOnClickListener { onClick() }
    }

    private fun texts(title: String, sub: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(context).apply { text = title; setTextColor(txt); textSize = 16f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
        if (!sub.isNullOrEmpty()) addView(TextView(context).apply {
            text = sub; setTextColor(txt2); textSize = 13f; setPadding(0, dp(3), 0, 0)
        })
    }

    private fun ripple(v: View) {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        if (tv.resourceId != 0) v.setBackgroundResource(tv.resourceId)
    }

    /** Tap karne wali row. onClick null ho to sirf info. */
    private fun row(title: String, sub: String?, onClick: (() -> Unit)?): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(56)
        setPadding(dp(4), dp(14), dp(4), dp(14))
        addView(texts(title, sub).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        if (onClick != null) {
            addView(TextView(context).apply { text = "\u203A"; setTextColor(txt2); textSize = 24f; setPadding(dp(8), 0, dp(4), 0) })
            ripple(this)
            setOnClickListener { onClick() }
        }
    }

    private fun switchRow(title: String, sub: String?, on: Boolean, f: (Boolean) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(56)
        setPadding(dp(4), dp(10), dp(4), dp(10))
        addView(texts(title, sub).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        val sw = Switch(context)
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, 0xFFB4B4C6.toInt()))
        sw.trackTintList = ColorStateList(st, intArrayOf(acc, (txt2 and 0xFFFFFF) or 0x55000000))
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, c -> f(c) }
        addView(sw)
        ripple(this)
        setOnClickListener { sw.toggle() }
    }

    private fun seekRow(title: String, lo: Int, hi: Int, cur: Int, fmt: (Int) -> String, f: (Int) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(4), dp(12), dp(4), dp(8))
        val label = TextView(context).apply { text = "$title: " + fmt(cur); setTextColor(txt); textSize = 16f }
        addView(label)
        addView(SeekBar(context).apply {
            this.max = hi - lo
            progress = cur - lo
            progressTintList = ColorStateList.valueOf(acc)
            thumbTintList = ColorStateList.valueOf(acc)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: " + fmt(p + lo)
                    if (fromUser) f(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun defSwitch(title: String, sub: String?, d: BoolDef): View =
        switchRow(title, sub, d.get(this)) { d.set(this, it) }

    /** Index based choice (0..n-1) ko IntDef me save karta hai. */
    private fun choiceRow(title: String, d: IntDef, labels: List<String>): View {
        val cur = d.get(this).coerceIn(0, labels.size - 1)
        return row(title, labels[cur]) { pick(title, labels, cur) { w -> d.set(this, w); render() } }
    }

    private fun colorRow(title: String, d: IntDef): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(13), dp(4), dp(13))
        addView(texts(title, null).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        addView(View(context).apply {
            background = GradientDrawable().apply { setColor(d.get(this@SettingsActivity)); cornerRadius = dp(6).toFloat(); setStroke(dp(1), 0x88888888.toInt()) }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(26))
        })
        ripple(this)
        setOnClickListener { colorDialog(d) }
    }

    private fun colorDialog(d: IntDef) {
        val palette = longArrayOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFFFFC107, 0xFFFF9800, 0xFFFF5252, 0xFFFF4081,
            0xFFE040FB, 0xFF7C4DFF, 0xFF448AFF, 0xFF40C4FF, 0xFF18FFFF, 0xFF69F0AE,
            0xFF76FF03, 0xFF22FF22, 0xFFBDBDBD, 0xFF616161, 0xFF212121, 0xFF000000).map { it.toInt() }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(6)) }
        var dialog: AlertDialog? = null
        palette.chunked(6).forEach { r ->
            grid.addView(LinearLayout(this).apply {
                r.forEach { c ->
                    addView(View(context).apply {
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(1), 0x88888888.toInt()) }
                        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
                        setOnClickListener { d.set(this@SettingsActivity, c); dialog?.dismiss(); render() }
                    })
                }
            })
        }
        val dlg = AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Colour").setView(grid)
            .setNegativeButton("Cancel", null).create()
        dialog = dlg
        dlg.show()
    }

    private fun pick(title: String, items: List<String>, cur: Int, f: (Int) -> Unit) {
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle(title)
            .setSingleChoiceItems(items.toTypedArray(), cur) { d, w -> f(w); d.dismiss() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun langPick(title: String, cur: String?, f: (String?) -> Unit) {
        val items = listOf("Auto (last chosen)") + AppSettings.LANGS.map { it.second }
        val idx = if (cur == null) 0 else AppSettings.LANGS.indexOfFirst { it.first == cur }.let { if (it < 0) -1 else it + 1 }
        pick(title, items, idx) { w -> f(if (w == 0) null else AppSettings.LANGS[w - 1].first) }
    }

    // ---------- pages ----------
    private fun render() {
        body.removeAllViews()
        when (page) {
            P_LIST -> listPage()
            P_AUDIO -> audioPage()
            P_SUB -> subPage()
            P_GENERAL -> generalPage()
            P_PLAYER -> playerPage()
            P_DECODER -> decoderPage()
            P_PRIVACY -> privacyPage()
            P_DEV -> devPage()
            P_SCREEN -> screenPage()
            P_CONTROLS -> controlsPage()
            P_NAV -> navPage()
            P_PLAYBACK -> playbackPage()
            else -> homePage()
        }
        groupIntoCards()
    }

    private fun homePage() {
        body.addView(homeRow(R.drawable.ic_list, "List", "View mode, layout, sort, fields, Continue Watching, NEW badge") { open(P_LIST) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_play, "Player", "Screen, controls, navigation, playback") { open(P_PLAYER) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_track, "Decoder", "HW, HW+ or SW, fallback, audio offset") { open(P_DECODER) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_audio, "Audio", "Equalizer, volume boost, audio language, audio delay") { open(P_AUDIO) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_cc, "Subtitle", "Style, layout, encoding, sync, language") { open(P_SUB) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_gear, "General", "Theme, hidden folders, updates, reset") { open(P_GENERAL) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_info, "Privacy", "Privacy policy, translation permission, licences, contact") { open(P_PRIVACY) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_info, "Report a problem", "Tell us about a bug or issue, with up to 4 screenshots") { startActivity(Intent(this, ReportActivity::class.java)) })
        body.addView(divider())
        body.addView(homeRow(R.drawable.ic_file, "Development", "Log viewer, settings export and import, build info") { open(P_DEV) })
    }

    private fun listPage() {
        val modes = listOf("All folders", "Files", "Folders")
        val grid = Lib.sp(this).getBoolean("grid", false)
        body.addView(section("Library"))
        body.addView(row("View mode, layout, sort and fields",
            modes[Lib.vmode(this)] + "  \u00B7  " + (if (grid) "Grid" else "List") + "  \u00B7  " + Lib.sortLabel(this)) {
            LibraryMenu.show(this, Themes.dialog(this), txt, txt2, acc, grid) { render() }
        })
        body.addView(divider())
        body.addView(switchRow("Continue Watching row", "Show the row at the top of the library", AppSettings.CONT_RECENT.get(this)) {
            AppSettings.CONT_RECENT.set(this, it)
        })
        body.addView(divider())
        val days = listOf(1, 2, 3, 5, 7, 14, 30)
        val cur = AppSettings.NEW_DAYS.get(this)
        body.addView(row("NEW badge duration", "Videos you have not started show NEW for " + cur + (if (cur == 1) " day" else " days")) {
            pick("NEW badge duration", days.map { if (it == 1) "1 day" else "$it days" }, days.indexOf(cur)) { w ->
                AppSettings.NEW_DAYS.set(this, days[w]); render()
            }
        })
        body.addView(section("Recycle bin and private vault"))
        body.addView(defSwitch("Recycle bin", "Deleted videos wait in the bin instead of being erased. Needs All files access.", AppSettings.BIN_ON))
        body.addView(divider())
        body.addView(choiceRow("Keep deleted videos for", AppSettings.BIN_DAYS_I, listOf("7 days", "14 days", "30 days", "60 days")))
        body.addView(divider())
        body.addView(row("Open recycle bin", "Restore or remove deleted videos") { StashActivity.openBin(this) })
        body.addView(divider())
        body.addView(row("Private vault", "Videos hidden behind a PIN") { StashActivity.openVault(this) })
        if (Pin.has(this)) {
            body.addView(divider())
            body.addView(row("Change vault PIN", null) {
                Pin.ask(this, "Change PIN", null, onOk = { Pin.setup(this, onDone = { toast("PIN changed") }) }, onCancel = { })
            })
        }
    }

    private fun audioPage() {
        body.addView(section("Defaults"))
        body.addView(switchRow("Equalizer on", "Applies to every video. Band levels are set in the player's Equalizer panel.", AppSettings.EQ_ON.get(this)) {
            AppSettings.EQ_ON.set(this, it)
        })
        body.addView(divider())
        body.addView(seekRow("Volume boost", 0, 15, AppSettings.BOOST_DB.get(this), { "$it dB" }) { AppSettings.BOOST_DB.set(this, it) })
        body.addView(note("High boost can distort sound and hurt your ears on earphones. Raise it slowly."))
        body.addView(divider())
        body.addView(row("Reset equalizer bands to flat", null) {
            AppSettings.resetEq(this)
            Toast.makeText(this, "Equalizer bands reset", Toast.LENGTH_SHORT).show()
        })
        body.addView(section("Language"))
        val cur = AppSettings.PREF_AUDIO_LANG.get(this)
        body.addView(row("Preferred audio language", AppSettings.langLabel(cur)) {
            langPick("Preferred audio language", cur) { AppSettings.PREF_AUDIO_LANG.set(this, it); render() }
        })
        body.addView(note("Picking an audio track inside the player also updates this."))
        body.addView(section("Sync"))
        body.addView(switchRow("Remember audio delay per video", "Off: audio delay resets when the player closes", AppSettings.REM_ADELAY.get(this)) {
            AppSettings.REM_ADELAY.set(this, it)
        })
        body.addView(note("Changes apply the next time you open a video."))
    }

    private fun subPage() {
        body.addView(section("Display"))
        body.addView(switchRow("Show subtitles", "Default for every video", AppSettings.SHOW_SUBS.get(this)) {
            AppSettings.SHOW_SUBS.set(this, it)
        })
        body.addView(divider())
        body.addView(switchRow("Animated ASS", "Karaoke and moving text. Uses more battery.", AppSettings.ASS_ANIM.get(this)) {
            AppSettings.ASS_ANIM.set(this, it)
        })
        body.addView(section("Text"))
        body.addView(seekRow("Size", 10, 60, AppSettings.SUB_SIZE.get(this), { "$it" }) { AppSettings.SUB_SIZE.set(this, it) })
        body.addView(colorRow("Colour", AppSettings.SUB_COLOR))
        body.addView(divider())
        body.addView(defSwitch("Bold", null, AppSettings.SUB_BOLD))
        body.addView(divider())
        body.addView(defSwitch("Border", "Outline around the text", AppSettings.SUB_BORDER))
        body.addView(divider())
        body.addView(defSwitch("Background", "Dark box behind the text", AppSettings.SUB_BG))
        body.addView(section("Layout"))
        body.addView(choiceRow("Alignment", AppSettings.SUB_ALIGN, listOf("Left", "Center", "Right")))
        body.addView(seekRow("Bottom margin", 0, 40, AppSettings.SUB_POS.get(this), { "$it" }) { AppSettings.SUB_POS.set(this, it) })
        body.addView(defSwitch("Fit subtitles into video size", null, AppSettings.SUB_FIT))
        body.addView(defSwitch("Move up when controls show", "Off: subtitles stay in place and the controls draw over them, like MX Player", AppSettings.SUB_LIFT))
        body.addView(note("Font, font folder and the live preview are in the player's subtitle panel. ASS/SSA subtitles use their own style, so these apply to SRT/VTT."))
        body.addView(section("Timing and encoding"))
        val enc = AppSettings.SUB_ENC.get(this)
        val encItems = listOf("Auto") + AppSettings.ENCODINGS
        body.addView(row("Character encoding", enc ?: "Auto (UTF-8, else Windows-1252)") {
            pick("Character encoding", encItems, if (enc == null) 0 else encItems.indexOf(enc)) { w ->
                AppSettings.SUB_ENC.set(this, if (w == 0) null else encItems[w]); render()
            }
        })
        body.addView(note("Used when you add a subtitle file. Pick the right one if the letters look broken."))
        body.addView(seekRow("Default sync (delay)", -100, 100, AppSettings.SUB_SYNC.get(this),
            { String.format(java.util.Locale.US, "%+.1f s", it / 10.0) }) { AppSettings.SUB_SYNC.set(this, it) })
        body.addView(note("Applied to every video's added subtitle. Embedded tracks only support a positive delay."))
        body.addView(section("Effects"))
        body.addView(defSwitch("Italic effect", "A line starting with / is shown in italic", AppSettings.SUB_ITALIC))
        body.addView(divider())
        body.addView(defSwitch("Force LTR for RTL subtitles", "Arabic, Urdu: keeps punctuation on the correct side", AppSettings.SUB_LTR))
        body.addView(section("Language"))
        val cur = AppSettings.PREF_SUB_LANG.get(this)
        body.addView(row("Preferred subtitle language", AppSettings.langLabel(cur)) {
            langPick("Preferred subtitle language", cur) { AppSettings.PREF_SUB_LANG.set(this, it); render() }
        })
        body.addView(note("Picking a subtitle track inside the player also updates this. Changes apply the next time you open a video."))
    }

    private fun para(t: String) = TextView(this).apply {
        text = t; setTextColor(txt); textSize = 14f; setLineSpacing(0f, 1.15f); setPadding(dp(4), dp(4), dp(4), dp(6))
    }

    private fun privacyPage() {
        body.addView(section("Permission"))
        body.addView(switchRow("Allow online translation",
            "Subtitle text (not video or audio) is sent to Google Translate when you use Translate. Off by default.",
            AppSettings.TR_CONSENT.get(this)) {
            AppSettings.TR_CONSENT.set(this, it)
            if (!it) AppSettings.sp(this).edit().remove("trlive").apply()     // live translation bhi band
        })
        if (Build.VERSION.SDK_INT >= 30) {
            body.addView(row("All files access",
                if (AllFiles.granted()) "On: delete, rename, move, copy, recycle bin and private vault work without extra Android prompts. Tap to change."
                else "Off: Android asks you each time you delete or rename, and move, copy, recycle bin and private vault are unavailable. Tap to allow.") {
                AllFiles.open(this, -1)
            })
        }
        body.addView(section("Contact"))
        body.addView(row("Email", AppSettings.CONTACT_EMAIL) {
            try {
                startActivity(Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:" + AppSettings.CONTACT_EMAIL))
                    .putExtra(Intent.EXTRA_SUBJECT, "NextGen Play privacy"))
            } catch (e: Exception) { Toast.makeText(this, AppSettings.CONTACT_EMAIL, Toast.LENGTH_LONG).show() }
        })
        body.addView(section("Privacy policy"))
        body.addView(note("Effective " + AppSettings.POLICY_DATE))
        PrivacyText.SECTIONS.forEach { (h, t) ->
            body.addView(TextView(this).apply {
                text = h; setTextColor(txt); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(14), dp(4), dp(2))
            })
            body.addView(para(t))
        }
        body.addView(section("Open-source licences"))
        body.addView(para(LicenseText.INTRO))
        LicenseText.ITEMS.forEach { (n, t) ->
            body.addView(TextView(this).apply {
                text = n; setTextColor(txt); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(10), dp(4), dp(0))
            })
            body.addView(para(t))
        }
    }

    // ---------- Development page ----------
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun devPage() {
        body.addView(section("Log"))
        body.addView(row("View log", "Last 300 lines written by this app") { showLog() })
        body.addView(divider())
        body.addView(row("Share log", "Or use Report a problem on the Settings home page") { shareLog() })
        body.addView(section("Settings backup"))
        body.addView(row("Export settings", "Settings, favourites and hidden folders, saved to a file") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, "nextgen-play-settings.json"), REQ_EXPORT)
        })
        body.addView(divider())
        body.addView(row("Import settings", "Load a file made by Export") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT)
        })
        body.addView(note("Watch history and added subtitles are not part of the backup. The online translation permission is never imported."))
        body.addView(section("This build"))
        body.addView(row("Version", "v" + Updater.curName(this) + "   \u00B7   Android " + android.os.Build.VERSION.RELEASE + "   \u00B7   " + android.os.Build.MODEL, null))
    }

    private fun readLog(): String = try {
        val p = ProcessBuilder("logcat", "-d", "-t", "300", "--pid=" + android.os.Process.myPid()).redirectErrorStream(true).start()
        val t = p.inputStream.bufferedReader().readText()
        if (t.isBlank()) "(the log is empty)" else t
    } catch (e: Exception) { "Could not read the log: " + e.message }

    private fun showLog() {
        toast("Reading log...")
        Thread { val t = readLog(); runOnUiThread { logDialog(t) } }.start()
    }

    private fun logDialog(t: String) {
        val tv = TextView(this).apply {
            text = t; typeface = Typeface.MONOSPACE; textSize = 10f; setTextColor(txt)
            setPadding(dp(12), dp(8), dp(12), dp(8)); setTextIsSelectable(true)
        }
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Log").setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("log", t))
                toast("Copied")
            }.show()
    }

    private fun shareLog() {
        Thread {
            val t = readLog()
            runOnUiThread {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share log"))
            }
        }.start()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        try {
            if (req == REQ_EXPORT) {
                contentResolver.openOutputStream(uri)?.use { it.write(AppSettings.exportJson(this).toByteArray()) }
                toast("Settings exported")
            } else if (req == REQ_IMPORT) {
                val s = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                val n = AppSettings.importJson(this, s)
                toast("Imported $n settings")
                recreate()
            }
        } catch (e: Exception) { toast("Failed: " + e.message) }
    }

    private fun decoderPage() {
        val names = AppSettings.DEC_NAMES
        body.addView(section("Default decoder"))
        val loc = AppSettings.decMode(this, false)
        body.addView(row("Local files", names[loc]) {
            pick("Local files", names, loc) { w -> AppSettings.DEC_LOCAL.set(this, w); render() }
        })
        body.addView(divider())
        val net = AppSettings.decMode(this, true)
        body.addView(row("Network streams", names[net]) {
            pick("Network streams", names, net) { w -> AppSettings.DEC_NET.set(this, w); render() }
        })
        body.addView(note("HW: phone's hardware decoders (FFmpeg audio only if the phone has no decoder for it).\nHW+: hardware video, FFmpeg audio preferred (AC3, EAC3, DTS, TrueHD, FLAC...).\nSW: software video decoders. Slower, but works when hardware fails.\nThe HW / HW+ / SW button in the player changes the default for that kind of file."))
        body.addView(section("When a decoder fails"))
        body.addView(defSwitch("Try HW+ if HW fails", null, AppSettings.TRY_HWPLUS))
        body.addView(divider())
        body.addView(defSwitch("Try HW if HW+ fails", null, AppSettings.TRY_HW))
        body.addView(note("SW is always the last step. A toast says \"Try next decoder\" each time it switches. The switch lasts for the current playback only."))
        body.addView(section("Software"))
        body.addView(defSwitch("Software audio in SW mode", "Off: only video uses software decoders", AppSettings.SW_AUDIO))
        body.addView(section("Sync"))
        body.addView(seekRow("Calibrate playback position", -100, 100, AppSettings.AUDIO_CAL.get(this),
            { String.format(java.util.Locale.US, "%+.1f s", it / 10.0) }) { AppSettings.AUDIO_CAL.set(this, it) })
        val rt = AudioRoute.current(this)
        if (rt != null) {
            val saved = AudioRoute.saved(this, rt.first)
            body.addView(seekRow("Calibrate for " + rt.second, -100, 100, saved ?: AppSettings.AUDIO_CAL.get(this),
                { String.format(java.util.Locale.US, "%+.1f s", it / 10.0) }) { AppSettings.sp(this).edit().putInt(rt.first, it).apply() })
            body.addView(note("Saved only for this earphone or speaker. It is used whenever it is connected and overrides the value above."))
            if (saved != null) body.addView(row("Use the common value for " + rt.second, null) {
                AppSettings.sp(this).edit().remove(rt.first).apply(); render()
            })
        } else body.addView(note("Connect earphones or a Bluetooth speaker to set a calibration just for them."))
        body.addView(note("Audio offset applied to every video, for phones or earphones that lag. A delay you set in the player for one video overrides it."))
        body.addView(note("Applies the next time you open a video."))
    }

    private fun playerPage() {
        body.addView(row("Screen", "Orientation, interface at start, battery and clock") { open(P_SCREEN) })
        body.addView(divider())
        body.addView(row("Controls", "Touch action, lock mode, gestures, shortcuts, auto-hide") { open(P_CONTROLS) })
        body.addView(divider())
        body.addView(row("Navigation", "Swipe seek speed, skip buttons, target position") { open(P_NAV) })
        body.addView(divider())
        body.addView(row("Playback", "Resume, default speed, back button") { open(P_PLAYBACK) })
    }

    private fun screenPage() {
        body.addView(choiceRow("Orientation", AppSettings.ORIENT, listOf("Follow video", "Auto (sensor)", "Landscape", "Portrait")))
        body.addView(divider())
        body.addView(defSwitch("Show interface at start", "Off: controls stay hidden until you tap", AppSettings.SHOW_UI_START))
        body.addView(divider())
        body.addView(defSwitch("Battery and clock", "Small overlay at the top of the video", AppSettings.CLOCK))
        body.addView(note("The screen already stays on while a video plays. Changes apply the next time you open a video."))
    }

    private fun controlsPage() {
        body.addView(section("Touch"))
        body.addView(choiceRow("Touch action", AppSettings.TAP_ACTION, listOf("Show / hide interface", "Play / pause")))
        body.addView(divider())
        body.addView(choiceRow("Lock mode", AppSettings.LOCK_MODE, listOf("Block everything", "Block buttons, allow volume and brightness swipes")))
        body.addView(section("Gestures"))
        body.addView(defSwitch("Swipe to seek", "Horizontal swipe", AppSettings.G_SEEK))
        body.addView(divider())
        body.addView(defSwitch("Pinch to zoom", null, AppSettings.G_PINCH))
        body.addView(divider())
        body.addView(defSwitch("Volume swipe", "Right half, vertical", AppSettings.G_VOL))
        body.addView(divider())
        body.addView(defSwitch("Brightness swipe", "Left half, vertical", AppSettings.G_BRI))
        body.addView(divider())
        body.addView(defSwitch("Double-tap to play / pause", "Middle of the screen", AppSettings.G_DT_PLAY))
        body.addView(divider())
        body.addView(defSwitch("Double-tap to fast forward / rewind", "Left and right sides", AppSettings.G_DT_SEEK))
        body.addView(divider())
        body.addView(defSwitch("Long press for 2x speed", null, AppSettings.G_LONG))
        body.addView(section("Quick shortcuts"))
        body.addView(defSwitch("Mute", null, AppSettings.SC_MUTE))
        body.addView(defSwitch("Sleep timer", null, AppSettings.SC_SLEEP))
        body.addView(defSwitch("Night mode", null, AppSettings.SC_NIGHT))
        body.addView(defSwitch("Frame back / forward", null, AppSettings.SC_FRAME))
        body.addView(defSwitch("Rotate", null, AppSettings.SC_ROTATE))
        body.addView(defSwitch("Picture in picture", "Button in the shortcuts row", AppSettings.SC_PIP))
        body.addView(defSwitch("Playback speed", null, AppSettings.SC_SPEED))
        body.addView(defSwitch("Screenshot", null, AppSettings.SC_SHOT))
        body.addView(defSwitch("Equalizer", null, AppSettings.SC_EQ))
        body.addView(defSwitch("Mirror (horizontal flip)", null, AppSettings.SC_MIRROR))
        body.addView(defSwitch("Vertical flip", null, AppSettings.SC_VFLIP))
        body.addView(defSwitch("Repeat", "Tap to cycle off, this video, all videos", AppSettings.SC_REPEAT))
        body.addView(defSwitch("Shuffle", null, AppSettings.SC_SHUFFLE))
        body.addView(defSwitch("A-B repeat", "Tap once for A, again for B, again to clear", AppSettings.SC_AB))
        body.addView(note("The shortcut row has an arrow at its start that collapses and expands it."))
        body.addView(section("Interface"))
        body.addView(seekRow("Auto-hide controls after", 1, 10, AppSettings.AUTOHIDE.get(this), { "$it s" }) { AppSettings.AUTOHIDE.set(this, it) })
        body.addView(defSwitch("Smooth fade", "Seekbar and all buttons fade in and out together", AppSettings.UI_ANIM))
        body.addView(note("Applies the next time you open a video."))
    }

    private fun navPage() {
        body.addView(seekRow("Swipe seek speed", 2, 60, AppSettings.SEEK_SPCM.get(this), { "$it s per cm" }) { AppSettings.SEEK_SPCM.set(this, it) })
        body.addView(divider())
        body.addView(seekRow("Skip button interval (+)", 5, 180, AppSettings.SKIP_S.get(this), { "$it s" }) { AppSettings.SKIP_S.set(this, it) })
        body.addView(divider())
        body.addView(defSwitch("Previous / next buttons", null, AppSettings.PREV_NEXT))
        body.addView(divider())
        body.addView(defSwitch("Show target position while seeking", null, AppSettings.SHOW_TARGET))
    }

    private fun playbackPage() {
        body.addView(choiceRow("Resume", AppSettings.RESUME, listOf("Always resume", "Ask every time", "Never (start from the beginning)")))
        body.addView(divider())
        val sp = listOf(50, 75, 100, 125, 150, 200)
        val cur = AppSettings.DEF_SPEED.get(this)
        body.addView(row("Default playback speed", (cur / 100.0).toString().removeSuffix(".0") + "x") {
            pick("Default playback speed", sp.map { (it / 100.0).toString().removeSuffix(".0") + "x" }, sp.indexOf(cur)) { w ->
                AppSettings.DEF_SPEED.set(this, sp[w]); render()
            }
        })
        body.addView(note("Videos where you picked a speed yourself keep that speed."))
        body.addView(switchRow("Background play", "Keep playing the audio when you leave the app, with notification controls. Picture in picture is skipped when this is on.",
            AppSettings.BG_PLAY.get(this)) {
            AppSettings.BG_PLAY.set(this, it)
            if (it && android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)      // notification dikhane ke liye
        })
        body.addView(divider())
        body.addView(defSwitch("Show remaining time", "Tap the total time in the player to switch it too", AppSettings.SHOW_REMAIN))
        body.addView(divider())
        body.addView(defSwitch("Double-tap back to close the player", "First back press shows a hint", AppSettings.DBL_BACK))
        body.addView(note("Only the first video of a queue resumes from its saved position."))
    }

    private fun generalPage() {
        val themeNames = listOf("Dark", "Light", "Follow system")
        body.addView(section("Appearance"))
        body.addView(row("Theme and accent colour", themeNames[AppSettings.sp(this).getInt("theme", 0).coerceIn(0, 2)]) {
            startActivity(Intent(this, ThemeActivity::class.java))
        })

        body.addView(section("Library"))
        val hidCount = (AppSettings.sp(this).getStringSet("hid", null) ?: emptySet<String>()).size
        body.addView(row("Hidden folders", if (hidCount == 0) "None hidden" else "$hidCount hidden. Tap to unhide.") { hiddenDialog() })

        body.addView(section("App"))
        body.addView(row("Check for updates", "Current version: v" + Updater.curName(this)) { Updater.check(this, true) })
        body.addView(divider())
        body.addView(row("Reset all settings to default", "Favourites, hidden folders and watch history are kept.") { resetDialog() })
    }

    private fun hiddenDialog() {
        val names = (AppSettings.sp(this).getStringSet("hid", null) ?: emptySet<String>()).sorted().toTypedArray()
        if (names.isEmpty()) { Toast.makeText(this, "No hidden folders", Toast.LENGTH_SHORT).show(); return }
        val checked = BooleanArray(names.size) { true }
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Hidden folders (untick to unhide)")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val keep = HashSet<String>()
                names.forEachIndexed { i, n -> if (checked[i]) keep.add(n) }
                AppSettings.sp(this).edit().putStringSet("hid", keep).apply()
                render()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun resetDialog() {
        AlertDialog.Builder(this, Themes.dialog(this)).setTitle("Reset all settings?")
            .setMessage("Every setting goes back to its default. Favourites, hidden folders and watch history are not touched.")
            .setPositiveButton("Reset") { _, _ ->
                AppSettings.resetAll(this)
                Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
                recreate()
            }
            .setNegativeButton("Cancel", null).show()
    }
}
