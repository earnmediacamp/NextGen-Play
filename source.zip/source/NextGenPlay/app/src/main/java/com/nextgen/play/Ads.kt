package com.nextgen.play

import android.app.Activity
import android.app.Application
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean
import com.unity3d.mediation.*
import com.unity3d.mediation.banner.*
import com.unity3d.mediation.interstitial.*
import com.unity3d.mediation.rewarded.*

/**
 * Ads for NextGen Play (Unity LevelPlay: Unity Ads + ironSource):
 * - 1 banner (LevelPlay), sirf library screen ke neeche (upar wala hata diya: header buttons ke paas galat click hote the).
 * - 1 full-screen video ad, har 40 minute me max 1, sirf jab user player se library par wapas aaye (natural break).
 * - Rewarded video: user khud dekhta hai -> poora ad-free (banner + full-screen band).
 *     1 video = 6 ghante, 2 videos = 12 ghante, 4 videos = 24 ghante. Adhura progress 30 minute saved rehta hai.
 * - Player ke andar kabhi ad nahi.
 */
object Ads {
    private const val PREFS = "ngp_ads_state"
    private const val KEY_LAST_VIDEO = "last_video_ad_ms"
    private const val KEY_UNTIL = "adfree_until_ms"          // ad-free kab tak (trusted time)
    private const val KEY_MAXSEEN = "adfree_maxseen_ms"      // ab tak dekha sabse bada clock (clock peeche karne se time na badhe)
    private const val KEY_DONE = "rw_done"                   // adhure package me kitne videos dekh liye
    private const val KEY_DONE_AT = "rw_done_at"
    private const val HOUR_MS = 60 * 60 * 1000L
    private const val VIDEO_GAP_MS = 40 * 60 * 1000L      // 40 minute (30-45 ke beech)
    private const val RETRY_GAP_MS = 60 * 1000L
    private const val PROGRESS_KEEP_MS = 30 * 60 * 1000L
    private const val MAX_ADFREE_MS = 48 * HOUR_MS           // zyada stack nahi hoga
    private const val BANNER_REFRESH_MS = 60 * 1000L         // banner har 60 sec me naya ad le (pehle ek hi ad atka rehta tha)

    // Unity LevelPlay (banner + full-screen + rewarded).
    // App Key + ad unit IDs gradle.properties se BuildConfig me aate hain (LP_APP_KEY, LP_BANNER_ID, LP_INTERSTITIAL_ID, LP_REWARDED_ID).
    private const val LP_LOAD_TIMEOUT_MS = 15000L            // itne me LevelPlay ka ad na aaye to "No video available" (cold load me 8 sec kam pad sakta hai)
    private const val LP_INIT_RETRY_MS = 15000L
    private const val LP_INIT_MAX_TRIES = 4

    /** (videos, hours) */
    private val PACKS = listOf(1 to 6, 2 to 12, 4 to 24)

    private var app: Application? = null

    private class Slot { var view: View? = null; var loading = false; var loadStart = 0L; var loadedAt = 0L; var refresh: Runnable? = null; var unityTurn = false; var owner: Activity? = null }
    @Volatile private var lpReady = false
    @Volatile private var lpGaveUp = false                // key khali ya init ke saare try fail: ab aur intezaar nahi
    @Volatile private var lpRewardedRef: LevelPlayRewardedAd? = null   // ad ke dauran object GC na ho
    // Ad na aane ka karan toast me dikhane ke liye (testing). Sab theek hone par false kar do.
    private const val SHOW_AD_WHY = false
    @Volatile private var lpWhy = "-"
    /** Fail hone par sirf toast. SHOW_AD_WHY true ho to karan bhi (testing). */
    private fun noVideo(act: Activity) {
        if (!alive(act)) return
        val msg = if (SHOW_AD_WHY) "No video available. LevelPlay: $lpWhy"
                  else "No video available right now. Please try again later."
        Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
    }
    private fun whyText(): String = if (SHOW_AD_WHY) "\n[LevelPlay: $lpWhy]" else ""
    private val main = Handler(Looper.getMainLooper())
    private val bottomSlot = Slot()

    private var libraryVisible = false
    private var videoBusy = false
    private var rewardBusy = false
    @Volatile private var rewardToken = 0                 // watchdog: purane watchOne ka timer naye ko na tode
    private var lastVideoAttempt = 0L
    @Volatile private var playerSeen = false                 // player abhi band hua -> library par ek natural break

    fun init(a: Application) {
        app = a
        lpInit(a, 1)
    }

    private fun errStr(e: Any?): String {
        if (e == null) return "null"
        return try {
            val c = e.javaClass.getMethod("getErrorCode").invoke(e)
            val m = e.javaClass.getMethod("getErrorMessage").invoke(e)
            "$c $m".take(120)
        } catch (_: Throwable) { e.toString().take(120) }
    }

    /** LevelPlay init. Fail ho to thodi der baad dobara (max LP_INIT_MAX_TRIES baar). */
    private fun lpInit(a: Application, attempt: Int) {
        if (BuildConfig.LP_APP_KEY.isBlank()) { lpWhy = "LP_APP_KEY empty"; lpGaveUp = true; return }
        try {
            val req = LevelPlayInitRequest.Builder(BuildConfig.LP_APP_KEY).build()
            LevelPlay.init(a, req, object : LevelPlayInitListener {
                override fun onInitSuccess(configuration: LevelPlayConfiguration) { lpReady = true }
                override fun onInitFailed(error: LevelPlayInitError) {
                    lpReady = false
                    lpWhy = "init " + errStr(error)
                    if (attempt < LP_INIT_MAX_TRIES) main.postDelayed({ lpInit(a, attempt + 1) }, LP_INIT_RETRY_MS)
                    else lpGaveUp = true
                }
            })
        } catch (e: Throwable) { lpReady = false; lpGaveUp = true; lpWhy = "init crash " + e.javaClass.simpleName }
    }

    // ---------- Ad-free state ----------
    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Phone ki clock peeche kar do to bhi time wapas nahi aata: hamesha ab tak ka sabse bada time. */
    private fun trustedNow(c: Context): Long {
        val p = sp(c)
        val wall = System.currentTimeMillis()
        val seen = p.getLong(KEY_MAXSEEN, 0L)
        if (wall > seen) { p.edit().putLong(KEY_MAXSEEN, wall).apply(); return wall }
        return seen
    }

    fun adFreeLeftMs(c: Context): Long = maxOf(0L, sp(c).getLong(KEY_UNTIL, 0L) - trustedNow(c))
    fun isAdFree(c: Context): Boolean = adFreeLeftMs(c) > 0L

    /** "Report a problem" email me jaane wali ad ki halat (koi personal data nahi). */
    fun reportInfo(c: Context): String =
        "Ad-free left: " + (if (isAdFree(c)) fmt(adFreeLeftMs(c)) else "none") + "\n" +
        "Rewarded progress: " + doneCount(c) + "\n" +
        "Ads ready: " + lpReady + " (gave up: " + lpGaveUp + ")\n" +
        "Last ad status: " + lpWhy + "\n"

    /** used = is pack me kitne dekhe hue videos kharch hue. Bache hue videos ka progress rehta hai. */
    private fun grant(c: Context, hours: Int, used: Int) {
        val now = trustedNow(c)
        val base = maxOf(sp(c).getLong(KEY_UNTIL, 0L), now)
        val until = minOf(base + hours * HOUR_MS, now + MAX_ADFREE_MS)
        val remaining = maxOf(0, doneCount(c) - used)
        val e = sp(c).edit().putLong(KEY_UNTIL, until).putInt(KEY_DONE, remaining)
        if (remaining == 0) e.putLong(KEY_DONE_AT, 0L)
        e.apply()
        Stats.log("adfree_granted", "hours" to hours)
    }

    private fun doneCount(c: Context): Int {
        val p = sp(c)
        val n = p.getInt(KEY_DONE, 0)
        if (n <= 0) return 0
        return if (trustedNow(c) - p.getLong(KEY_DONE_AT, 0L) > PROGRESS_KEEP_MS) {
            p.edit().putInt(KEY_DONE, 0).apply(); 0
        } else n
    }

    private fun fmt(ms: Long): String {
        val m = (ms / 60000L).toInt()
        val h = m / 60
        return if (h >= 1) "${h}h ${m % 60}m" else "${maxOf(1, m)}m"
    }

    /** Header ke neeche wali pill ka text. */
    fun pillText(c: Context): String =
        if (isAdFree(c)) "Ad-free  \u00B7  ${fmt(adFreeLeftMs(c))} left  \u00B7  Add more"
        else "\u25B6\uFE0E  Watch a video  \u00B7  Ad-free up to 24 hours"

    // ---------- Banner: sirf neeche (adBar) ----------
    fun attachBanners(act: Activity) {
        val bar = act.findViewById<ViewGroup>(R.id.adBar) ?: return
        if (isAdFree(act)) { bar.visibility = View.GONE; return }
        attach(act, bar, bottomSlot)
    }

    private fun place(bar: ViewGroup, view: View) {
        try {
            (view.parent as? ViewGroup)?.removeView(view)
            bar.removeAllViews()
            val d = bar.resources.displayMetrics.density
            val lpBanner = view is LevelPlayBannerAdView
            bar.addView(view, FrameLayout.LayoutParams(
                if (lpBanner) (320 * d).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                if (lpBanner) (50 * d).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ))
            bar.visibility = View.VISIBLE
        } catch (_: Throwable) { }
    }

    private fun alive(act: Activity) = !act.isFinishing && !act.isDestroyed

    private fun attach(act: Activity, bar: ViewGroup, slot: Slot) {
        var existing = slot.view
        if (existing is LevelPlayBannerAdView && slot.owner !== act) {   // purani activity ka LevelPlay banner: naye par nahi lagta
            try { existing.destroy() } catch (_: Throwable) { }
            slot.view = null; existing = null
        }
        if (existing != null) place(bar, existing)
        if (app == null) return
        if (!lpReady) {
            // LevelPlay abhi init ho raha hai: thodi der baad dobara dekho. Key khali ya init ke saare try fail to ruk jao.
            if (lpGaveUp) return
            bar.postDelayed({ if (alive(act) && !isAdFree(act)) attach(act, bar, slot) }, 1800L)
            return
        }
        val stale = existing == null || System.currentTimeMillis() - slot.loadedAt >= BANNER_REFRESH_MS - 5000L
        if (stale) loadBanner(act, bar, slot)
        scheduleRefresh(act, bar, slot)
    }

    /** Naya LevelPlay banner mangao. Fail ho to agli refresh (60 sec) par dobara koshish hogi. */
    private fun loadBanner(act: Activity, bar: ViewGroup, slot: Slot) {
        // load atka reh jaye (callback na aaye) to 20 sec baad dobara koshish
        if (slot.loading && System.currentTimeMillis() - slot.loadStart < 20000L) return
        slot.loading = true
        slot.loadStart = System.currentTimeMillis()
        loadLpBanner(act, bar, slot) { slot.loading = false }
    }

    private fun swapIn(act: Activity, bar: ViewGroup, slot: Slot, view: View) {
        val old = slot.view
        slot.view = view
        slot.owner = act
        slot.loadedAt = System.currentTimeMillis()
        place(bar, view)
        if (old is LevelPlayBannerAdView && old !== view) { try { old.destroy() } catch (_: Throwable) { } }
    }

    private fun loadLpBanner(act: Activity, bar: ViewGroup, slot: Slot, onFail: () -> Unit) {
        try {
            val cfg = LevelPlayBannerAdView.Config.Builder().setAdSize(LevelPlayAdSize.BANNER).build()
            val bv = LevelPlayBannerAdView(act, BuildConfig.LP_BANNER_ID, cfg)
            bv.setBannerListener(object : LevelPlayBannerAdViewListener {
                override fun onAdLoaded(adInfo: LevelPlayAdInfo) {
                    slot.loading = false
                    // SDK ka apna auto-refresh band: refresh sirf hamare 60 sec timer se hoga
                    try { bv.pauseAutoRefresh() } catch (_: Throwable) { }
                    if (alive(act) && !isAdFree(act)) swapIn(act, bar, slot, bv)
                    else { try { bv.destroy() } catch (_: Throwable) { } }
                }
                override fun onAdLoadFailed(error: LevelPlayAdError) {
                    lpWhy = "banner " + errStr(error)
                    if (slot.view === bv) return            // dikh raha banner ka auto-refresh fail hua: purana chalne do
                    try { bv.destroy() } catch (_: Throwable) { }
                    act.runOnUiThread(onFail)
                }
                override fun onAdDisplayed(adInfo: LevelPlayAdInfo) { }
                override fun onAdClicked(adInfo: LevelPlayAdInfo) { }
            })
            bv.loadAd()
        } catch (_: Throwable) { onFail() }
    }

    /** Har 60 sec par naya banner (load jab tak na aaye purana dikhta rahta hai). Timer main handler par hai, activity badalne par bhi nahi atakta. */
    private fun scheduleRefresh(act: Activity, bar: ViewGroup, slot: Slot) {
        slot.refresh?.let { main.removeCallbacks(it) }
        val r = Runnable {
            slot.refresh = null
            if (alive(act) && libraryVisible && !isAdFree(act) && lpReady) {
                loadBanner(act, bar, slot)
                scheduleRefresh(act, bar, slot)
            }
        }
        slot.refresh = r
        main.postDelayed(r, BANNER_REFRESH_MS)
    }

    // ---------- Full video ad: sirf player se library wapas aane par, 40 minute me max 1 ----------
    /** PlayerActivity.onPause se: user ne video dekha, ab library par aayega. */
    fun onPlayerLeft() { playerSeen = true }

    fun onLibraryResumed(act: Activity) {
        libraryVisible = true
        attachBanners(act)
        val comingFromPlayer = playerSeen
        playerSeen = false
        if (comingFromPlayer) maybeShowVideo(act)
    }

    fun onLibraryPaused() { libraryVisible = false }

    /**
     * LevelPlay ka full-screen / rewarded ad: load -> show. finish(shown, completed):
     * shown=false  -> LevelPlay se ad nahi chala (load fail / timeout / show fail): user ko "No video available" dikhao.
     * shown=true   -> ad chala; completed = reward mila (sirf rewarded ke liye).
     * Har baar naya ad object banta hai (init ke baad), isliye purane state ka jhanjhat nahi.
     */
    private fun lpRun(act: Activity, rewarded: Boolean, canShow: () -> Boolean, onShown: () -> Unit, onLate: () -> Unit = {}, finish: (Boolean, Boolean) -> Unit) {
        if (!lpReady) { if (lpWhy == "-") lpWhy = "not initialised yet"; finish(false, false); return }
        val settled = AtomicBoolean(false)     // load ka natija aa gaya (loaded / failed / timeout)
        val finished = AtomicBoolean(false)    // finish sirf ek baar
        var started = false
        var rewardOk = false
        var closedFlag = false
        val rewardReported = AtomicBoolean(false)   // onAdRewarded aaya (ad band hone ke kitni bhi der baad aaye, ginte hain)
        val done = { shown: Boolean, completed: Boolean ->
            if (finished.compareAndSet(false, true)) main.post { finish(shown, completed) }
        }
        val timeout = Runnable { if (settled.compareAndSet(false, true)) { lpWhy = "load timeout"; done(false, false) } }
        main.postDelayed(timeout, LP_LOAD_TIMEOUT_MS)

        fun loaded(show: () -> Unit) {
            if (!settled.compareAndSet(false, true)) return
            main.removeCallbacks(timeout)
            if (!canShow()) { done(false, false); return }
            try { show() } catch (_: Throwable) { done(false, false) }
        }
        fun loadFailed(error: LevelPlayAdError) {
            lpWhy = "load " + errStr(error)
            Stats.log("lp_load_fail", "why" to lpWhy.take(60))
            if (settled.compareAndSet(false, true)) { main.removeCallbacks(timeout); done(false, false) }
        }
        fun displayed() { started = true; Stats.log("lp_displayed", "rewarded" to rewarded.toString()); onShown() }
        fun displayFailed(error: LevelPlayAdError) {
            lpWhy = "show " + errStr(error)
            if (started) done(true, false) else done(false, false)
        }
        // onAdRewarded aksar onAdClosed ke BAAD aata hai: band hone ke baad 6 sec tak reward ka intezaar (aate hi turant result)
        fun closed() {
            closedFlag = true
            Stats.log("lp_closed", "rewarded" to rewarded.toString(), "reward_cb" to rewardReported.get().toString())
            if (!rewarded) { done(true, false); return }
            if (rewardReported.get()) return           // reward pehle aa chuka, result ja chuka
            main.postDelayed({
                if (!rewardReported.get()) { lpWhy = "ad closed, onAdRewarded not received (yet)"; done(true, false) }
            }, 6000L)
        }
        // Reward ka callback aate hi turant result (ad band hone ka intezaar nahi)
        fun rewardedNow() {
            if (!rewardReported.compareAndSet(false, true)) return   // reward sirf ek baar
            rewardOk = true
            Stats.log("lp_reward_cb")
            if (finished.compareAndSet(false, true)) main.post { finish(true, true) }
            else if (rewarded) { Stats.log("reward_late"); main.post { onLate() } }                // "no reward" result ja chuka tha par reward baad me aaya: phir bhi do
        }

        try {
            if (rewarded) {
                val ad = LevelPlayRewardedAd(BuildConfig.LP_REWARDED_ID)
                lpRewardedRef = ad
                ad.setListener(object : LevelPlayRewardedAdListener {
                    override fun onAdLoaded(adInfo: LevelPlayAdInfo) { loaded { ad.showAd(act) } }
                    override fun onAdLoadFailed(error: LevelPlayAdError) { loadFailed(error) }
                    override fun onAdDisplayed(adInfo: LevelPlayAdInfo) { displayed() }
                    override fun onAdRewarded(reward: LevelPlayReward, adInfo: LevelPlayAdInfo) { rewardedNow() }
                    override fun onAdDisplayFailed(error: LevelPlayAdError, adInfo: LevelPlayAdInfo) { displayFailed(error) }
                    override fun onAdClicked(adInfo: LevelPlayAdInfo) { }
                    override fun onAdClosed(adInfo: LevelPlayAdInfo) { closed() }
                    override fun onAdInfoChanged(adInfo: LevelPlayAdInfo) { }
                })
                ad.loadAd()
            } else {
                val ad = LevelPlayInterstitialAd(BuildConfig.LP_INTERSTITIAL_ID)
                ad.setListener(object : LevelPlayInterstitialAdListener {
                    override fun onAdLoaded(adInfo: LevelPlayAdInfo) { loaded { ad.showAd(act) } }
                    override fun onAdLoadFailed(error: LevelPlayAdError) { loadFailed(error) }
                    override fun onAdDisplayed(adInfo: LevelPlayAdInfo) { displayed() }
                    override fun onAdDisplayFailed(error: LevelPlayAdError, adInfo: LevelPlayAdInfo) { displayFailed(error) }
                    override fun onAdClicked(adInfo: LevelPlayAdInfo) { }
                    override fun onAdClosed(adInfo: LevelPlayAdInfo) { closed() }
                    override fun onAdInfoChanged(adInfo: LevelPlayAdInfo) { }
                })
                ad.loadAd()
            }
        } catch (_: Throwable) {
            if (settled.compareAndSet(false, true)) { main.removeCallbacks(timeout); done(false, false) }
        }
    }

    private fun maybeShowVideo(act: Activity) {
        if (!lpReady || videoBusy || rewardBusy || !alive(act) || isAdFree(act)) return
        val prefs = sp(act)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(KEY_LAST_VIDEO, 0L)
        // Pehli baar (ya phone ki clock peeche gayi): timer abhi se shuru, ad turant nahi.
        if (last == 0L || last > now) { prefs.edit().putLong(KEY_LAST_VIDEO, now).apply(); return }
        if (now - last < VIDEO_GAP_MS) return
        if (now - lastVideoAttempt < RETRY_GAP_MS) return
        lastVideoAttempt = now
        videoBusy = true
        // LevelPlay interstitial
        lpRun(act, false, { alive(act) && libraryVisible && !isAdFree(act) },
            { prefs.edit().putLong(KEY_LAST_VIDEO, System.currentTimeMillis()).apply() }) { _, _ ->
            videoBusy = false
        }
    }

    // ---------- Rewarded video: "Go ad-free" ----------
    /**
     * target = package me kitne videos chahiye (1 / 2 / 4). Ek video poora dekhne par done++,
     * done >= target hote hi ad-free mil jata hai. onChange: UI refresh. onNext: package adhura hai -> dialog dobara kholo.
     */
    private fun watchOne(act: Activity, target: Int, hours: Int, onChange: () -> Unit, onNext: () -> Unit) {
        if (rewardBusy) return
        // 1-video pack: ad-free chal raha ho to timer khatam hone tak band (dubara ad dikhta tha par fayda nahi tha)
        if (target == 1 && isAdFree(act)) {
            Toast.makeText(act, "1-video pack is available again in ${fmt(adFreeLeftMs(act))}.", Toast.LENGTH_LONG).show(); return
        }
        if (doneCount(act) >= target) {          // pehle ka progress hi kaafi hai
            grant(act, hours, target)
            Toast.makeText(act, "Ad-free for $hours hours", Toast.LENGTH_LONG).show()
            onChange(); return
        }
        if (adFreeLeftMs(act) + hours * HOUR_MS > MAX_ADFREE_MS) {   // 48h limit: abhi dekha to reward waste hoga
            Toast.makeText(act, "You already have ${fmt(adFreeLeftMs(act))} of ad-free. Come back when it is lower.", Toast.LENGTH_LONG).show(); return
        }
        if (!lpReady) {
            Toast.makeText(act, if (lpGaveUp) "Ads are not available right now." else "Ads are still loading. Try again in a moment.", Toast.LENGTH_SHORT).show(); return
        }
        rewardBusy = true
        val myToken = ++rewardToken
        main.postDelayed({
            if (rewardBusy && rewardToken == myToken) { rewardBusy = false; Stats.log("reward_watchdog") }   // callback kho gaya to button atka na rahe
        }, 120000L)
        Toast.makeText(act, "Loading video\u2026", Toast.LENGTH_SHORT).show()
        // LevelPlay rewarded
        lpRun(act, true, { alive(act) }, { }, onLate = { act.runOnUiThread { rewardComplete(act, target, hours, onChange, onNext) } }) { shown, completed ->
            if (shown) {
                rewardBusy = false
                act.runOnUiThread {
                    if (completed) rewardComplete(act, target, hours, onChange, onNext)
                    else Toast.makeText(act, "Watch the full video to get the reward" + whyText(), Toast.LENGTH_LONG).show()
                }
            } else {
                rewardBusy = false
                act.runOnUiThread { noVideo(act) }
            }
        }
    }

    private fun rewardComplete(act: Activity, target: Int, hours: Int, onChange: () -> Unit, onNext: () -> Unit) {
        val p = sp(act)
        Stats.log("rewarded_complete", "pack" to target)
        val n = doneCount(act) + 1
        p.edit().putInt(KEY_DONE, n).putLong(KEY_DONE_AT, trustedNow(act)).apply()
        if (n >= target) {
            grant(act, hours, target)
            Toast.makeText(act, "Done! Ad-free for $hours hours", Toast.LENGTH_LONG).show()
            onChange()
        } else {
            Toast.makeText(act, "$n of $target watched", Toast.LENGTH_SHORT).show()
            onChange(); onNext()
        }
    }

    /** Pill par tap: 3 options wala dialog. */
    fun showAdFreeDialog(act: Activity, onChange: () -> Unit) {
        if (!alive(act)) return
        val dp = { x: Int -> AppDialogs.dp(act, x) }
        val text = AppDialogs.col(act, R.attr.appText, Color.WHITE)
        val text2 = AppDialogs.col(act, R.attr.appText2, Color.GRAY)
        val accent = AppDialogs.col(act, R.attr.appAccent, Color.parseColor("#32A8FF"))
        val soft = AppDialogs.col(act, R.attr.appAccentSoft, Color.parseColor("#3332A8FF"))
        val done = doneCount(act)
        var dlg: android.app.AlertDialog? = null

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
        }
        box.addView(TextView(act).apply {
            this.text = "Go ad-free"; setTextColor(text); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
        })
        val status = when {
            isAdFree(act) -> "Ad-free now \u00B7 ${fmt(adFreeLeftMs(act))} left. Watch more to add time."
            else -> "Watch short videos to remove all banner and video ads for a while."
        }
        box.addView(TextView(act).apply {
            this.text = status; setTextColor(text2); textSize = 13f
            setPadding(0, dp(6), 0, dp(if (done > 0) 6 else 14))
        })
        if (done > 0) box.addView(TextView(act).apply {
            this.text = "Progress saved: $done video${if (done > 1) "s" else ""} watched"
            setTextColor(accent); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(12))
        })

        for ((n, h) in PACKS) {
            val left = maxOf(0, n - done)
            val label = when {
                left == 0 -> "Claim $h hours ad-free"
                left == n -> "Watch $n video${if (n > 1) "s" else ""}  \u2192  $h hours ad-free"
                else -> "Watch $left more  \u2192  $h hours ad-free"
            } + if (n == 4) "  (best value)" else ""
            val locked = n == 1 && isAdFree(act)
            val pillView = AppDialogs.pill(act, if (locked) "Watch 1 video  \u00B7  available in ${fmt(adFreeLeftMs(act))}" else label, soft, accent, accent) {
                if (locked) { watchOne(act, n, h, onChange, onNext = { }); return@pill }
                dlg?.dismiss()
                watchOne(act, n, h, onChange, onNext = { showAdFreeDialog(act, onChange) })
            }
            if (locked) pillView.alpha = 0.45f
            box.addView(pillView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        box.addView(TextView(act).apply {
            this.text = "Videos must be watched fully. Ads come back when the time ends."
            setTextColor(text2); textSize = 11f; setPadding(0, dp(4), 0, dp(10))
        })
        box.addView(AppDialogs.pill(act, "Not now", null, text2, text2) { dlg?.dismiss() },
            LinearLayout.LayoutParams(-1, -2))
        dlg = AppDialogs.show(act, box)
    }
}
