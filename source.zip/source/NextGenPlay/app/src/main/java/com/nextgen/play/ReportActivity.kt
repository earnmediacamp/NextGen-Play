package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * "Report a problem": user bug/issue likhta hai, 4 tak screenshots chunta hai, phir uske email app me
 * to/subject/body/attachments bhare hue khulte hain. Bhejna user ke haath me hai (Send dabaye bina kuch nahi jata).
 * Koi server ya upload nahi hai.
 */
class ReportActivity : Activity() {
    companion object {
        private const val REQ_PICK = 81
        private const val MAX_SHOTS = 4
        private val CATEGORIES = listOf(
            "Ads or ad-free reward", "Video playback", "Subtitles", "Audio", "Library or folders",
            "Settings", "Update", "App crash or freeze", "Something else"
        )
    }

    private fun dp(x: Int) = AppDialogs.dp(this, x)
    private fun attr(a: Int): Int { val tv = TypedValue(); theme.resolveAttribute(a, tv, true); return tv.data }

    private var txt = 0
    private var txt2 = 0
    private var acc = 0
    private var category = 0
    private val shots = ArrayList<File>()
    private val dir by lazy { File(cacheDir, "report") }
    private lateinit var catBtn: TextView
    private lateinit var desc: EditText
    private lateinit var shotsRow: LinearLayout
    private lateinit var addBtn: TextView
    private lateinit var diagCb: CheckBox
    private lateinit var logCb: CheckBox
    private lateinit var sendBtn: TextView
    @Volatile private var picking = false

    override fun onCreate(b: Bundle?) {
        setTheme(if (Themes.light(this)) R.style.Theme_NextGenPlay_Light else R.style.Theme_NextGenPlay)
        Themes.applyAccent(this)
        super.onCreate(b)
        txt = attr(R.attr.appText); txt2 = attr(R.attr.appText2); acc = attr(R.attr.appAccent)
        val soft = AppDialogs.col(this, R.attr.appAccentSoft, Color.parseColor("#3332A8FF"))

        // Purani report ki temporary files saaf
        try { dir.deleteRecursively(); dir.mkdirs() } catch (_: Throwable) { }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(28)) }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_back); setColorFilter(txt); setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); setOnClickListener { finish() }
            })
            addView(TextView(context).apply {
                text = "Report a problem"; setTextColor(txt); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, 0)
            })
        })

        root.addView(label("What is it about?"))
        catBtn = AppDialogs.pill(this, categoryLabel(), soft, acc, acc) {
            AlertDialog.Builder(this, Themes.dialog(this)).setTitle("What is it about?")
                .setItems(CATEGORIES.toTypedArray()) { _, i -> category = i; catBtn.text = categoryLabel() }.show()
        }
        root.addView(catBtn, LinearLayout.LayoutParams(-1, -2))

        root.addView(label("What went wrong?"))
        desc = EditText(this).apply {
            hint = "Tell us what you did, what you expected and what happened instead."
            setHintTextColor(txt2); setTextColor(txt); textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 5; maxLines = 12; gravity = Gravity.TOP or Gravity.START
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), txt2); setColor(Color.TRANSPARENT) }
        }
        root.addView(desc, LinearLayout.LayoutParams(-1, -2))

        root.addView(label("Screenshots (up to $MAX_SHOTS)"))
        shotsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(shotsRow, LinearLayout.LayoutParams(-1, -2))
        addBtn = AppDialogs.pill(this, "", soft, acc, acc) { pick() }
        root.addView(addBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(small("Choose only screenshots that show the problem. Anything you add is sent in your email and can be seen by us."))

        diagCb = check("Include app and phone details", "App version, Android version, phone model, language and ad status.")
        logCb = check("Attach the app log", "The last 300 lines the app wrote. It helps us find crashes and errors.")
        root.addView(diagCb); root.addView(logCb)

        sendBtn = AppDialogs.pill(this, "Send report by email", acc, Color.WHITE, acc) { send() }
        root.addView(sendBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        root.addView(small("Your email app opens with everything filled in. Nothing is sent until you press Send there."))

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        refreshShots()
    }

    private fun categoryLabel() = "Topic: " + CATEGORIES[category] + "  ▾"

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(txt); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(18), 0, dp(8))
    }

    private fun small(t: String) = TextView(this).apply {
        text = t; setTextColor(txt2); textSize = 12f; setPadding(0, dp(8), 0, 0)
    }

    private fun check(title: String, sub: String) = CheckBox(this).apply {
        text = title + "\n" + sub; setTextColor(txt); textSize = 13f; isChecked = true
        buttonTintList = ColorStateList.valueOf(acc)
        setPadding(dp(6), dp(10), 0, dp(4))
    }

    // ---------- Screenshots ----------
    private fun pick() {
        if (picking) return
        if (shots.size >= MAX_SHOTS) { toast("You can add up to $MAX_SHOTS screenshots."); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try { startActivityForResult(i, REQ_PICK) } catch (_: Exception) { toast("No gallery or file app was found.") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != REQ_PICK || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) clip.getItemAt(k).uri?.let { uris.add(it) }
        } else {
            data.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) return
        val room = MAX_SHOTS - shots.size
        if (uris.size > room) toast("Only $MAX_SHOTS screenshots can be added.")
        val take = uris.take(room)
        picking = true
        addBtn.isEnabled = false
        Thread {
            val done = ArrayList<File>()
            for (u in take) {
                val f = File(dir, "screenshot_" + System.nanoTime() + ".jpg")
                if (shrink(u, f)) done.add(f)
            }
            runOnUiThread {
                picking = false
                addBtn.isEnabled = true
                if (done.size < take.size) toast("Some images could not be read.")
                shots.addAll(done)
                refreshShots()
            }
        }.start()
    }

    /** Badi photo ko 1600px / JPEG me chhota karo, taaki 4 photos email limit me rahein. */
    private fun shrink(u: Uri, out: File): Boolean {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth <= 0 || o.outHeight <= 0) return false
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 2400) s *= 2
            val bm = contentResolver.openInputStream(u)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return false
            val m = maxOf(bm.width, bm.height)
            val f = if (m > 1600) 1600f / m else 1f
            val sc = if (f < 1f) Bitmap.createScaledBitmap(bm, maxOf(1, (bm.width * f).toInt()), maxOf(1, (bm.height * f).toInt()), true) else bm
            FileOutputStream(out).use { sc.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            if (sc !== bm) bm.recycle()
            sc.recycle()
            return true
        } catch (_: Throwable) { return false }
    }

    private fun refreshShots() {
        shotsRow.removeAllViews()
        for (f in shots) {
            val thumb = try {
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 })
            } catch (_: Throwable) { null }
            val cell = FrameLayout(this)
            cell.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                if (thumb != null) setImageBitmap(thumb)
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#33808080")) }
                clipToOutline = true
            }, FrameLayout.LayoutParams(dp(72), dp(72)))
            cell.addView(TextView(this).apply {
                text = "✕"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC000000")) }
                setOnClickListener { shots.remove(f); try { f.delete() } catch (_: Throwable) { }; refreshShots() }
            }, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END))
            shotsRow.addView(cell, LinearLayout.LayoutParams(dp(72), dp(72)).apply { marginEnd = dp(8) })
        }
        addBtn.text = if (shots.isEmpty()) "Add screenshots" else "Add more (${shots.size} of $MAX_SHOTS)"
        addBtn.visibility = if (shots.size >= MAX_SHOTS) View.GONE else View.VISIBLE
    }

    // ---------- Send ----------
    private fun readLog(): String = try {
        val p = ProcessBuilder("logcat", "-d", "-t", "300", "--pid=" + android.os.Process.myPid()).redirectErrorStream(true).start()
        val t = p.inputStream.bufferedReader().readText()
        if (t.isBlank()) "(the log is empty)" else t
    } catch (e: Exception) { "Could not read the log: " + e.message }

    private fun diag(): String = buildString {
        append("App: v").append(Updater.curName(this@ReportActivity)).append('\n')
        append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        append("Phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        append("Language: ").append(Locale.getDefault().toString()).append('\n')
        append(Ads.reportInfo(this@ReportActivity))
    }

    private fun uriOf(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun send() {
        val text = desc.text.toString().trim()
        if (text.length < 5) { toast("Please describe the problem first."); desc.requestFocus(); return }
        sendBtn.isEnabled = false
        val withLog = logCb.isChecked
        Thread {
            val uris = ArrayList<Uri>()
            try { for (f in shots) uris.add(uriOf(f)) } catch (_: Throwable) { }
            if (withLog) {
                try { val lf = File(dir, "app-log.txt"); lf.writeText(readLog()); uris.add(uriOf(lf)) } catch (_: Throwable) { }
            }
            runOnUiThread { sendBtn.isEnabled = true; launchEmail(text, uris) }
        }.start()
    }

    private fun launchEmail(text: String, uris: List<Uri>) {
        val body = StringBuilder(text)
        if (diagCb.isChecked) body.append("\n\n--- Details ---\n").append(diag())
        val subject = "NextGen Play report: " + CATEGORIES[category] + " (v" + Updater.curName(this) + ")"
        val intent: Intent
        if (uris.isEmpty()) {
            intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + AppSettings.CONTACT_EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, body.toString())
        } else {
            intent = Intent(Intent.ACTION_SEND_MULTIPLE).setType("message/rfc822")
                .putExtra(Intent.EXTRA_EMAIL, arrayOf(AppSettings.CONTACT_EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, body.toString())
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val clip = ClipData.newRawUri("report", uris[0])
            for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
            intent.clipData = clip
        }
        try {
            startActivity(Intent.createChooser(intent, "Send report with"))
        } catch (_: ActivityNotFoundException) {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", body.toString()))
            toast("No email app found. Your text is copied. Please email " + AppSettings.CONTACT_EMAIL)
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
