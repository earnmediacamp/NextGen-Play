package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Environment
import android.provider.MediaStore
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.provider.OpenableColumns
import android.util.TypedValue
import java.io.File
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.media.MediaMetadataRetriever
import android.os.SystemClock
import android.widget.ProgressBar
import android.widget.RadioButton
import android.graphics.drawable.GradientDrawable
import java.util.concurrent.Executors
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.Switch
import android.content.res.ColorStateList
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.SubtitleView
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Locale
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.video.VideoFrameMetadataListener
import androidx.media3.ui.AspectRatioFrameLayout as AR
import androidx.media3.ui.PlayerView
import io.github.peerless2012.ass.media.AssHandlerConfig
import io.github.peerless2012.ass.media.kt.buildWithAssSupport
import io.github.peerless2012.ass.media.type.AssRenderType
import androidx.media3.ui.TimeBar
import kotlin.math.abs

/** libass (ass-media) ko external ASS track ka id numeric aur >= 128 chahiye; baaki formats "ext" hi rehte hain. */
private const val ASS_EXT_ID = "129"

private class ExtSub(val text: String, val kind: String, val mime: String, val name: String) {
    var cur: File? = null
    var tr: String? = null          // translate ki hui poori subtitle file (text)
    var trLang: String? = null
    var trName: String? = null
    var useTr = false
}

private const val SHARP_AGSL = """
uniform shader inputShader;
uniform float amount;
half4 main(float2 c) {
    half4 s = inputShader.eval(c);
    half4 n = inputShader.eval(c + float2(0.0, -1.0));
    half4 d = inputShader.eval(c + float2(0.0, 1.0));
    half4 w = inputShader.eval(c + float2(-1.0, 0.0));
    half4 e = inputShader.eval(c + float2(1.0, 0.0));
    half3 o = s.rgb * (1.0 + 4.0 * amount) - (n.rgb + d.rgb + w.rgb + e.rgb) * amount;
    return half4(clamp(o, 0.0, 1.0), s.a);
}
"""

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var uris: Array<String>
    private lateinit var pv: PlayerView
    private lateinit var info: TextView
    private lateinit var ttl: TextView
    private lateinit var decBtn: TextView
    private lateinit var playBtn: ImageView
    private lateinit var playFlash: ImageView
    private var manualOrient = false   // user ne rotate button dabaya -> auto orientation band (agle video tak)
    private lateinit var unlockBtn: ImageView
    private lateinit var am: AudioManager
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideFlash = Runnable {
        playFlash.animate().alpha(0f).setDuration(220).withEndAction { playFlash.visibility = View.GONE }.start()
    }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }

    // ---- instant double-tap skip ----
    private lateinit var skipL: TextView
    private lateinit var skipR: TextView
    private var skipBase = 0L
    private var skipAcc = 0L
    private var skipDir = 0
    private var lastSkipAt = 0L
    private val hideSkip = Runnable { skipL.visibility = View.GONE; skipR.visibility = View.GONE }
    private val exactSeek = Runnable { player.setSeekParameters(SeekParameters.EXACT) }

    // ---- hold = 2x, level bar, A-B repeat, autosave, scrub preview ----
    private var boost = false
    private var preBoost = 1f
    private var boostAcc = 0f                         // long-press ke baad upar / neeche slide: speed badlo
    private var boostSpeed = 2f
    private var zoom = 1f                             // pinch zoom 1x se 4x, do ungli se pan
    private var panX = 0f
    private var panY = 0f
    private var durTv: TextView? = null
    private lateinit var levelBox: View
    private lateinit var levelTxt: TextView
    private lateinit var levelBar: ProgressBar
    private val hideLevel = Runnable { levelBox.visibility = View.GONE }
    private var abA = -1L
    private var abB = -1L
    private var lastSave = 0L
    private lateinit var scrubBox: View
    private lateinit var scrubImg: ImageView
    private lateinit var scrubTime: TextView
    private val scrubPool = Executors.newSingleThreadExecutor()
    private var mmr: MediaMetadataRetriever? = null
    private var mmrUri: String? = null
    private var scrubBusy = false
    private var scrubWant = -1L
    private val modes = intArrayOf(AR.RESIZE_MODE_FIT, AR.RESIZE_MODE_FILL, AR.RESIZE_MODE_ZOOM)
    private val aspectNames = arrayOf("Fit", "Stretch", "Crop")
    private var mode = 0
    private var folder = ""
    private var names: Array<String>? = null
    private var referer: String? = null
    private var mimes: Array<String>? = null          // network link ka type (HLS / DASH), NetProbe se
    private var locked = false
    private var g = 0          // gesture: 1=seek 2=brightness 3=volume
    private var seekBy = 0L
    private var bright = 0.5f
    private var vol = 0f
    private val subs = HashMap<Int, MediaItem.SubtitleConfiguration>()

    // ---- sub / audio delay (per video, sirf is session ke liye) ----
    private lateinit var subView: SubtitleView
    private lateinit var ccBtn: ImageView
    private val audioDelay = AudioDelayProcessor()
    private var audioDelayOn = false      // true hone par hi audio chain me delay processor lagta hai
    private var fallbacks = 0
    private var sessMode = -1                       // error fallback ka session-only decoder (-1 = setting wala)
    private val triedModes = HashSet<Int>()
    private fun isNet(i: Int) = uris.getOrNull(i)?.startsWith("http", true) == true || uris.getOrNull(i)?.startsWith("rtsp", true) == true

    /** All items are network links with no added subtitle: these use our own data source (redirects, browser User-Agent, Referer). */
    private fun netOnly() = uris.indices.all { isNet(it) && subs[it] == null }

    private fun netFactory(k: Int): androidx.media3.exoplayer.source.DefaultMediaSourceFactory {
        val http = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(NetProbe.UA)
            .setConnectTimeoutMs(15_000).setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(mapOf("Referer" to NetProbe.refererFor(uris[k], referer), "Accept" to "*/*"))
        return androidx.media3.exoplayer.source.DefaultMediaSourceFactory(androidx.media3.datasource.DefaultDataSource.Factory(this, http))
    }
    private fun curMode(i: Int) = if (sessMode >= 0) sessMode else AppSettings.decMode(this, isNet(i))
    private val subDelay = HashMap<Int, Long>()
    private val subSpeed = HashMap<Int, Double>()      // external subtitle ki speed (1.0 = normal)
    private val audDelay = HashMap<Int, Long>()
    private val ext = HashMap<Int, ExtSub>()           // external subtitle file (re-time karne ke liye text yaad rakhte hain)
    private val cueEvents = ArrayList<Pair<Long, List<Cue>>>()   // embedded subtitle ke live delay ke liye
    private var lastCues: List<Cue> = emptyList()
    private var rawCues: List<Cue> = emptyList()
    private var shown: List<Cue> = emptyList()
    private var reloadIdx = -1
    private var badgeAfterSelect = false
    private var pendingExt = -1                       // is item par external subtitle track ko zabardasti select karna hai
    private var sleepAt = 0L
    private val sleepRun = Runnable { sleepAt = 0L; player.pause(); show("Sleep timer: paused") }
    private val reloadSub = Runnable { reloadItem(reloadIdx) }
    private val flushAudio = Runnable { player.seekTo(player.currentPosition) }
    private val tick = object : Runnable {
        override fun run() {
            updateCues()
            updRemain()
            if (abA >= 0 && abB > abA && player.currentPosition >= abB) player.seekTo(abA)
            val now = SystemClock.uptimeMillis()
            if (now - lastSave > 5_000) { lastSave = now; if (player.isPlaying) save() }
            subView.postDelayed(this, 80)
        }
    }
    private var dlg: AlertDialog? = null

    // ---- night mode + frame by frame ----
    private lateinit var nightBtn: ImageView
    @Volatile private var lastPtsUs = -1L          // abhi dikh rahe frame ka timestamp (VideoFrameMetadataListener se)
    private var stepPos = -1.0
    private var stepAt = 0L
    private var stepDir = 1
    private val stepRepeat = object : Runnable {
        override fun run() { stepFrame(stepDir); pv.postDelayed(this, 110) }
    }

    // ---- subtitle auto sync / translate (side panel state) ----
    private var sideTag: String? = null
    private var syncTv: TextView? = null
    private var syncText = ""
    private var syncBusy = false
    @Volatile private var syncCancel = false
    private var trTv: TextView? = null
    private var trText = ""
    private var trBusy = false
    @Volatile private var trCancel = false
    private var trWarned = false
    private val trCache = HashMap<String, String>()
    private val trPending = HashSet<String>()
    private val trPool = Executors.newFixedThreadPool(2)

    // ---- right side panel (subtitle / more / audio / ...) + left rail ----
    private lateinit var sideWrap: View
    private lateinit var sidePanel: ScrollView
    private lateinit var sideBody: LinearLayout
    private lateinit var railWrap: View
    private lateinit var muteBtn: ImageView
    private var sideOpen = false
    private var sideRebuild: (() -> Unit)? = null
    private var muted = false
    private var tf: Typeface? = null
    private var assViews: List<View> = emptyList()      // libass overlay (animated mode) ke views, player dobara banne par hatane ke liye
    private val DLG = R.style.Theme_NextGenPlay_Dialog

    override fun onCreate(b: Bundle?) {
        Themes.applyAccent(this)
        super.onCreate(b)
        // video ke hisab se orientation: vertical video -> portrait, horizontal -> landscape
        val firstUri = intent.getStringArrayExtra("uris")?.firstOrNull() ?: intent.dataString
        requestedOrientation = when (AppSettings.ORIENT.get(this)) {          // Settings > Player > Screen
            1 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            3 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> if (peekPortrait(firstUri) == true) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (intent.getStringArrayExtra("uris")?.firstOrNull()?.let { Stash.isVaultPath(it) } == true)
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)             // vault video: screenshot / recents preview band
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        pv = findViewById(R.id.pv)
        info = findViewById(R.id.info)
        ttl = findViewById(R.id.title)
        ttl.maxLines = 2                                            // lamba naam 2 line me; poora naam title par tap karke
        ttl.setOnClickListener {
            AlertDialog.Builder(this, DLG).setTitle("Video").setMessage(fullTitle).setPositiveButton("OK", null).show()
        }
        decBtn = findViewById(R.id.decBtn)
        playBtn = findViewById(R.id.playBtn)
        playFlash = findViewById(R.id.playFlash)
        skipL = findViewById(R.id.skipL)
        skipR = findViewById(R.id.skipR)
        levelBox = findViewById(R.id.levelBox)
        levelTxt = findViewById(R.id.levelTxt)
        levelBar = findViewById(R.id.levelBar)
        scrubBox = findViewById(R.id.scrubBox)
        scrubImg = findViewById(R.id.scrubImg)
        scrubTime = findViewById(R.id.scrubTime)
        unlockBtn = findViewById(R.id.unlockBtn)
        subView = findViewById(R.id.subView)
        ccBtn = findViewById(R.id.ccBtn)
        sideWrap = findViewById(R.id.sideWrap)
        sidePanel = findViewById(R.id.sidePanel)
        sideBody = findViewById(R.id.sideBody)
        railWrap = findViewById(R.id.railWrap)
        muteBtn = findViewById(R.id.muteBtn)
        nightBtn = findViewById(R.id.nightBtn)
        findViewById<View>(R.id.sideScrim).setOnClickListener { closeSide() }
        pv.subtitleView?.visibility = View.GONE      // apna SubtitleView use karte hain (delay ke liye)
        durTv = pv.findViewById<TextView>(androidx.media3.ui.R.id.exo_duration)
        durTv?.setOnClickListener {                                          // total time par tap = baaki time (ya wapas)
            AppSettings.SHOW_REMAIN.set(this, !AppSettings.SHOW_REMAIN.get(this))
            if (!AppSettings.SHOW_REMAIN.get(this)) durTv?.text = VideoInfo.dur(player.duration.coerceAtLeast(0L))
            updRemain()
        }
        pv.controllerShowTimeoutMs = AppSettings.AUTOHIDE.get(this) * 1000      // Settings > Player > Controls > Auto-hide
        // Media3 ka controller hide animation sirf apne standard views (bottom bar, progress) ko slide karta hai, baaki buttons
        // baad me gayab hote the. Animation band = seekbar, top buttons, shortcuts, bottom buttons sab ek saath turant hide / show.
        pv.findViewById<androidx.media3.ui.PlayerControlView>(androidx.media3.ui.R.id.exo_controller)?.setAnimationEnabled(false)
        // Smooth fade: poora controller (seekbar + saare buttons) ek hi view hai, to uski visibility badalne par LayoutTransition
        // ka alpha fade sab ko ek saath animate karta hai. APPEARING ka default 300ms delay hata diya.
        if (AppSettings.UI_ANIM.get(this)) pv.layoutTransition = android.animation.LayoutTransition().apply {
            disableTransitionType(android.animation.LayoutTransition.CHANGE_APPEARING)
            disableTransitionType(android.animation.LayoutTransition.CHANGE_DISAPPEARING)
            disableTransitionType(android.animation.LayoutTransition.CHANGING)
            setStartDelay(android.animation.LayoutTransition.APPEARING, 0L)
            setStartDelay(android.animation.LayoutTransition.DISAPPEARING, 0L)
            setDuration(android.animation.LayoutTransition.APPEARING, 160L)
            setDuration(android.animation.LayoutTransition.DISAPPEARING, 220L)
        }
        // Controls dikhein to subtitles unke upar uth jayein (pehle seekbar / buttons ke upar chhap jate the)
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            val bar = pv.findViewById<View>(androidx.media3.ui.R.id.exo_progress)
            val lift = if (vis == View.VISIBLE && AppSettings.SUB_LIFT.get(this)) {
                if (bar != null && bar.height > 0 && subView.height > 0) {
                    val l = IntArray(2); bar.getLocationInWindow(l)
                    val s = IntArray(2); subView.getLocationInWindow(s)
                    (subView.height - (l[1] - s[1]) + dp(8)).coerceIn(0, subView.height / 2)
                } else dp(110)
            } else 0
            animLift(lift)
        })
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_content_frame)
            ?.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> subView.post { layoutSubs() }; if (zoom > 1.01f) applyZoom() }
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
        // brightness: pichli baar set ki hui (sab videos + app restart ke baad bhi) wapas lagao, warna system brightness se shuru
        bright = prefs.getFloat("bright", -1f).let { sv ->
            if (sv > 0f) { window.attributes = window.attributes.also { it.screenBrightness = sv }; sv }
            else try { (android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f).coerceIn(0.01f, 1f) } catch (e: Exception) { 0.5f }
        }

        uris = intent.getStringArrayExtra("uris") ?: arrayOf(intent.dataString ?: return finish())
        names = intent.getStringArrayExtra("names")
        mimes = intent.getStringArrayExtra("mimes")
        referer = intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }
        folder = intent.getStringExtra("folder") ?: ""
        if (AppSettings.REM_ADELAY.get(this)) {          // Settings > Audio: har video ka audio delay yaad rakho
            uris.indices.forEach { i -> prefs.getLong("ad_" + subKey(i), 0L).let { if (it != 0L) audDelay[i] = it } }
            if (audDelay.isNotEmpty()) audioDelayOn = true
        }
        val cal = (AudioRoute.cal(this) ?: AppSettings.AUDIO_CAL.get(this)) * 100L         // Settings > Decoder > Calibrate playback position
        if (cal != 0L) { uris.indices.forEach { audDelay.putIfAbsent(it, cal) }; audioDelayOn = true }
        val h = History.get(this, uris[0])
        val resMode = AppSettings.RESUME.get(this)       // 0 always, 1 ask, 2 never
        val resPos = if (h != null && !History.finished(h)) h.pos else 0L
        start(0, if (resMode == 0) resPos else 0L)
        if (resMode == 1 && resPos > 5_000L) askResume(resPos)
        loadFont(); applySub(); applyEnh(); syncNightUi()
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { moreMenu() }

        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        if (!AppSettings.SHOW_UI_START.get(this)) pv.post { pv.hideController() }
        if (AppSettings.CLOCK.get(this)) { findViewById<View>(R.id.clockOv).visibility = View.VISIBLE; clockRun.run() }

        // shortcuts row: show / hide + collapse setupExtras() aur applyShortcuts() sambhalte hain
        applyRailVisible()

        // CC button -> subtitle side panel
        ccBtn.setOnClickListener { subtitlePage() }
        findViewById<View>(R.id.queueTopBtn).setOnClickListener { queue() }
        muteBtn.setOnClickListener {
            muted = !muted
            player.volume = if (muted) 0f else 1f
            muteBtn.setImageResource(if (muted) R.drawable.ic_mute else R.drawable.ic_volume)
            show(if (muted) "Muted" else "Sound ON")
        }
        findViewById<View>(R.id.sleepBtn).setOnClickListener { sleepPage() }
        nightBtn.setOnClickListener { setNight(!night()) }
        bindStep(findViewById(R.id.frameBackBtn), -1)
        bindStep(findViewById(R.id.frameFwdBtn), 1)
        findViewById<View>(R.id.audioBtn).setOnClickListener { audioPage() }
        findViewById<View>(R.id.prevBtn).setOnClickListener { playPrevious() }
        findViewById<View>(R.id.nextBtn).setOnClickListener { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
        findViewById<View>(R.id.pipBtn).setOnClickListener { pip() }
        updateSkipLabel()
        findViewById<View>(R.id.rotateBtn).setOnClickListener {
            manualOrient = true
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        playBtn.setOnClickListener {
            if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) player.play() else player.pause()
        }
        decBtn.setOnClickListener {
            val i = player.currentMediaItemIndex
            val net = isNet(i)
            val next = (curMode(i) + 1) % 3                       // HW -> HW+ -> SW
            (if (net) AppSettings.DEC_NET else AppSettings.DEC_LOCAL).set(this, next)
            sessMode = -1; triedModes.clear(); fallbacks = 0
            val p = player.currentPosition
            player.release()
            start(i, p)
            show(decBtn.text.toString() + " decoder")
        }
        decBtn.setOnLongClickListener { showDecoderInfo(); true }      // lamba dabao: abhi kaunsa decoder chal raha hai
        findViewById<View>(R.id.lockBtn).setOnClickListener { setLock(true) }
        unlockBtn.setOnClickListener { setLock(false) }
        setupExtras()

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                // skip chain: double-tap ke baad agle single taps bhi turant skip karte hain
                if (!locked && AppSettings.G_DT_SEEK.get(this@PlayerActivity) && SystemClock.uptimeMillis() - lastSkipAt < 700) {
                    val x = e.x / pv.width
                    if (x < 0.35f) { skip(-1); return true }
                    if (x > 0.65f) { skip(1); return true }
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked || g != 0 || boost || !AppSettings.G_LONG.get(this@PlayerActivity)) return
                boost = true
                preBoost = player.playbackParameters.speed
                player.setPlaybackSpeed(2f)
                boostAcc = 0f; boostSpeed = 2f
                info.removeCallbacks(hideInfo)
                info.text = "\u25B6\uFE0E\u25B6\uFE0E  2x"
                info.visibility = View.VISIBLE
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (SystemClock.uptimeMillis() - lastSkipAt < 700) return true
                if (locked) flashUnlock()
                else if (AppSettings.TAP_ACTION.get(this@PlayerActivity) == 1) {         // Settings: touch action = play / pause
                    if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) { player.play(); flashPlay(true) }
                    else { player.pause(); flashPlay(false) }
                }
                else if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (zoom > 1.01f) { resetZoom(); return true }      // zoom hai to double-tap = zoom reset
                val x = e.x / pv.width
                if (x in 0.35f..0.65f) {          // beech me double-tap = play / pause
                    if (!AppSettings.G_DT_PLAY.get(this@PlayerActivity)) return true
                    if (player.playbackState == Player.STATE_ENDED || !player.playWhenReady) { player.play(); flashPlay(true) }
                    else { player.pause(); flashPlay(false) }
                    return true
                }
                if (!AppSettings.G_DT_SEEK.get(this@PlayerActivity)) return true
                skip(if (x < 0.35f) -1 else 1)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null) return false
                if (boost) {                                          // 2x par ungli rakhe rakhe slide: upar = tez, neeche = dheema
                    boostAcc += dy
                    val sp = (2f + Math.round(boostAcc / dp(40)) * 0.25f).coerceIn(0.5f, 4f)
                    if (sp != boostSpeed) {
                        boostSpeed = sp; player.setPlaybackSpeed(sp)
                        info.text = "\u25B6\uFE0E\u25B6\uFE0E  " + (if (sp == sp.toInt().toFloat()) sp.toInt().toString() else sp.toString()) + "x"
                    }
                    return true
                }
                if (locked && AppSettings.LOCK_MODE.get(this@PlayerActivity) == 0) return false      // lock mode: sab block
                if (g == 0) {
                    // screen ke kinare (status bar / notification pull, back & home gesture) se shuru hua swipe ignore
                    val d = resources.displayMetrics.density
                    val edge = e1.y < 56 * d || e1.y > pv.height - 40 * d || e1.x < 28 * d || e1.x > pv.width - 28 * d
                    g = if (edge) -1 else if (abs(dx) > abs(dy)) 1 else if (e1.x < pv.width / 2) 2 else 3
                    val st = this@PlayerActivity
                    if ((g == 1 && (locked || !AppSettings.G_SEEK.get(st))) || (g == 2 && !AppSettings.G_BRI.get(st)) ||
                        (g == 3 && !AppSettings.G_VOL.get(st))) g = -1
                }
                when (g) {
                    -1 -> return false
                    1 -> {
                        val pxCm = resources.displayMetrics.xdpi / 2.54f
                        seekBy -= (dx / pxCm * AppSettings.SEEK_SPCM.get(this@PlayerActivity) * 1000f).toLong()
                        val tgt = (player.currentPosition + seekBy).coerceIn(0L, if (player.duration > 0) player.duration else Long.MAX_VALUE)
                        if (AppSettings.SHOW_TARGET.get(this@PlayerActivity))
                            show(VideoInfo.dur(tgt) + "   (" + (if (seekBy >= 0) "+" else "") + seekBy / 1000 + "s)")
                    }
                    2 -> {
                        bright = (bright + dy / pv.height).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.also { it.screenBrightness = bright }
                        showLevel("Brightness  " + (bright * 100).toInt() + "%", (bright * 100).toInt())
                    }
                    else -> {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        vol = (vol + dy / pv.height * max).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                        showLevel("Volume  " + vol.toInt() + "/" + max, (vol / max * 100).toInt())
                    }
                }
                return true
            }
        })

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var fx = 0f
            private var fy = 0f
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
                fx = d.focusX; fy = d.focusY
                return !locked && AppSettings.G_PINCH.get(this@PlayerActivity)
            }
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (locked || !AppSettings.G_PINCH.get(this@PlayerActivity)) return true
                zoom = (zoom * d.scaleFactor).coerceIn(1f, 4f)           // pinch = zoom, do ungli sarkana = pan
                panX += d.focusX - fx; panY += d.focusY - fy
                fx = d.focusX; fy = d.focusY
                applyZoom()
                return true
            }
            override fun onScaleEnd(d: ScaleGestureDetector) {
                if (zoom > 1.01f) show((zoom * 100).toInt().toString() + "%") else resetZoom()
            }
        })

        pv.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (!sd.isInProgress) gd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (g == 1 && seekBy != 0L) player.seekTo((player.currentPosition + seekBy).coerceAtLeast(0))
                if (g == 2) prefs.edit().putFloat("bright", bright).apply()
                g = 0; seekBy = 0
                if (boost) { boost = false; player.setPlaybackSpeed(preBoost); info.visibility = View.GONE }
            }
            true
        }
        (pv.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? TimeBar)?.addListener(object : TimeBar.OnScrubListener {
            override fun onScrubStart(timeBar: TimeBar, position: Long) { scrubBox.visibility = View.VISIBLE; scrubTo(position) }
            override fun onScrubMove(timeBar: TimeBar, position: Long) { scrubTo(position) }
            override fun onScrubStop(timeBar: TimeBar, position: Long, canceled: Boolean) { scrubBox.visibility = View.GONE }
        })
        subView.postDelayed(tick, 80)
    }

    /** Player banata hai. HW = default decoders, SW = sirf software decoders (na mile to default). */
    private fun start(index: Int, pos: Long) {
        val mode = curMode(index)                              // 0 HW, 1 HW+, 2 SW
        val sw = mode == 2
        val swAudio = AppSettings.SW_AUDIO.get(this)
        val defSync = AppSettings.SUB_SYNC.get(this) * 100L          // Settings > Subtitle > Default sync
        if (defSync != 0L) uris.indices.forEach { subDelay.putIfAbsent(it, defSync) }
        cueEvents.clear(); shown = emptyList(); lastCues = emptyList()
        audioDelay.delayMs = audDelay[index] ?: 0L
        val selector = MediaCodecSelector { mime, secure, tunnel ->
            val l = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
            if (sw && (swAudio || !mime.startsWith("audio/"))) l.filter { it.softwareOnly }.ifEmpty { l } else l
        }
        val rf = DelayRenderersFactory(this, if (audioDelayOn) audioDelay else null).setMediaCodecSelector(selector).setEnableDecoderFallback(true)
            .setExtensionRendererMode(if (mode == 1) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        // libass: ASS/SSA subtitles. Default CUES (purane subtitle pipeline ke saath poora compatible),
        // "Animated ASS" ON ho to overlay (animations / karaoke / moving text). Audio delay wala renderers factory wahi rehta hai.
        assViews.forEach { subView.removeView(it) }
        assViews = emptyList()
        val overlay = assOverlay()
        val childBefore = subView.childCount
        // Network: start playing after ~0.5 s of data (default waits 2.5 s). Local files are not affected.
        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 500, 1_500)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        player = ExoPlayer.Builder(this).setLoadControl(loadControl).buildWithAssSupport(
            context = this,
            renderType = if (overlay) AssRenderType.OVERLAY_OPEN_GL else AssRenderType.CUES,
            config = AssHandlerConfig(maxRenderPixels = if (overlay) 2_073_600 else 0),
            subtitleView = if (overlay) subView else null,
            renderersFactory = rf
        )
        assViews = (childBefore until subView.childCount).map { subView.getChildAt(it) }
        if (overlay && subOn()) subView.visibility = View.VISIBLE
        pv.player = player
        vDec = null; aDec = null
        player.addAnalyticsListener(object : AnalyticsListener {            // asli decoder ka naam yahin se pata chalta hai
            override fun onVideoDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String,
                                                   initializedTimestampMs: Long, initializationDurationMs: Long) { vDec = decoderName }
            override fun onAudioDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String,
                                                   initializedTimestampMs: Long, initializationDurationMs: Long) { aDec = decoderName }
        })
        player.setVideoFrameMetadataListener(VideoFrameMetadataListener { pts, _, _, _ -> lastPtsUs = pts })
        // pichli baar chuni hui audio / subtitle language agle episodes par bhi apne aap
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().apply {
            prefs.getString("pal", null)?.let { setPreferredAudioLanguage(it) }
            prefs.getString("ptl", null)?.let { setPreferredTextLanguage(it) }
        }.build()
        player.volume = if (muted) 0f else 1f
        // Bluetooth / earphones: audio focus (call, doosre apps), disconnect par auto-pause, headset buttons
        player.setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        player.setHandleAudioBecomingNoisy(true)
        player.repeatMode = prefs.getInt("rep", Player.REPEAT_MODE_OFF)
        player.shuffleModeEnabled = prefs.getBoolean("shuf", false)
        // Equalizer / LoudnessEnhancer take 100+ ms to create, so they are created only when EQ or boost is really on
        fxSession = player.audioSessionId; fx.release(); applyFx()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { fxSession = audioSessionId; if (fx.attached()) fx.attach(audioSessionId); applyFx() }
            override fun onIsPlayingChanged(isPlaying: Boolean) { syncSession() }
            override fun onPlaybackStateChanged(state: Int) { syncSession() }
            override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, reason: Int) {
                // video poora khatam hoke next par gaya -> "Watched" mark
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) o.mediaItem?.let { mark(it, o.positionMs, o.positionMs) }
                if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    cueEvents.clear(); shown = emptyList(); subView.setCues(emptyList())
                }
            }
            override fun onCues(cueGroup: CueGroup) {
                rawCues = cueGroup.cues
                lastCues = processCues(rawCues)
                // Keep the custom overlay visible whenever real cue data arrives.
                if (subOn()) subView.visibility = View.VISIBLE
                if (liveDelay() <= 0) { cueEvents.clear(); shown = lastCues; subView.setCues(lastCues) }
                else { cueEvents.add(player.currentPosition to lastCues); updateCues() }
            }
            override fun onTracksChanged(tracks: Tracks) {
                selectPendingExt(tracks)
                refreshCues()
            }
            override fun onVideoSizeChanged(vs: VideoSize) {
                if (manualOrient || AppSettings.ORIENT.get(this@PlayerActivity) != 0 || isInPictureInPictureMode || vs.width <= 0 || vs.height <= 0) return
                val w = vs.width * (if (vs.pixelWidthHeightRatio > 0f) vs.pixelWidthHeightRatio else 1f)
                val h = vs.height.toFloat()
                if (w == h) return
                requestedOrientation = if (h > w) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
            override fun onPlayerError(error: PlaybackException) { handleError(error) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                playBtn.setImageResource(if (playWhenReady) R.drawable.ic_pause else R.drawable.ic_play)
                if (!playWhenReady) save()          // pause par turant save: library me resume real-time dikhe
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                setTitleText(item?.mediaMetadata?.title)
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) pendingExt = -1
                manualOrient = false
                abA = -1L; abB = -1L
                resetZoom()
                player.currentMediaItemIndex.let { ci -> if (ext[ci] != null) { pendingExt = ci; subView.postDelayed(extTrackRetry, 450) } }
                applySpeed()
                audioDelay.delayMs = audDelay[player.currentMediaItemIndex] ?: 0L
            }
        })
        uris.indices.forEach { loadExt(it) }          // pehle add kiye hue subtitles wapas
        if (ext[index] != null) pendingExt = index
        if (netOnly()) player.setMediaSources(uris.indices.map { netFactory(it).createMediaSource(item(it)) }, index, pos)
        else player.setMediaItems(uris.indices.map { item(it) }, index, pos)
        applySpeed()
        player.pauseAtEndOfMediaItems = !prefs.getBoolean("auto", true)
        player.prepare()
        player.play()
        setupSession()
        setTitleText(player.currentMediaItem?.mediaMetadata?.title)
        playBtn.setImageResource(R.drawable.ic_pause)
        decBtn.text = AppSettings.DEC_NAMES[mode]
        applySubOnOff()
        bgAttach()
    }

    // ---------- decoder info (decBtn long-press) ----------
    private var vDec: String? = null
    private var aDec: String? = null

    private fun decKind(n: String?): String = when {
        n == null -> "not started yet"
        n.contains("ffmpeg", true) -> "FFmpeg, software"
        n.startsWith("c2.android.") || n.startsWith("OMX.google.") || n.startsWith("c2.google.") -> "software"
        else -> "hardware"
    }

    private fun showDecoderInfo() {
        val i = player.currentMediaItemIndex
        val vf = player.videoFormat
        val af = player.audioFormat
        val sb = StringBuilder()
        sb.append("Mode: ").append(AppSettings.DEC_NAMES[curMode(i)])
            .append(if (sessMode >= 0) " (switched after an error)" else "")
            .append("  \u00B7  ").append(if (isNet(i)) "network" else "local").append("\n\n")
        sb.append("Video: ").append(vf?.sampleMimeType ?: "-")
        if (vf != null && vf.width > 0) sb.append("  ").append(vf.width).append("x").append(vf.height)
        sb.append("\n").append(vDec ?: "-").append("  (").append(decKind(vDec)).append(")\n\n")
        sb.append("Audio: ").append(af?.sampleMimeType ?: "-")
        sb.append("\n").append(aDec ?: "-").append("  (").append(decKind(aDec)).append(")")
        AlertDialog.Builder(this, DLG).setTitle("Decoder in use").setMessage(sb.toString())
            .setPositiveButton("OK", null).show()
    }

    // ---------- error handling + auto fallback ----------
    private fun restartSoon() {
        pv.post {
            if (isDestroyed || isFinishing) return@post
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            player.release()
            start(i, p)
        }
    }

    private fun handleError(e: PlaybackException) {
        val c = e.errorCode
        val audioErr = c == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
            c == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
        val decErr = c == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            c == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            c == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
            c == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
        if (fallbacks < 3) {
            if (audioErr && audioDelayOn) {
                fallbacks++; audioDelayOn = false; audioDelay.delayMs = 0; audDelay.clear()
                show("Audio delay band (error)"); restartSoon(); return
            }
            if (audioErr) {                                         // e.g. Bluetooth / earphone switched output: one clean restart
                fallbacks++; show("Audio output changed, retrying"); restartSoon(); return
            }
            if (decErr) {                                           // chain: HW -> HW+ -> SW  ya  HW+ -> HW -> SW
                val cur = curMode(player.currentMediaItemIndex)
                triedModes.add(cur)
                val next = when (cur) {
                    0 -> if (AppSettings.TRY_HWPLUS.get(this) && 1 !in triedModes) 1 else if (2 !in triedModes) 2 else -1
                    1 -> if (AppSettings.TRY_HW.get(this) && 0 !in triedModes) 0 else if (2 !in triedModes) 2 else -1
                    else -> -1
                }
                if (next >= 0) {
                    fallbacks++; sessMode = next
                    show("Try next decoder: " + AppSettings.DEC_NAMES[next]); restartSoon(); return
                }
            }
        }
        if (isFinishing) return
        AlertDialog.Builder(this, DLG).setTitle("Playback error")
            .setMessage(friendly(e) + "\n\n(" + e.errorCodeName + ")")
            .setPositiveButton("Retry") { _, _ -> restartSoon() }
            .setNegativeButton("Close", null).show()
    }

    private fun item(k: Int) = MediaItem.Builder().setUri(uris[k]).apply {
        mimes?.getOrNull(k)?.takeIf { it.isNotBlank() }?.let { setMimeType(it) }   // extension-less HLS/DASH link
    }.setMediaMetadata(
        MediaMetadata.Builder().setTitle(names?.getOrNull(k) ?: Uri.parse(uris[k]).lastPathSegment ?: "Video").build()
    ).apply {
        subs[k]?.let {
            setSubtitleConfigurations(listOf(it))
            // IMPORTANT: Media3 1.4.1 me ProgressiveMediaSource.canUpdateMediaItem() sirf uri / customCacheKey
            // compare karta hai (subtitle config nahi). Isliye replaceMediaItem() same video par subtitle ko
            // chupchaap ignore kar deta tha -> track kabhi bana hi nahi. Har subtitle build par alag cache key
            // dene se source naya banta hai aur subtitle sach me load hota hai.
            setCustomCacheKey(uris[k] + "#sub-" + it.id + "-" + (ext[k]?.cur?.name ?: ""))
        }
    }.build()

    // ---------- right side panel: helpers ----------
    private fun fillSide(title: String?, v: List<View>, back: (() -> Unit)? = null) {
        sideBody.removeAllViews()
        if (title != null) sideBody.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(14))
            if (back != null) addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_back); setPadding(dp(11), dp(11), dp(11), dp(11)); contentDescription = "Back"
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) }
                setOnClickListener { back() }
            })
            addView(TextView(context).apply {
                text = title; setTextColor(Color.WHITE); textSize = if (back != null) 21f else 26f; typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_close); setPadding(dp(12), dp(12), dp(12), dp(12))
                setBackgroundResource(R.drawable.circle_btn); contentDescription = "Close"
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
                setOnClickListener { closeSide() }
            })
        })
        v.forEach { sideBody.addView(it) }
    }

    private fun openSide(title: String?, back: (() -> Unit)? = null, tag: String? = null, build: () -> List<View>) {
        sideTag = tag
        sideRebuild = { fillSide(title, build(), back) }
        fillSide(title, build(), back)
        sidePanel.scrollTo(0, 0)
        val w = minOf(dp(340), (resources.displayMetrics.widthPixels * 0.88f).toInt())
        sidePanel.layoutParams = sidePanel.layoutParams.apply { width = w }
        if (!sideOpen) {
            sideOpen = true
            pv.hideController()
            sideWrap.visibility = View.VISIBLE
            sidePanel.translationX = w.toFloat()
            sidePanel.animate().translationX(0f).setDuration(180).start()
        }
    }

    /** Panel ko wahin dobara banata hai (scroll yaad rakhta hai), jaise slider values refresh karne ke liye. */
    private fun reopenSide() {
        if (!sideOpen) return
        val y = sidePanel.scrollY
        sideRebuild?.invoke()
        sidePanel.post { sidePanel.scrollTo(0, y) }
    }

    private fun closeSide() {
        refreshRailState()
        dlg?.dismiss()
        resumeFromSub()
        if (!sideOpen) return
        sideOpen = false
        sidePanel.animate().translationX(sidePanel.width.toFloat()).setDuration(160)
            .withEndAction { if (!sideOpen) sideWrap.visibility = View.GONE }.start()
    }

    @Deprecated("Deprecated in Java")
    private var lastBackAt = 0L
    override fun onBackPressed() {
        if (sideOpen) closeSide()
        else if (AppSettings.DBL_BACK.get(this) && SystemClock.uptimeMillis() - lastBackAt > 2000L) {
            lastBackAt = SystemClock.uptimeMillis(); show("Press back again to close")
        } else super.onBackPressed()
    }

    private fun icon(res: Int) = ImageView(this).apply {
        setImageResource(res)
        setPadding(dp(9), dp(9), dp(9), dp(9))
        setBackgroundResource(R.drawable.icon_tile_bg)
        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(14) }
    }

    private fun chevron() = ImageView(this).apply {
        setImageResource(R.drawable.ic_chevron); alpha = 0.45f; setColorFilter(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
    }

    private fun tintSwitch(s: Switch) {
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, 0xFFC4C4D2.toInt()))
        s.trackTintList = ColorStateList(st, intArrayOf(acc(), 0x55FFFFFF))
    }

    private fun modernBar(s: SeekBar) {
        s.progressTintList = ColorStateList.valueOf(acc())
        s.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        s.progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
    }

    /** Icon + text wali row (tap = action). */
    private fun srow(ic: Int?, t: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        minimumHeight = dp(56)
        setBackgroundResource(R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        if (ic != null) addView(icon(ic))
        addView(TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 16.5f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        addView(chevron())
        setOnClickListener { f() }
    }

    /** Collapsible row (header par tap = khulo/band, haalat prefs me yaad rehti hai). */
    private fun fold(t: String, key: String, openDef: Boolean, ic: Int?, vararg v: View): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, 0, dp(4)); v.forEach { addView(it) }
        }
        val caret = TextView(this).apply { setTextColor(acc()); textSize = 11f }
        val hdr = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(14), dp(10))
            setBackgroundResource(R.drawable.row_bg)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
            if (ic != null) addView(icon(ic))
            addView(TextView(context).apply {
                text = t; setTextColor(Color.WHITE); textSize = 16.5f; typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(caret)
        }
        val upd = {
            val open = prefs.getBoolean("sf_$key", openDef)
            body.visibility = if (open) View.VISIBLE else View.GONE
            caret.text = if (open) "\u25B2" else "\u25BC"
        }
        upd()
        hdr.setOnClickListener { prefs.edit().putBoolean("sf_$key", !prefs.getBoolean("sf_$key", openDef)).apply(); upd() }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(hdr); addView(body) }
    }

    /** Checkbox row. */
    private fun crow(t: String, get: () -> Boolean, set: (Boolean) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6))
        val cb = CheckBox(context).apply {
            isChecked = get(); buttonTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(acc(), 0xFFB4B4C6.toInt()))
            setOnCheckedChangeListener { _, c -> set(c) }
        }
        addView(cb)
        addView(TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(6), dp(6), 0, dp(6))
            setOnClickListener { cb.toggle() }
        })
    }

    /** ON/OFF switch row. */
    private fun trow(t: String, get: () -> Boolean, set: (Boolean) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(6))
        addView(TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 17f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val sw = Switch(context).apply { isChecked = get(); tintSwitch(this); setOnCheckedChangeListener { _, c -> set(c) } }
        addView(sw)
        setOnClickListener { sw.toggle() }
    }

    /** Subtitle panel ka bada ON/OFF card: icon tile + title + live status + switch. */
    private fun subToggleCard(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(16), dp(12))
        setBackgroundResource(R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        addView(icon(R.drawable.ic_cc))
        val status = TextView(context).apply { textSize = 12.5f; setPadding(0, dp(2), 0, 0) }
        val upd = { on: Boolean ->
            status.text = if (on) "On  \u00B7  shown on video" else "Off  \u00B7  hidden"
            status.setTextColor(if (on) acc() else 0xFF9A9AAE.toInt())
        }
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(TextView(context).apply { text = "Subtitles"; setTextColor(Color.WHITE); textSize = 16.5f; typeface = Typeface.DEFAULT_BOLD })
            addView(status)
        })
        upd(subOn())
        val sw = Switch(context).apply {
            isChecked = subOn(); tintSwitch(this)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("son", c).apply(); applySubOnOff(); upd(c) }
        }
        addView(sw)
        setOnClickListener { sw.toggle() }
    }

    /** 3-dot menu ka round icon + label. */
    private fun cell(ic: Int, label: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(8), 0, dp(8))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        addView(ImageView(context).apply {
            setImageResource(ic); setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundResource(R.drawable.tile_sq_bg)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        })
        addView(TextView(context).apply {
            text = label; setTextColor(0xFFE2E2EC.toInt()); textSize = 12.5f; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0)
            minLines = 2; maxLines = 2
        })
        setOnClickListener { f() }
    }

    /** Titled rounded card that groups related settings in a side panel. */
    private fun settingCard(title: String?, vararg v: View): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(12))
        setBackgroundResource(R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        if (title != null) addView(TextView(context).apply {
            text = title; setTextColor(acc()); textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
            setPadding(0, 0, 0, dp(6))
        })
        v.forEach { addView(it) }
    }

    private fun presetRow(items: List<Pair<String, () -> Unit>>, selected: Int = -1): View = LinearLayout(this).apply {
        items.forEachIndexed { i, (n, f) ->
            addView(btn(n) { f() }.apply {
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
                gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
                setBackgroundResource(if (i == selected) R.drawable.tab_sel_bg else R.drawable.chip_bg)
            })
        }
    }

    // ---------- 3-dot menu (icon grid + toggles) ----------
    private fun moreMenu(): Unit = openSide("Quick settings") {
        val cells = ArrayList<View>()
        fun add(ic: Int, label: String, f: () -> Unit) { cells += cell(ic, label, f) }
        add(R.drawable.ic_queue, "Playing\nQueue") { closeSide(); queue() }
        add(R.drawable.ic_aspect, "Aspect\nRatio") {
            mode = (mode + 1) % 3; pv.resizeMode = modes[mode]; closeSide(); show(aspectNames[mode])
        }
        add(R.drawable.ic_display, "Display\nSettings") { displayPage() }
        add(R.drawable.ic_cc, "Subtitle") { subtitlePage() }
        add(R.drawable.ic_audio, "Audio\nTracks") { audioPage() }
        add(R.drawable.ic_speed, "Speed") { speedPage() }
        add(R.drawable.ic_tune, "Playback") { playbackPage() }
        add(R.drawable.ic_volume, "Sound") { soundPage() }
        add(R.drawable.ic_info, "Video properties") { closeSide(); showProps() }
        add(R.drawable.ic_share, "Share") { closeSide(); curUri()?.let { ShareSheet.show(this, listOf(it)) } }
        add(R.drawable.ic_camera, "Screenshot") { closeSide(); screenshot() }
        add(R.drawable.ic_pip, "Picture in\nPicture") { closeSide(); pip() }
        add(R.drawable.ic_power, "Quit") { finish() }
        val out = ArrayList<View>()
        cells.chunked(4).forEach { r ->
            out += LinearLayout(this).apply {
                r.forEach { addView(it) }
                repeat(4 - r.size) { addView(View(context).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }) }
            }
        }
        out += trow("Night mode", { night() }) { on -> setNight(on) }
        out += trow("Shortcuts", { prefs.getBoolean("rail_on", true) }) { on ->
            prefs.edit().putBoolean("rail_on", on).apply(); applyRailVisible()
        }
        out += trow("Auto-play next", { prefs.getBoolean("auto", true) }) { on ->
            prefs.edit().putBoolean("auto", on).apply(); player.pauseAtEndOfMediaItems = !on
        }
        out += trow("Animated ASS (libass)", { assOverlay() }) { on ->
            if (on != assOverlay()) {
                prefs.edit().putBoolean("ass_anim", on).apply()
                val i = player.currentMediaItemIndex
                val p = player.currentPosition
                player.release()
                start(i, p)
                closeSide()
                show(if (on) "Animated ASS ON" else "Animated ASS OFF")
            }
        }
        out
    }

    private fun applyRailVisible() { railWrap.visibility = if (prefs.getBoolean("rail_on", true)) View.VISIBLE else View.GONE }

    // ---------- subtitle panel ----------
    private var subPaused = false

    /** Subtitle panel khulte hi video pause; subtitle select hone / panel band hone par resume. */
    private fun pauseForSub() { if (!subPaused && player.playWhenReady) { subPaused = true; player.pause() } }
    private fun resumeFromSub() { if (subPaused) { subPaused = false; player.play() } }

    private fun sectionLabel(t: String) = TextView(this).apply {
        text = t; setTextColor(acc()); textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
        setPadding(dp(4), dp(14), 0, dp(8))
    }

    private fun subLink(t: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(13), dp(12), dp(13))
        addView(TextView(context).apply { text = t; setTextColor(Color.WHITE); textSize = 16f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        addView(chevron())
        setOnClickListener { f() }
    }

    private fun chip(label: String, f: () -> Unit): View = btn(label, f).apply {
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
        gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
        setBackgroundResource(R.drawable.chip_bg)
    }

    /** Video ke andar bane (embedded) subtitles: list + select. External files "Open" me. */
    private fun embeddedSubRows(): List<View> {
        val gs = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        val emb = gs.withIndex().filter { !isExtFormat(it.value.getTrackFormat(0)) }
        if (emb.isEmpty()) return emptyList()
        val sel = if (!subOn()) -1 else gs.indexOfFirst { it.isSelected }
        val out = ArrayList<View>()
        out += sectionLabel("BUILT-IN SUBTITLES  \u00B7  ${emb.size}")
        for ((k, g) in emb) {
            val f = g.getTrackFormat(0)
            val lang = langName(f.language)
            val lbl = f.label?.takeIf { it.isNotBlank() && !it.equals(lang, true) }
            val name = listOfNotNull(lang, lbl).joinToString(" \u00B7 ").ifEmpty { subLabel(g, k) }
            out += fileRow(name, null, null, k == sel, "\u2713  ") { chooseSubTrack(gs, k); closeSide() }
        }
        return out
    }

    /** Subtitle (main) page: Open + collapsible Settings. */
    private fun subtitlePage() {
        pauseForSub()
        openSide("Subtitle") {
            listOf(
                selectedSubRow(),
                subToggleCard()
            ) + embeddedSubRows() + listOf(
                srow(R.drawable.ic_folder, "Open") { subOpenPage() },
                srow(R.drawable.ic_sync, "Auto sync") { autoSyncPage() },
                srow(R.drawable.ic_translate, "Translate") { translatePage() },
                fold("Settings", "subset", false, R.drawable.ic_gear,
                    subLink("Synchronization") { subSyncPage() },
                    subLink("Speed") { subSpeedPage() },
                    crow("Panel", { prefs.getBoolean("swon", false) }) { on -> prefs.edit().putBoolean("swon", on).apply(); applySub() },
                    subLink("Customization") { customPage() })
            )
        }
    }

    /** "Open": embedded tracks + chune hue folder ki saari subtitle files. Select karte hi video resume. */
    private fun subOpenPage() {
        pauseForSub()
        val tree = prefs.getString("sub_tree", null)
        openSide("Subtitles", { subtitlePage() }) {
            val rows = ArrayList<View>()
            rows.addAll(subTrackRows())
            rows.add(sectionLabel(if (tree != null) "FILES  \u00B7  " + folderLabel(tree) else "SUBTITLE FILES"))
            if (tree == null) {
                rows.add(srow(R.drawable.ic_folder, "Select subtitle folder") { pickFolder(3) })
            } else {
                val files = listFolder(tree, setOf("srt", "vtt", "ass", "ssa", "ttml", "dfxp", "xml"))
                if (files == null) {
                    rows.add(TextView(this).apply { text = "Folder not accessible. Select it again."; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(6), dp(8), dp(6), dp(8)) })
                } else {
                    val base = videoBaseName()
                    fun isMatch(n: String) = base.isNotEmpty() && n.substringBeforeLast('.').lowercase(Locale.ROOT).let { x -> x == base || x.startsWith(base) || base.startsWith(x) }
                    val sorted = files.sortedByDescending { isMatch(it.name) }
                    if (sorted.isEmpty()) rows.add(TextView(this).apply { text = "No subtitle files in this folder"; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(6), dp(8), dp(6), dp(8)) })
                    sorted.forEach { fe ->
                        val match = isMatch(fe.name)
                        rows.add(fileRow(fe.name, fe.name.substringAfterLast('.', "").uppercase(Locale.ROOT), if (fe.size > 0) "${fe.size / 1024} KB" else null, match, "\u2605 ") {
                            loadSubUri(fe.uri); closeSide()
                        })
                    }
                }
                rows.add(srow(R.drawable.ic_folder, "Change folder") { pickFolder(3) })
            }
            rows.add(srow(R.drawable.ic_open, "Open a single file") { pickFile(1) })
            if (ext[player.currentMediaItemIndex] != null)
                rows.add(srow(R.drawable.ic_close, "Remove added subtitle") { removeExt(player.currentMediaItemIndex); closeSide() })
            rows
        }
    }

    private fun subSyncPage() {
        pauseForSub()
        openSide("Synchronization", { subtitlePage() }) {
            listOf(
                TextView(this).apply {
                    text = "External subtitle files can be shifted earlier or later. Embedded tracks support a later (+) delay only."
                    setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(2), dp(4), dp(10))
                },
                accentButton("Auto sync (awaaz se)") { autoSyncPage() }.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) } },
                delayRow("Subtitle delay", { subDelay[player.currentMediaItemIndex] ?: 0L }) { setSubDelay(it) }
            )
        }
    }

    private fun subSpeedPage() {
        pauseForSub()
        openSide("Speed", { subtitlePage() }) {
            val k = player.currentMediaItemIndex
            val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(4), dp(8), 0, dp(10)) }
            val upd = { tv.text = "Subtitle speed: " + String.format(Locale.US, "%.3fx", subSpeed[k] ?: 1.0) }
            upd()
            fun sp(label: String, v: Double) = chip(label) { setSubSpeed(v); upd() }
            listOf(
                TextView(this).apply {
                    text = "Stretches or shrinks subtitle timing (for example a 23.976 vs 25 fps mismatch). Works only on added (external) subtitles."
                    setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(2), dp(4), dp(10))
                },
                tv,
                LinearLayout(this).apply {
                    addView(sp("0.959x", 23.976 / 25.0)); addView(sp("0.99x", 0.99)); addView(sp("1.00x", 1.0))
                    addView(sp("1.01x", 1.01)); addView(sp("1.043x", 25.0 / 23.976))
                }
            )
        }
    }

    private fun setSubSpeed(v: Double) {
        val k = player.currentMediaItemIndex
        if (ext[k] == null) { show("Speed works only on added (external) subtitles"); return }
        subSpeed[k] = v
        reloadIdx = k
        subView.removeCallbacks(reloadSub)
        subView.postDelayed(reloadSub, 600)
        show("Sub speed " + String.format(Locale.US, "%.3fx", v))
    }

    // ---------- subtitle auto sync (awaaz se timing match) ----------
    private fun reopenIf(tag: String) { if (sideOpen && sideTag == tag) reopenSide() }

    private fun note(t: String) = TextView(this).apply {
        text = t; setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(2), dp(4), dp(10))
    }

    private fun statusCard(t: String, hold: (TextView) -> Unit): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(4), 0, dp(4)); setSingleLine(false); text = t }
        hold(tv)
        return settingCard("STATUS", tv)
    }

    private fun autoSyncPage() {
        pauseForSub()
        val k = player.currentMediaItemIndex
        if (!syncBusy && syncText.isEmpty()) syncText = if (ext[k] != null) "Starting..." else "Add an external subtitle file first for auto sync (Subtitle > Open)."
        openSide("Auto sync", { subtitlePage() }, "autosync") {
            listOf(
                note("Matches the speech in the video to the subtitle timing: both delay and speed (fps mismatch) are fixed automatically. Works on added (external) subtitles. No internet needed."),
                statusCard(syncText) { syncTv = it },
                if (syncBusy) accentButton("Cancel") { syncCancel = true }
                else accentButton("Run auto sync") { startAutoSync() },
                accentButton("Reset sync (delay 0, speed 1x)") { resetSync() }
            )
        }
        if (!syncBusy && ext[k] != null && syncText == "Starting...") startAutoSync()
    }

    private fun setSyncText(t: String) { syncText = t; syncTv?.text = t }

    private fun startAutoSync() {
        if (syncBusy) return
        val k = player.currentMediaItemIndex
        val e = ext[k]
        if (e == null) {
            setSyncText("Add an external subtitle file first for auto sync (Subtitle > Open). Embedded track timing is usually fine already.")
            reopenIf("autosync"); return
        }
        val ivs = SubParse.intervals(e.text, e.kind)
        if (ivs.size < 20) {
            setSyncText("Could not read timing from this subtitle (SRT, VTT and ASS are supported).")
            reopenIf("autosync"); return
        }
        syncBusy = true; syncCancel = false
        setSyncText("Analysing audio... 0%")
        reopenIf("autosync")
        val uri = uris[k]
        val dur = player.duration.let { if (it > 0) it else 0L }
        Thread {
            var res: AutoSync.Result? = null
            var err: String? = null
            try {
                res = AutoSync.run(applicationContext, uri, dur, ivs, { p ->
                    runOnUiThread { if (syncBusy) setSyncText("Analysing audio... $p%") }
                }, { syncCancel })
            } catch (f: AutoSync.Fail) { err = f.message }
            catch (x: Exception) { err = "Auto sync fail: " + (x.message ?: x.javaClass.simpleName) }
            catch (x: OutOfMemoryError) { err = "Not enough memory, auto sync failed." }
            val r = res
            val m = err
            runOnUiThread {
                syncBusy = false
                if (isDestroyed) return@runOnUiThread
                if (r != null && ext[k] === e) {
                    subDelay[k] = r.delayMs
                    subSpeed[k] = r.speed
                    reloadIdx = k
                    subView.removeCallbacks(reloadSub)
                    subView.postDelayed(reloadSub, 200)
                    setSyncText("\u2713 Synced: " + r.note + ". Not right? Fine-tune it under Synchronization or Reset.")
                    show("Auto sync: " + r.note)
                } else setSyncText(m ?: "Cancelled")
                reopenIf("autosync")
            }
        }.start()
    }

    private fun resetSync() {
        val k = player.currentMediaItemIndex
        subDelay[k] = 0L; subSpeed[k] = 1.0
        if (ext[k] != null) {
            reloadIdx = k
            subView.removeCallbacks(reloadSub)
            subView.postDelayed(reloadSub, 200)
        } else refreshCues()
        setSyncText("Reset ho gaya (delay 0, speed 1x).")
        reopenIf("autosync")
    }

    // ---------- subtitle translate ----------
    private fun trActive(): Boolean = ext[player.currentMediaItemIndex]?.useTr == true || prefs.getString("trlive", null) != null

    private fun trCurLang(): String? {
        val e = ext[player.currentMediaItemIndex]
        return if (e != null && e.useTr) e.trLang else prefs.getString("trlive", null)
    }

    private fun trStatus(): String {
        val e = ext[player.currentMediaItemIndex]
        if (e != null && e.useTr) return "Translated: " + (e.trName ?: "") + "  (subtitle file)"
        prefs.getString("trlive", null)?.let { return "Live translation ON: " + SubTranslate.langName(it) }
        return "Translation OFF. Neeche se language chuno."
    }

    private fun translatePage() {
        pauseForSub()
        if (!trBusy && trText.isEmpty()) trText = trStatus()
        openSide("Translate", { subtitlePage() }, "translate") {
            val rows = ArrayList<View>()
            rows.add(note("An added (external) subtitle is translated as a whole file (SRT / VTT / ASS) and remembered. Embedded text subtitles are translated live (original first, then the translation). With Animated ASS ON, an embedded ASS track is read from the video (MKV files on the phone) and translated as a full file, then used like an added subtitle. Internet needed."))
            rows.add(statusCard(trText) { trTv = it })
            if (trBusy) rows.add(accentButton("Cancel") { trCancel = true })
            else {
                if (trActive()) rows.add(accentButton("Stop translation (show original)") { stopTr() })
                rows.add(sectionLabel("TRANSLATE TO"))
                val cur = trCurLang()
                SubTranslate.LANGS.forEach { (name, code) -> rows.add(radioRow(name, code == cur) { startTr(name, code) }) }
            }
            rows
        }
    }

    private fun setTrText(t: String) { trText = t; trTv?.text = t }

    /** Online translation se pehle ek baar ijazat (subtitle text Google ko jata hai). true = dialog dikha diya, abhi ruko. */
    private fun needTrConsent(onOk: () -> Unit): Boolean {
        if (AppSettings.TR_CONSENT.get(this)) return false
        AlertDialog.Builder(this, DLG).setTitle("Online translation")
            .setMessage("Translate sends the subtitle text (not the video or audio) to Google's translation service over the internet. Google's privacy policy applies to that text.\n\nYou can turn this off any time in Settings > Privacy.")
            .setPositiveButton("Allow") { _, _ -> AppSettings.TR_CONSENT.set(this, true); onOk() }
            .setNegativeButton("Cancel", null).show()
        return true
    }

    private fun startTr(name: String, code: String) {
        if (trBusy) return
        if (needTrConsent { startTr(name, code) }) return
        val k = player.currentMediaItemIndex
        val e = ext[k]
        prefs.edit().putString("trlang", code).apply()
        trWarned = false
        if (e != null && extSelected()) {
            if (e.kind != "srt" && e.kind != "vtt" && e.kind != "ass") {
                setTrText("Translation is not supported for this subtitle format (SRT, VTT and ASS work).")
                reopenIf("translate"); return
            }
            trBusy = true; trCancel = false
            setTrText("Translating ($name)... 0%")
            reopenIf("translate")
            Thread {
                var out: String? = null
                var err: String? = null
                try {
                    out = SubTranslate.translateFile(e.text, e.kind, code, { p ->
                        runOnUiThread { if (trBusy) setTrText("Translating ($name)... $p%") }
                    }, { trCancel })
                } catch (x: SubTranslate.Err) { err = x.message }
                catch (x: Exception) { err = "Translate fail: " + (x.message ?: x.javaClass.simpleName) }
                catch (x: OutOfMemoryError) { err = "Not enough memory, translation failed." }
                val o = out
                val m = err
                runOnUiThread {
                    trBusy = false
                    if (isDestroyed) return@runOnUiThread
                    if (o != null && ext[k] === e) {
                        e.tr = o; e.trLang = code; e.trName = name; e.useTr = true
                        saveTr(k)
                        prefs.edit().remove("trlive").apply()
                        reloadItem(k)
                        setTrText("\u2713 Subtitle $name me translate ho gayi.")
                        show("Translated: $name")
                    } else setTrText(m ?: "Cancelled")
                    reopenIf("translate")
                }
            }.start()
        } else {
            // Animated ASS (libass overlay) me subtitle text cue nahi hota, live translate nahi chalta:
            // embedded ASS track ko MKV se nikaal ke poori file translate karo.
            if (assOverlay() && selectedEmbeddedText() != null && !uris[k].startsWith("http", true)) {
                startEmbeddedAssTr(name, code); return
            }
            prefs.edit().putString("trlive", code).apply()
            refreshTr()
            setTrText("Live translation ON: $name. Subtitle aate hi translate hoke dikhegi.")
            show("Live translate: $name")
            reopenIf("translate")
        }
    }

    /** Abhi selected embedded (non-external) text track ka Format. */
    private fun selectedEmbeddedText(): androidx.media3.common.Format? {
        for (g in player.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_TEXT || !g.isSelected) continue
            for (i in 0 until g.length) {
                if (g.isTrackSelected(i) && !isExtFormat(g.getTrackFormat(i))) return g.getTrackFormat(i)
            }
        }
        return null
    }

    /** Embedded ASS: MKV se track nikaalo, poori file translate karo, phir external ASS ki tarah laga do (animated bhi chalta hai). */
    private fun startEmbeddedAssTr(name: String, code: String) {
        val k = player.currentMediaItemIndex
        val ef = selectedEmbeddedText()
        val hId = ef?.id
        val hLang = ef?.language
        val hLabel = ef?.label
        val uriStr = uris[k]
        trBusy = true; trCancel = false
        setTrText("Reading subtitle from video... 0%")
        reopenIf("translate")
        Thread {
            var res: MkvSubs.Result? = null
            var out: String? = null
            var err: String? = null
            var noAss = false
            try {
                val r = MkvSubs.extract(this@PlayerActivity, uriStr, hId, hLang, hLabel, { p ->
                    runOnUiThread { if (trBusy) setTrText("Reading subtitle from video... $p%") }
                }, { trCancel })
                res = r
                out = SubTranslate.translateFile(r.text, "ass", code, { p ->
                    runOnUiThread { if (trBusy) setTrText("Translating ($name)... $p%") }
                }, { trCancel })
            } catch (x: MkvSubs.NoAss) { noAss = true }
            catch (x: MkvSubs.Err) { err = x.message }
            catch (x: SubTranslate.Err) { err = x.message }
            catch (x: Exception) { err = "Translate fail: " + (x.message ?: x.javaClass.simpleName) }
            catch (x: OutOfMemoryError) { err = "Not enough memory, translation failed." }
            val r2 = res
            val o = out
            val m = err
            val na = noAss
            runOnUiThread {
                trBusy = false
                if (isDestroyed) return@runOnUiThread
                if (r2 != null && o != null && player.currentMediaItemIndex == k) {
                    applyEmbeddedTr(k, r2, o, code, name)
                    setTrText("\u2713 Subtitle $name me translate ho gayi.")
                    show("Translated: $name")
                } else if (na) {
                    // ASS track nahi mila (ya selected track ASS nahi) -> pehle jaisa live translate
                    prefs.edit().putString("trlive", code).apply()
                    refreshTr()
                    setTrText("Live translation ON: $name. Subtitle aate hi translate hoke dikhegi.")
                    show("Live translate: $name")
                } else setTrText(m ?: "Cancelled")
                reopenIf("translate")
            }
        }.start()
    }

    private fun applyEmbeddedTr(k: Int, r: MkvSubs.Result, translated: String, code: String, name: String) {
        if (k < 0 || k >= player.mediaItemCount) return
        val p = player.currentPosition
        val playing = player.playWhenReady
        ext[k]?.cur?.delete()
        val e = ExtSub(r.text, "ass", MimeTypes.TEXT_SSA, r.name)
        e.tr = translated; e.trLang = code; e.trName = name; e.useTr = true
        ext[k] = e
        saveExt(k)
        saveTr(k)
        prefs.edit().remove("trlive").putBoolean("son", true).apply()
        pendingExt = k
        badgeAfterSelect = false
        buildExt(k)
        player.replaceMediaItem(k, item(k))
        player.seekTo(k, p)
        player.playWhenReady = playing
        applySubOnOff()
        subView.postDelayed(extTrackRetry, 450)
    }

    private fun stopTr() {
        val k = player.currentMediaItemIndex
        val e = ext[k]
        if (e != null && e.useTr) { e.useTr = false; saveTr(k); reloadItem(k) }
        prefs.edit().remove("trlive").apply()
        refreshTr()
        setTrText("Translation OFF (original subtitle).")
        reopenIf("translate")
    }

    // ---------- subtitles customization (MX-style) ----------
    private fun customPage() {
        pauseForSub()
        openSide("Subtitles Customization", { subtitlePage() }) { customization() }
    }

    private fun formRow(label: String, v: View): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4))
        addView(TextView(context).apply { text = label; setTextColor(0xFFBBBBCC.toInt()); textSize = 15f; layoutParams = LinearLayout.LayoutParams(dp(84), -2) })
        addView(v)
    }

    private fun dropdown(opts: List<String>, sel: Int, on: (Int) -> Unit): View = TextView(this).apply {
        text = opts[sel.coerceIn(opts.indices)] + "  \u25BE"; setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(6), dp(8), dp(6), dp(8))
        setOnClickListener {
            val pm = android.widget.PopupMenu(context, this)
            opts.forEachIndexed { i, o -> pm.menu.add(0, i, i, o) }
            pm.setOnMenuItemClickListener { mi -> on(mi.itemId); text = opts[mi.itemId] + "  \u25BE"; true }
            pm.show()
        }
    }

    private fun sliderRow(label: String, lo: Int, hi: Int, k: String, d: Int, suffix: String): View {
        val cur = prefs.getInt(k, d).coerceIn(lo, hi)
        val value = TextView(this).apply { text = "$cur$suffix"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.END; minWidth = dp(54) }
        val seek = SeekBar(this).apply { modernBar(this)
            max = hi - lo; progress = cur - lo
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    if (!u) return
                    prefs.edit().putInt(k, p + lo).apply(); value.text = "${p + lo}$suffix"; applySub()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6))
            addView(TextView(context).apply { text = label; setTextColor(0xFFBBBBCC.toInt()); textSize = 15f; layoutParams = LinearLayout.LayoutParams(dp(78), -2) })
            addView(seek); addView(value)
        }
    }

    private fun swatch(k: String, def: Int, withAlpha: Boolean): View = View(this).apply {
        fun paint() { background = GradientDrawable().apply { setColor(prefs.getInt(k, def)); cornerRadius = dp(6).toFloat(); setStroke(dp(1), 0x88FFFFFF.toInt()) } }
        paint()
        layoutParams = LinearLayout.LayoutParams(dp(54), dp(30)).apply { marginStart = dp(10) }
        setOnClickListener { colorDialog(k, def, withAlpha) { paint(); applySub() } }
    }

    private fun checkSwatch(label: String, kOn: String, kCol: String, defCol: Int, defOn: Boolean = false): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(crow(label, { prefs.getBoolean(kOn, defOn) }) { on -> prefs.edit().putBoolean(kOn, on).apply(); applySub() })
        addView(swatch(kCol, defCol, true))
    }

    private fun colorDialog(k: String, def: Int, withAlpha: Boolean, done: () -> Unit) {
        dlg?.dismiss()
        var cur = prefs.getInt(k, def)
        val palette = longArrayOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFFFFC107, 0xFFFF9800, 0xFFFF5252, 0xFFFF4081,
            0xFFE040FB, 0xFF7C4DFF, 0xFF448AFF, 0xFF40C4FF, 0xFF18FFFF, 0xFF69F0AE,
            0xFF76FF03, 0xFF22FF22, 0xFFBDBDBD, 0xFF616161, 0xFF212121, 0xFF000000).map { it.toInt() }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun draw() {
            grid.removeAllViews()
            palette.chunked(6).forEach { row ->
                grid.addView(LinearLayout(this).apply {
                    row.forEach { c ->
                        val on = (cur and 0xFFFFFF) == (c and 0xFFFFFF)
                        addView(View(context).apply {
                            background = GradientDrawable().apply {
                                shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(if (on) 3 else 1), if (on) Color.WHITE else 0x55FFFFFF)
                            }
                            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
                            setOnClickListener {
                                cur = (cur and 0xFF000000.toInt()) or (c and 0xFFFFFF)
                                if (!withAlpha) cur = cur or 0xFF000000.toInt()
                                prefs.edit().putInt(k, cur).apply(); done(); draw()
                            }
                        })
                    }
                })
            }
        }
        draw()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(8))
            addView(dialogHeader("Color")); addView(grid)
            if (withAlpha) {
                val al = (cur ushr 24) and 0xFF
                val tv = TextView(context).apply { text = "Opacity: ${al * 100 / 255}%"; setTextColor(Color.WHITE); textSize = 14f; setPadding(0, dp(10), 0, 0) }
                addView(tv)
                addView(SeekBar(context).apply { modernBar(this)
                    max = 95; progress = (al * 100 / 255 - 5).coerceIn(0, 95)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                            if (!u) return
                            val a = (p + 5) * 255 / 100
                            cur = (a shl 24) or (cur and 0xFFFFFF)
                            tv.text = "Opacity: ${p + 5}%"
                            prefs.edit().putInt(k, cur).apply(); done()
                        }
                        override fun onStartTrackingTouch(s: SeekBar) {}
                        override fun onStopTrackingTouch(s: SeekBar) {}
                    })
                })
            }
        }
        dlg = AlertDialog.Builder(this, DLG).setView(box).setPositiveButton("OK", null).create().also { it.show() }
    }

    private fun customization(): List<View> {
        fun head(t: String) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(2), dp(16), 0, dp(8))
        }
        val out = ArrayList<View>()
        out.add(subPreviewBox())
        out.add(head("Layout"))
        out.add(formRow("Alignment", dropdown(listOf("Left", "Center", "Right"), prefs.getInt("salign", 1)) { prefs.edit().putInt("salign", it).apply(); applySub() }))
        out.add(sliderRow("Bottom margins", 0, 40, "spos", 8, ""))
        out.add(checkSwatch("Background", "swon", "swc", 0x99000000.toInt()))
        out.add(crow("Fit subtitles into video size", { prefs.getBoolean("sfit", true) }) { on -> prefs.edit().putBoolean("sfit", on).apply(); applySub() })
        out.add(head("Text"))
        out.add(formRow("Font", TextView(this).apply {
            text = fontName() + "  \u25BE"; setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(6), dp(8), dp(6), dp(8)); setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END; tf?.let { typeface = it }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { fontDialog() }
        }))
        out.add(sliderRow("Size", 10, 60, "ss", 20, ""))
        out.add(sliderRow("Scale", 50, 400, "ssc", 100, "%"))
        out.add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4))
            addView(TextView(context).apply { text = "Color"; setTextColor(0xFFBBBBCC.toInt()); textSize = 15f; layoutParams = LinearLayout.LayoutParams(dp(84), -2) })
            addView(swatch("sc", Color.WHITE, false))
            addView(crow("Bold", { prefs.getBoolean("sbold", false) }) { on -> prefs.edit().putBoolean("sbold", on).apply(); applySub() }.apply { setPadding(dp(14), 0, 0, 0) })
        })
        out.add(checkSwatch("Background Color", "sb", "sbc", 0xAA000000.toInt()))
        out.add(checkSwatch("Border", "sbd", "sec", Color.BLACK, true))
        out.add(fold("Advanced", "subadv", false, null,
            sliderRow("Opacity", 20, 100, "sop", 100, "%"),
            presetRow(listOf("Classic" to intArrayOf(Color.WHITE, 0, 20), "Yellow" to intArrayOf(0xFFFFEB3B.toInt(), 0, 22),
                "Box" to intArrayOf(Color.WHITE, 1, 20), "Big" to intArrayOf(0xFFFFEB3B.toInt(), 1, 30)).map { (n, v) ->
                n to {
                    prefs.edit().putInt("sc", v[0]).putBoolean("sb", v[1] == 1).putInt("ss", v[2]).putInt("ssc", 100).apply()
                    applySub(); show("$n style"); reopenSide()
                }
            }),
            TextView(this).apply {
                text = "Note: ASS/SSA subtitles use their own style, font and position; these settings apply to SRT/VTT only."
                setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(6), dp(4), dp(10))
            }))
        return out
    }

    // ---------- other panels ----------
    // ---------- audio panel: sirf audio tracks (Hindi / English / Japanese ...) + unke beech switch ----------
    private var audioPick = -1

    private val langNames = mapOf(
        "hin" to "Hindi", "eng" to "English", "jpn" to "Japanese", "kor" to "Korean", "chi" to "Chinese", "zho" to "Chinese",
        "spa" to "Spanish", "fre" to "French", "fra" to "French", "ger" to "German", "deu" to "German", "tam" to "Tamil",
        "tel" to "Telugu", "ben" to "Bengali", "rus" to "Russian", "por" to "Portuguese", "ita" to "Italian", "ara" to "Arabic",
        "tha" to "Thai", "ind" to "Indonesian", "mar" to "Marathi", "mal" to "Malayalam", "kan" to "Kannada", "urd" to "Urdu"
    )

    /** "jpn" / "ja" -> "Japanese". Samajh na aaye to None. */
    private fun langName(code: String?): String? {
        val c = code?.trim()?.lowercase(Locale.ROOT) ?: return null
        if (c.isEmpty() || c == "und" || c == "zxx") return null
        langNames[c]?.let { return it }
        return try {
            Locale.forLanguageTag(c).getDisplayLanguage(Locale.ENGLISH).takeIf { it.isNotBlank() && !it.equals(c, true) } ?: c.uppercase(Locale.ROOT)
        } catch (e: Exception) { c.uppercase(Locale.ROOT) }
    }

    private fun audioLabel(f: androidx.media3.common.Format, n: Int): String {
        val lang = langName(f.language)
        val lbl = f.label?.takeIf { it.isNotBlank() && !it.equals(lang, true) }
        val title = listOfNotNull(lang, lbl).joinToString(" \u00B7 ").ifEmpty { "Audio ${n + 1}" }
        val ch = when (f.channelCount) {
            androidx.media3.common.Format.NO_VALUE, 0 -> null
            1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"
            else -> "${f.channelCount}ch"
        }
        val m = (f.sampleMimeType ?: "").lowercase(Locale.ROOT)
        val codec = when {
            "eac3" in m -> "E-AC3"; "ac3" in m -> "AC3"; "ac4" in m || "ac-4" in m -> "AC4"
            "truehd" in m -> "TrueHD"; "dts" in m -> "DTS"; "opus" in m -> "Opus"; "vorbis" in m -> "Vorbis"
            "flac" in m -> "FLAC"; "mp4a" in m || "aac" in m -> "AAC"; "mpeg" in m || "mp3" in m -> "MP3"
            else -> null
        }
        val extra = listOfNotNull(ch, codec).joinToString(" \u00B7 ")
        return if (extra.isEmpty()) title else "$title\n$extra"
    }

    private fun audioRows(): List<View> {
        val gs = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
        if (gs.isEmpty()) return listOf(TextView(this).apply {
            text = "No audio tracks found in this video."
            setTextColor(0xFFBBBBCC.toInt()); textSize = 14f; setPadding(dp(8), dp(12), dp(8), dp(12))
        })
        val cur = if (audioPick in gs.indices) audioPick else gs.indexOfFirst { it.isSelected }
        val out = ArrayList<View>()
        out += sectionLabel("${gs.size} AUDIO TRACK" + if (gs.size > 1) "S" else "")
        gs.forEachIndexed { n, g ->
            out += fileRow(audioLabel(g.getTrackFormat(0), n), if (g.isSupported) null else "Unsupported", null, n == cur, "\u2713  ") { chooseAudio(gs, n) }
        }
        out += settingCard("SYNC", delayRow("Audio delay", { audDelay[player.currentMediaItemIndex] ?: 0L }) { setAudDelay(it) })
        out += TextView(this).apply {
            text = (if (gs.size == 1) "This video has only one audio track.\n" else "") + "Equalizer and volume boost are in Quick settings \u2192 Sound."
            setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(6), dp(4), dp(10))
        }
        return out
    }

    private fun chooseAudio(gs: List<Tracks.Group>, k: Int) {
        val g = gs[k]
        if (!g.isSupported) { show("This audio format is not supported on this phone"); return }
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
            .addOverride(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
        g.getTrackFormat(0).language?.let { prefs.edit().putString("pal", it).apply() }
        audioPick = k
        reopenSide()
    }

    private fun audioPage() { audioPick = -1; openSide("Audio") { audioRows() } }

    /** Quick settings ke "Sound" tile ka page: Equalizer + volume boost. Audio delay audio panel me hai. */
    private fun soundPage(): Unit = openSide("Sound", { moreMenu() }) {
        listOf(
            srow(R.drawable.ic_tune, "Equalizer") { eqPage { soundPage() } },
            settingCard("VOLUME BOOST",
                bar("Boost (dB)", 0, 15, "vb", 0) { applyFx() },
                TextView(this).apply {
                    text = "Too much boost can distort the sound and may harm your ears or earphones. Raise it slowly."
                    setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(2), dp(4), dp(6))
                })
        )
    }

    // ---------- equalizer + volume boost ----------
    private val fx = AudioFx()

    private var fxSession = 0
    private fun fxNeeded() = prefs.getBoolean("eqon", false) || prefs.getInt("vb", 0) > 0
    private fun ensureFx() { if (!fx.attached() && fxSession != 0) fx.attach(fxSession) }

    private fun applyFx() {
        if (!fx.attached()) { if (!fxNeeded()) return; ensureFx() }
        val n = fx.bands()
        fx.apply(prefs.getBoolean("eqon", false), IntArray(n) { prefs.getInt("eqb$it", 0) }, prefs.getInt("vb", 0))
    }

    private fun hzLabel(hz: Int) = if (hz >= 1000) String.format(Locale.US, "%.1f kHz", hz / 1000f) else "$hz Hz"

    private fun setEqPreset(name: String, n: Int, minDb: Int, maxDb: Int) {
        val e = prefs.edit()
        for (i in 0 until n) {
            val f = if (n <= 1) 0f else i / (n - 1f)
            val w = when (name) {
                "Bass" -> maxOf(0f, 0.8f * (1f - 2f * f))
                "Treble" -> maxOf(0f, 0.8f * (2f * f - 1f))
                "Vocal" -> 0.6f * (1f - kotlin.math.abs(2f * f - 1f))
                else -> 0f
            }
            e.putInt("eqb$i", Math.round(w * maxDb).coerceIn(minDb, maxDb))
        }
        e.putBoolean("eqon", name != "Flat").apply()
        applyFx(); reopenSide()
    }

    private fun eqPage(back: (() -> Unit)? = null): Unit = openSide("Equalizer", back) {
        ensureFx()
        val n = fx.bands()
        if (n == 0) listOf(TextView(this).apply {
            text = "Equalizer is not available on this phone."
            setTextColor(0xFFBBBBCC.toInt()); textSize = 14f; setPadding(dp(8), dp(12), dp(8), dp(12))
        }) else {
            val (lo, hi) = fx.rangeMb()
            val minDb = maxOf(lo / 100, -15)
            val maxDb = minOf(hi / 100, 15)
            listOf(
                crow("Equalizer", { prefs.getBoolean("eqon", false) }) { on -> prefs.edit().putBoolean("eqon", on).apply(); applyFx() },
                settingCard("PRESETS", presetRow(listOf("Flat", "Bass", "Vocal", "Treble").map { nm -> nm to { setEqPreset(nm, n, minDb, maxDb) } }))
            ) + (0 until n).map { i -> bar(hzLabel(fx.freqHz(i)) + " (dB)", minDb, maxDb, "eqb$i", 0) { applyFx() } }
        }
    }

    private fun sleepPage() = openSide("Sleep timer") { listOf(sleepRow()) }

    private fun speedPage() = openSide("Speed") {
        val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val curSp = prefs.getFloat(spdKey(player.currentMediaItemIndex), defSpeed())
        listOf(presetRow(speeds.map { sp -> "${sp}x" to { setSpeed(sp); reopenSide() } }, speeds.indexOfFirst { it == curSp }))
    }

    private fun updateSkipLabel() {
        val n = AppSettings.SKIP_S.get(this)
        backBtnView?.text = "+" + n + "s"
    }

    private fun playbackPage() = openSide("Playback") {
        listOf(
            settingCard("AUTO-PLAY", autoSwitch()),
            settingCard("REPEAT", repeatBtn(), toggle("Shuffle", "shuf") { player.shuffleModeEnabled = prefs.getBoolean("shuf", false) }),
            settingCard("SLEEP TIMER", sleepRow()),
            settingCard("A-B REPEAT", abRow()),
            settingCard("SKIP BUTTON", bar("Skip button (seconds)", 5, 180, "skipS", 85) { updateSkipLabel() }),
            srow(R.drawable.ic_queue, "Queue / Playlist") { closeSide(); queue() }
        )
    }

    private fun displayPage() = openSide("Display") {
        listOf(
            settingCard("NIGHT MODE",
                toggle("Night mode (warm + dim)", "night") { applyEnh(); syncNightUi() },
                bar("Strength %", 10, 100, "nightLvl", 60) { applyEnh() }),
            settingCard("PRESETS", presetRow(listOf("Normal" to intArrayOf(0, 100, 100, 0), "Vivid" to intArrayOf(0, 110, 130, 15),
                "Anime" to intArrayOf(4, 115, 145, 35), "Cinema" to intArrayOf(-6, 112, 88, 0)).map { (n, v) -> n to { setEnh(v[0], v[1], v[2], v[3]) } })),
            settingCard("ADJUST",
                bar("Brightness", -50, 50, "eb", 0) { applyEnh() },
                bar("Contrast %", 50, 150, "ec", 100) { applyEnh() },
                bar("Saturation %", 0, 300, "es", 100) { applyEnh() },
                if (Build.VERSION.SDK_INT >= 33) bar("Sharpness", 0, 100, "esh", 0) { applyEnh() }
                else TextView(this).apply {
                    text = "Sharpness: needs Android 13 or above"
                    setTextColor(0xFFBBBBCC.toInt()); textSize = 12f; setPadding(dp(4), dp(8), dp(4), dp(8))
                })
        )
    }

    private fun curUri(): Uri? = player.currentMediaItem?.localConfiguration?.uri

    private fun showProps() {
        val u = curUri() ?: return
        Thread {
            val t = VideoInfo.describe(this, u)
            runOnUiThread { AlertDialog.Builder(this, DLG).setTitle("Video properties").setMessage(t).setPositiveButton("OK", null).show() }
        }.start()
    }

    /** Repeat: Off -> This video -> All videos. */
    private fun repeatBtn(): View = btn("") {}.also { v ->
        val upd = {
            v.text = "Repeat: " + when (player.repeatMode) {
                Player.REPEAT_MODE_ONE -> "This video"
                Player.REPEAT_MODE_ALL -> "All videos"
                else -> "Off"
            }
        }
        upd()
        v.setOnClickListener {
            val next = when (player.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                else -> Player.REPEAT_MODE_OFF
            }
            player.repeatMode = next
            prefs.edit().putInt("rep", next).apply()
            upd()
        }
    }

    private fun autoSwitch(): View = btn("") {}.also { v ->
        val upd = { v.text = "Auto-play next episode: " + if (prefs.getBoolean("auto", true)) "ON" else "OFF" }
        upd()
        v.setOnClickListener {
            prefs.edit().putBoolean("auto", !prefs.getBoolean("auto", true)).apply()
            player.pauseAtEndOfMediaItems = !prefs.getBoolean("auto", true)
            upd()
        }
    }

    private fun setSleep(min: Int) {
        subView.removeCallbacks(sleepRun)
        if (min == 0) { sleepAt = 0L; show("Sleep timer off"); return }
        sleepAt = System.currentTimeMillis() + min * 60_000L
        subView.postDelayed(sleepRun, min * 60_000L)
        show("Sleep timer $min min")
    }

    private fun sleepRow(): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = {
            tv.text = "Sleep timer: " + if (sleepAt == 0L) "Off" else "${(sleepAt - System.currentTimeMillis()) / 60_000 + 1} min left"
        }
        upd()
        val row = LinearLayout(this)
        listOf("Off" to 0, "15m" to 15, "30m" to 30, "45m" to 45, "60m" to 60, "90m" to 90).forEach { (l, m) ->
            row.addView(btn(l) { setSleep(m); upd() }.apply {
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
                gravity = Gravity.CENTER; textSize = 12f; setPadding(dp(2), dp(10), dp(2), dp(10))
                setBackgroundResource(R.drawable.chip_bg)
            })
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row) }
    }

    // ---------- screenshot (video frame, Pictures/NextGenPlay me) ----------
    private fun screenshot() {
        val tv = pv.videoSurfaceView as? TextureView
        val bm: Bitmap? = try { tv?.bitmap } catch (e: Exception) { null }
        if (bm == null) { show("Could not take screenshot"); return }
        Thread {
            val ok = try { saveShot(bm) } catch (e: Exception) { false }
            runOnUiThread { show(if (ok) "Screenshot saved" else "Screenshot error") }
        }.start()
    }

    private fun saveShot(bm: Bitmap): Boolean {
        val name = "NextGenPlay_" + System.currentTimeMillis() + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NextGenPlay")
            }
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            contentResolver.openOutputStream(u)?.use { bm.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return true
        }
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return false
        File(dir, name).outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return true
    }

    /** Collapsible section: header par tap = khulo/band. Haalat prefs me yaad rehti hai. */
    private fun section(title: String, key: String, openDefault: Boolean, vararg v: View): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0); v.forEach { addView(it) }
        }
        val hdr = TextView(this).apply {
            setTextColor(0xFF8B7CFF.toInt()); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(12))
        }
        val upd = {
            val open = prefs.getBoolean("sec_$key", openDefault)
            body.visibility = if (open) View.VISIBLE else View.GONE
            hdr.text = (if (open) "\u25BE  " else "\u25B8  ") + title
        }
        upd()
        hdr.setOnClickListener {
            prefs.edit().putBoolean("sec_$key", !prefs.getBoolean("sec_$key", openDefault)).apply(); upd()
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(hdr); addView(body) }
    }

    private fun fmtDelay(ms: Long) = (if (ms > 0) "+" else "") + String.format(Locale.US, "%.1f s", ms / 1000.0)

    /** MX Player jaisa delay control: -1s  -0.1s  +0.1s  +1s  Reset */
    private fun delayRow(t: String, cur: () -> Long, set: (Long) -> Unit): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = { tv.text = "$t: " + fmtDelay(cur()) }
        upd()
        fun chip(label: String, d: Long?) = btn(label) { set(if (d == null) 0L else cur() + d); upd() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
            setBackgroundResource(R.drawable.chip_bg)
        }
        val row = LinearLayout(this).apply {
            addView(chip("-1s", -1000)); addView(chip("-0.1", -100)); addView(chip("+0.1", 100))
            addView(chip("+1s", 1000)); addView(chip("Reset", null))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row)
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    /** Theme ka accent colour (ThemeActivity me chuna hua). */
    private fun acc(): Int { val tv = TypedValue(); theme.resolveAttribute(R.attr.appAccent, tv, true); return tv.data }

    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f
        setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { f() }
    }

    private fun toggle(t: String, k: String, on: () -> Unit) = btn("") {}.also { v ->
        val upd = { v.text = t + ": " + if (prefs.getBoolean(k, false)) "ON" else "OFF" }
        upd()
        v.setOnClickListener { prefs.edit().putBoolean(k, !prefs.getBoolean(k, false)).apply(); upd(); on() }
    }

    private fun bar(t: String, lo: Int, hi: Int, k: String, d: Int, on: () -> Unit): View {
        val cur = prefs.getInt(k, d)
        val tv = TextView(this).apply { setTextColor(Color.WHITE); text = "$t: $cur" }
        val seek = SeekBar(this).apply { modernBar(this)
            max = hi - lo; progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    if (!u) return
                    prefs.edit().putInt(k, p + lo).apply(); tv.text = "$t: ${p + lo}"; on()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)); addView(tv); addView(seek)
        }
    }

    private fun panel(t: String, vararg v: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)); v.forEach { addView(it) }
        }
        dlg = AlertDialog.Builder(this, DLG).setTitle(t).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK", null).show()
        dlg?.window?.setDimAmount(0.15f)
    }

    // ---------- selected subtitle name + saved external subtitle (per video) ----------
    private fun currentSubName(): String {
        if (!subOn()) return "Off"
        val k = player.currentMediaItemIndex
        val g = player.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_TEXT && it.isSelected }
        if (g == null) return ext[k]?.let { it.name + " (loading\u2026)" } ?: "None"
        val f = g.getTrackFormat(0)
        if (isExtFormat(f)) {
            val e = ext[k]
            return (e?.name ?: (f.label ?: "External")) + (if (e != null && e.useTr) "  \u00B7  " + (e.trName ?: "translated") else "")
        }
        return listOfNotNull(f.label, f.language).distinct().joinToString(" \u00B7 ").ifEmpty { "Embedded track" } +
            (prefs.getString("trlive", null)?.let { "  \u00B7  " + SubTranslate.langName(it) } ?: "")
    }

    private fun selectedSubRow(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
        background = resources.getDrawable(R.drawable.info_bg, theme)
        addView(TextView(context).apply { text = "Selected subtitle"; setTextColor(0xFFBBBBCC.toInt()); textSize = 13f })
        addView(TextView(context).apply {
            text = currentSubName(); setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setSingleLine(false)       // poora naam, wrap hoke
        })
    }

    private fun subKey(k: Int): String =
        java.security.MessageDigest.getInstance("SHA-1").digest(uris[k].toByteArray()).joinToString("") { "%02x".format(it) }.take(24)

    private fun subFile(k: Int) = File(File(filesDir, "subs").apply { mkdirs() }, subKey(k) + ".sub")

    /** Added subtitle ko is video ke liye save karo, taaki player band hone ke baad dobara add na karna pade. */
    private fun saveExt(k: Int) {
        val e = ext[k] ?: return
        try {
            subFile(k).writeText(e.text, Charsets.UTF_8)
            prefs.edit().putString("xs_" + subKey(k), e.kind + "|" + e.mime + "|" + e.name).apply()
        } catch (_: Exception) {}
    }

    private fun trFile(k: Int) = File(subFile(k).parentFile, subKey(k) + ".tr")

    /** Translate ki hui subtitle file is video ke liye save (dobara translate na karna pade). */
    private fun saveTr(k: Int) {
        val e = ext[k] ?: return
        val t = e.tr
        try {
            if (t == null) { clearTr(k); return }
            trFile(k).writeText(t, Charsets.UTF_8)
            prefs.edit().putString("xt_" + subKey(k), (e.trLang ?: "") + "|" + (e.trName ?: "") + "|" + (if (e.useTr) "1" else "0")).apply()
        } catch (_: Exception) {}
    }

    private fun clearTr(k: Int) {
        try { trFile(k).delete() } catch (_: Exception) {}
        prefs.edit().remove("xt_" + subKey(k)).apply()
    }

    private fun loadExt(k: Int) {
        if (ext[k] != null) return
        val v = prefs.getString("xs_" + subKey(k), null) ?: return
        val f = subFile(k)
        if (!f.exists()) return
        try {
            val p = v.split("|", limit = 3)
            val e = ExtSub(f.readText(Charsets.UTF_8), p[0], p[1], p.getOrElse(2) { "Subtitle" })
            val tv = prefs.getString("xt_" + subKey(k), null)
            val tf = trFile(k)
            if (tv != null && tf.exists()) {
                val q = tv.split("|", limit = 3)
                e.tr = tf.readText(Charsets.UTF_8)
                e.trLang = q[0]
                e.trName = q.getOrElse(1) { q[0] }
                e.useTr = q.getOrElse(2) { "1" } == "1"
            }
            ext[k] = e
            buildExt(k)
        } catch (_: Exception) { ext.remove(k); subs.remove(k) }
    }

    private fun removeExt(k: Int) {
        ext.remove(k)?.cur?.delete()
        subs.remove(k); subDelay.remove(k); pendingExt = -1
        subFile(k).delete(); prefs.edit().remove("xs_" + subKey(k)).apply()
        clearTr(k)
        val p = player.currentPosition; val pl = player.playWhenReady
        player.replaceMediaItem(k, item(k))
        player.seekTo(k, p); player.playWhenReady = pl
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).build()
        lastCues = emptyList(); shown = emptyList(); subView.setCues(emptyList())
        show("Subtitle removed")
    }

    // ---------- subtitles ----------
    private fun subOn() = prefs.getBoolean("son", true)

    /** Animated ASS (libass overlay) ON/OFF. OFF = CUES (static, purana pipeline). */
    private fun assOverlay() = prefs.getBoolean("ass_anim", false)

    /** Subtitle ON/OFF: text track disable + view hide. */
    private fun applySubOnOff() {
        val on = subOn()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !on).build()
        syncSubUi()
    }

    private fun syncSubUi() {
        val on = subOn()
        subView.visibility = if (on) View.VISIBLE else View.GONE
        ccBtn.alpha = if (on) 1f else 0.4f
        if (!on) subView.setCues(emptyList())
    }

    // ---- subtitle delay ----
    private fun isExtFormat(f: androidx.media3.common.Format): Boolean =
        f.id == "ext" || f.id == ASS_EXT_ID || f.label == "External" || f.id?.startsWith("ext-") == true ||
            (f.label != null && f.label == ext[player.currentMediaItemIndex]?.name)

    private fun extSelected() = player.currentTracks.groups.any {
        it.type == C.TRACK_TYPE_TEXT && it.isSelected && isExtFormat(it.getTrackFormat(0))
    }

    /** Nayi external file ke baad uska track hi select karo (warna mkv ka embedded track / purana override jeet jata tha). */
    private fun selectPendingExt(tracks: Tracks) {
        if (pendingExt < 0 || pendingExt != player.currentMediaItemIndex) return
        // Do not accidentally select an embedded subtitle group reported from the previous
        // item. First wait for the replacement item's external track to appear.
        val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 && it.isSupported }
        val g = textGroups.firstOrNull { group ->
            (0 until group.length).any { isExtFormat(group.getTrackFormat(it)) }
        }
        if (g == null) {
            // Media3 may publish tracks before the replacement media item is prepared.
            subView.removeCallbacks(extTrackRetry)
            subView.postDelayed(extTrackRetry, 350)
            return
        }
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .addOverride(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
        pendingExt = -1
        prefs.edit().putBoolean("son", true).apply()
        subView.visibility = View.VISIBLE
        syncSubUi()
        if (badgeAfterSelect) { badgeAfterSelect = false; subView.postDelayed({ showBadge() }, 200) }
    }

    private val extTrackRetry = Runnable {
        if (pendingExt >= 0 && pendingExt == player.currentMediaItemIndex && ::player.isInitialized) {
            selectPendingExt(player.currentTracks)
        }
    }

    /** Live delay sirf embedded subtitle par (external file ka time file me hi badal dete hain). */
    private fun liveDelay(): Long = if (extSelected()) 0L else (subDelay[player.currentMediaItemIndex] ?: 0L)

    /**
     * Ek saath kai log bolein to same position wale text cues alag-alag ek ke upar chhap jate the (overlap).
     * Ab same position wale cues ek cue me upar-neeche (line by line) jod dete hain. Alag \\pos / \\an8 wale cues alag rehte hain.
     */
    private fun stackCues(cues: List<Cue>): List<Cue> {
        if (cues.size < 2) return cues
        val out = ArrayList<Cue>()
        val groups = LinkedHashMap<String, MutableList<Cue>>()
        for (c in cues) {
            if (c.bitmap != null || c.text == null) { out.add(c); continue }
            // Same jagah ke saare cues ek hi box me upar-neeche (alag alag position / alignment wale bhi), taaki ek doosre par overlap na ho.
            // Default (neeche) wale sab ek group; explicit line wale (top / beech) apni line ke hisaab se.
            val key = if (c.verticalType != Cue.TYPE_UNSET) "v|${c.verticalType}|${c.line}"
                else if (c.line == Cue.DIMEN_UNSET) "bottom" else "${c.lineType}|${c.lineAnchor}|${c.line}"
            groups.getOrPut(key) { ArrayList() }.add(c)
        }
        for (g in groups.values) {
            if (g.size == 1) { out.add(g[0]); continue }
            val sb = android.text.SpannableStringBuilder()
            val seen = HashSet<String>()
            for (c in g) {
                val t = c.text ?: continue
                if (!seen.add(t.toString())) continue          // bilkul same line do baar na dikhe
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t)
            }
            out.add(g[0].buildUpon().setText(sb).build())
        }
        return out
    }

    private fun processCues(c: List<Cue>): List<Cue> = ltrCues(italicCues(alignCues(stackCues(trCues(c)))))

    /** Settings > Subtitle > Italic effect: "/" se shuru hone wali line italic (slash hat jata hai). */
    private fun italicCues(cues: List<Cue>): List<Cue> {
        if (!AppSettings.SUB_ITALIC.get(this)) return cues
        return cues.map { c ->
            val t = c.text
            if (c.bitmap != null || t == null || t.indexOf('/') < 0) c
            else {
                val sb = android.text.SpannableStringBuilder(t)
                var i = 0
                var changed = false
                while (i < sb.length) {
                    val nl = sb.indexOf("\n", i)
                    val end = if (nl < 0) sb.length else nl
                    if (end > i && sb[i] == '/') {
                        sb.delete(i, i + 1)
                        val e2 = end - 1
                        if (e2 > i) sb.setSpan(android.text.style.StyleSpan(Typeface.ITALIC), i, e2, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        changed = true
                        i = e2 + 1
                    } else i = end + 1
                }
                if (changed) c.buildUpon().setText(sb).build() else c
            }
        }
    }

    /** Settings > Subtitle > Force LTR: har line ko LTR embedding me lapet do (Arabic / Urdu ke punctuation sahi side par). */
    private fun ltrCues(cues: List<Cue>): List<Cue> {
        if (!AppSettings.SUB_LTR.get(this)) return cues
        return cues.map { c ->
            val t = c.text
            if (c.bitmap != null || t == null) c
            else {
                val sb = android.text.SpannableStringBuilder(t)
                var end = sb.length
                while (true) {
                    val st = sb.lastIndexOf('\n', end - 1) + 1
                    sb.insert(end, "\u202C")
                    sb.insert(st, "\u202A")
                    if (st == 0) break
                    end = st - 1
                }
                c.buildUpon().setText(sb).build()
            }
        }
    }

    /**
     * Live translation (embedded text subtitle ke liye): cue ka text translate hoke aata hai.
     * Jab tak translation na aaye original dikhta hai. Added (external) subtitle file poori translate hoti hai, uspar ye nahi lagta.
     */
    private fun trCues(cues: List<Cue>): List<Cue> {
        val lang = prefs.getString("trlive", null) ?: return cues
        if (!AppSettings.TR_CONSENT.get(this)) return cues
        if (::player.isInitialized && ext[player.currentMediaItemIndex]?.useTr == true && extSelected()) return cues
        return cues.map { c ->
            val t = c.text
            if (c.bitmap != null || t == null) c
            else {
                val key = t.toString().replace("\n", " ").trim()
                if (key.isEmpty()) c
                else {
                    val hit = trCache[lang + "|" + key]
                    if (hit != null) c.buildUpon().setText(hit).build()
                    else { requestTr(key, lang); c }
                }
            }
        }
    }

    private fun requestTr(key: String, lang: String) {
        if (!AppSettings.TR_CONSENT.get(this)) return
        val ck = lang + "|" + key
        if (!trPending.add(ck)) return
        trPool.execute {
            val r = try { SubTranslate.translateAll(listOf(key), lang, { }, { false }).firstOrNull() } catch (e: Exception) { null }
            runOnUiThread {
                trPending.remove(ck)
                if (isDestroyed) return@runOnUiThread
                if (r != null && r.isNotBlank()) {
                    if (trCache.size > 3000) trCache.clear()
                    trCache[ck] = r
                    if (prefs.getString("trlive", null) == lang) { lastCues = processCues(rawCues); refreshCues() }
                } else if (!trWarned) {
                    trWarned = true
                    show("Could not translate (check internet)")
                }
            }
        }
    }

    private fun refreshTr() {
        if (!::player.isInitialized) return
        lastCues = processCues(rawCues)
        refreshCues()
    }

    /** Subtitle alignment (Left / Center / Right) - Customization se. */
    private fun alignCues(cues: List<Cue>): List<Cue> {
        val al = prefs.getInt("salign", 1)
        if (al == 1) return cues
        return cues.map { c ->
            if (c.bitmap != null || c.text == null) c
            else if (al == 0) c.buildUpon().setTextAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
                .setPosition(0.04f).setPositionAnchor(Cue.ANCHOR_TYPE_START).build()
            else c.buildUpon().setTextAlignment(android.text.Layout.Alignment.ALIGN_OPPOSITE)
                .setPosition(0.96f).setPositionAnchor(Cue.ANCHOR_TYPE_END).build()
        }
    }

    private fun updateCues() {
        val d = liveDelay()
        if (d <= 0 || cueEvents.isEmpty()) return
        val p = player.currentPosition - d
        var best: List<Cue> = emptyList()
        var n = 0
        for ((i, e) in cueEvents.withIndex()) { if (e.first <= p) { best = e.second; n = i } else break }
        repeat(n) { cueEvents.removeAt(0) }
        if (best !== shown) { shown = best; subView.setCues(best) }
    }

    private fun refreshCues() {
        if (liveDelay() <= 0) { cueEvents.clear(); shown = lastCues; subView.setCues(lastCues) }
        else { if (cueEvents.isEmpty()) cueEvents.add(player.currentPosition to lastCues); updateCues() }
    }

    private fun setSubDelay(v: Long) {
        val k = player.currentMediaItemIndex
        val d = v.coerceIn(-60_000L, 60_000L)
        subDelay[k] = d
        if (ext[k] != null) {                       // external file: re-time karke reload (debounced)
            reloadIdx = k
            subView.removeCallbacks(reloadSub)
            subView.postDelayed(reloadSub, 600)
        } else if (d < 0) {
            show("Embedded sub: only + delay")
            return
        }
        refreshCues()
        show("Sub delay " + fmtDelay(d) + if (ext[k] == null && assOverlay() && d != 0L) "  (animated ASS: delay does not work on embedded ASS)" else "")
    }

    private fun setAudDelay(v: Long) {
        val k = player.currentMediaItemIndex
        val d = v.coerceIn(-10_000L, 10_000L)
        audDelay[k] = d
        audioDelay.delayMs = d
        if (AppSettings.REM_ADELAY.get(this)) {
            prefs.edit().apply { if (d == 0L) remove("ad_" + subKey(k)) else putLong("ad_" + subKey(k), d) }.apply()
        }
        if (d != 0L && !audioDelayOn) {            // pehli baar: player naye audio chain ke saath dobara banta hai
            audioDelayOn = true
            restartSoon()
            show("Audio delay " + fmtDelay(d))
            return
        }
        info.removeCallbacks(flushAudio)
        info.postDelayed(flushAudio, 500)          // thoda ruk ke seek: purana buffered audio flush hoke naya delay lagta hai
        show("Audio delay " + fmtDelay(d))
    }

    private fun reloadItem(k: Int) {
        if (k < 0 || k >= player.mediaItemCount) return
        if (k == player.currentMediaItemIndex && (extSelected() || pendingExt == k)) pendingExt = k
        buildExt(k)
        val p = player.currentPosition
        val playing = player.playWhenReady
        player.replaceMediaItem(k, item(k))
        player.seekTo(k, p)
        player.playWhenReady = playing
    }

    private val tsRe = Regex("""((?:\d+:)?\d+:\d{2}[,.]\d{1,3})(\s*-->\s*)((?:\d+:)?\d+:\d{2}[,.]\d{1,3})""")
    private val tsPart = Regex("""(?:(\d+):)?(\d+):(\d{2})[,.](\d{1,3})""")
    private val assRe = Regex("""^(\s*Dialogue:[^,]*,)(\d+:\d{2}:\d{2}[.:]\d{1,2}),(\d+:\d{2}:\d{2}[.:]\d{1,2})(,.*)$""")
    private val assPart = Regex("""(\d+):(\d{2}):(\d{2})[.:](\d{1,2})""")

    private fun parseTs(s: String): Long {
        val m = tsPart.matchEntire(s.trim()) ?: return 0
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        return ((h * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(3, '0').toLong()
    }

    private fun fmtTs(ms: Long, comma: Boolean): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d:%02d%s%03d", t / 3600000, t / 60000 % 60, t / 1000 % 60,
            if (comma) "," else ".", t % 1000)
    }

    private fun parseAss(s: String): Long {
        val m = assPart.matchEntire(s.trim()) ?: return 0
        return ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(2, '0').toLong() * 10
    }

    private fun fmtAss(ms: Long): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d:%02d.%02d", t / 3600000, t / 60000 % 60, t / 1000 % 60, t % 1000 / 10)
    }

    /** Subtitle text ke saare timestamps ms se shift karta hai (srt / vtt / ass). */
    private fun shiftSub(text: String, kind: String, ms: Long, speed: Double = 1.0): String {
        if (ms == 0L && speed == 1.0) return text
        val sc = { x: Long -> (x * speed).toLong() + ms }
        if (kind == "ttml") return text // Preserve XML time expressions.
        return if (kind == "ass") {
            text.lines().joinToString("\n") { line ->
                assRe.matchEntire(line)?.let { m ->
                    m.groupValues[1] + fmtAss(sc(parseAss(m.groupValues[2]))) + "," +
                        fmtAss(sc(parseAss(m.groupValues[3]))) + m.groupValues[4]
                } ?: line
            }
        } else {
            tsRe.replace(text) { m ->
                fmtTs(sc(parseTs(m.groupValues[1])), kind == "srt") + m.groupValues[2] +
                    fmtTs(sc(parseTs(m.groupValues[3])), kind == "srt")
            }
        }
    }

    private fun decodeText(b: ByteArray): String {
        if (b.size >= 2 && ((b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) || (b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())))
            return String(b, Charsets.UTF_16).removePrefix("\uFEFF")
        AppSettings.SUB_ENC.get(this)?.let { n ->           // Settings > Subtitle > Character encoding
            try { return String(b, java.nio.charset.Charset.forName(n)).removePrefix("\uFEFF") } catch (e: Exception) { }
        }
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString().removePrefix("\uFEFF")
        } catch (e: Exception) {
            String(b, java.nio.charset.Charset.forName("windows-1252"))
        }
    }

    /** External subtitle ko current delay ke hisaab se re-time karke cache file + SubtitleConfiguration banata hai. */
    private fun buildExt(k: Int) {
        val e = ext[k] ?: return
        val tr = e.tr
        val out = shiftSub(if (e.useTr && tr != null) tr else e.text, e.kind, subDelay[k] ?: 0L, subSpeed[k] ?: 1.0)
        e.cur?.delete()
        val f = File(cacheDir, "sub_${k}_${System.nanoTime()}.${e.kind}")
        f.writeBytes(out.toByteArray(Charsets.UTF_8))
        e.cur = f
        subs[k] = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f)).setMimeType(e.mime)
            .setId(if (e.kind == "ass") ASS_EXT_ID else "ext").setLabel(e.name).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
    }

    private fun subTypeface(): Typeface? =
        if (prefs.getBoolean("sbold", false)) Typeface.create(tf ?: Typeface.DEFAULT, Typeface.BOLD) else tf

    private fun applySub() {
        val sv = subView
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt("ss", 20) * prefs.getInt("ssc", 100) / 100f)
        sv.setBottomPaddingFraction(prefs.getInt("spos", 8) / 100f)
        val a = (prefs.getInt("sop", 100).coerceIn(20, 100) * 255) / 100
        val fg = (prefs.getInt("sc", Color.WHITE) and 0x00FFFFFF) or (a shl 24)
        val bg = if (prefs.getBoolean("sb", false)) prefs.getInt("sbc", 0xAA000000.toInt()) else Color.TRANSPARENT
        val win = if (prefs.getBoolean("swon", false)) prefs.getInt("swc", 0x99000000.toInt()) else Color.TRANSPARENT
        val edgeType = if (prefs.getBoolean("sbd", true)) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE
        val edge = (prefs.getInt("sec", Color.BLACK) and 0x00FFFFFF) or (a shl 24)
        sv.setStyle(CaptionStyleCompat(fg, bg, win, edgeType, edge, subTypeface()))
        if (::player.isInitialized) { lastCues = processCues(rawCues); refreshCues() }
        layoutSubs()
        updatePreview()
    }

    /** Subtitle area: "Fit into video size" (video ke andar) + controls dikhne par upar uthna. */
    private var subLift = 0
    private fun layoutSubs() {
        var l = 0; var t = 0; var r = 0; var b = 0
        if (prefs.getBoolean("sfit", true) && zoom <= 1.01f) {
            val frame = pv.findViewById<View>(androidx.media3.ui.R.id.exo_content_frame)
            if (frame != null && frame.width > 0 && subView.width > 0) {
                val fl = IntArray(2); frame.getLocationInWindow(fl)
                val sl = IntArray(2); subView.getLocationInWindow(sl)
                l = (fl[0] - sl[0]).coerceAtLeast(0)
                t = (fl[1] - sl[1]).coerceAtLeast(0)
                r = ((sl[0] + subView.width) - (fl[0] + frame.width)).coerceAtLeast(0)
                b = ((sl[1] + subView.height) - (fl[1] + frame.height)).coerceAtLeast(0)
            }
        }
        // subLift = subtitle ke neeche ka edge view ke bottom se kitna door hona chahiye (controls ke upar). SubtitleView apna
        // "bottom margin" (spos %) alag se jodta hai, isliye lift ko usme se ghata kar padding nikalte hain: subtitle sirf utna
        // hi uthta hai jitna controls se bachne ke liye zaroori hai (pehle lift + margin dono jud jaate the = zyada upar).
        val h = subView.height.toFloat()
        val frac = prefs.getInt("spos", 8) / 100f
        var pb = b
        if (subLift > 0 && h > 0f) {
            val need = ((subLift - frac * (h - t)) / (1f - frac)).toInt()
            if (need > pb) pb = need
        }
        subView.setPadding(l, t, r, pb)
    }

    private var liftAnim: android.animation.ValueAnimator? = null
    /** Controls aate / jaate waqt subtitle jhatke se nahi, smooth upar-neeche jaata hai (controls ke fade ke saath). */
    private fun animLift(target: Int) {
        liftAnim?.cancel()
        if (!AppSettings.UI_ANIM.get(this) || subView.height == 0) { subLift = target; layoutSubs(); return }
        liftAnim = android.animation.ValueAnimator.ofInt(subLift, target).apply {
            duration = if (target > subLift) 160L else 220L
            addUpdateListener { subLift = it.animatedValue as Int; layoutSubs() }
            start()
        }
    }

    // ---------- live subtitle preview (Style tab) ----------
    private var subPreview: TextView? = null

    private fun updatePreview() {
        val tv = subPreview ?: return
        val a = (prefs.getInt("sop", 100).coerceIn(20, 100) * 255) / 100
        tv.setTextColor((prefs.getInt("sc", Color.WHITE) and 0x00FFFFFF) or (a shl 24))
        tv.textSize = (prefs.getInt("ss", 20) * prefs.getInt("ssc", 100) / 100f).coerceAtMost(34f)
        tv.setBackgroundColor(if (prefs.getBoolean("sb", false)) prefs.getInt("sbc", 0xAA000000.toInt()) else Color.TRANSPARENT)
        tv.typeface = subTypeface() ?: Typeface.DEFAULT
        if (prefs.getBoolean("sbd", true)) tv.setShadowLayer(4f, 0f, 1f, prefs.getInt("sec", Color.BLACK)) else tv.setShadowLayer(0f, 0f, 0f, 0)
    }

    private fun subPreviewBox(): View {
        val tv = TextView(this).apply {
            text = "I want to see more of this world."; gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        subPreview = tv
        updatePreview()
        return FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1B2A5A.toInt(), 0xFFD98A7A.toInt(), 0xFF2A2140.toInt())).apply { cornerRadius = dp(18).toFloat() }
            setPadding(dp(12), dp(36), dp(12), dp(18))
            layoutParams = LinearLayout.LayoutParams(-1, dp(120)).apply { bottomMargin = dp(12) }
            addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM))
        }
    }

    // ---------- fonts ----------
    private val sysFonts = listOf("Roboto Medium" to "sans-serif-medium", "Roboto Condensed" to "sans-serif-condensed",
        "Serif" to "serif", "Monospace" to "monospace", "Casual" to "casual", "Cursive" to "cursive")

    private fun fontMode() = prefs.getString("fm", null) ?: if (prefs.getString("sf", null) != null) "custom" else "def"

    private fun assetFontName(path: String) = path.substringAfterLast('/').substringBeforeLast('.')
        .replace('-', ' ').replace('_', ' ').removeSuffix(" Regular")

    private fun fontName(): String {
        val m = fontMode()
        return when {
            m.startsWith("sys:") -> sysFonts.firstOrNull { it.second == m.substring(4) }?.first ?: "System"
            m.startsWith("asset:") -> assetFontName(m.substring(6))
            m.startsWith("folder:") -> m.substring(7).substringBeforeLast('.')
            m == "custom" -> prefs.getString("sfn", null) ?: "Custom Font"
            else -> "Default"
        }
    }

    private fun loadFont() {
        val m = fontMode()
        tf = try {
            when {
                m.startsWith("sys:") -> Typeface.create(m.substring(4), Typeface.NORMAL)
                m.startsWith("asset:") -> Typeface.createFromAsset(assets, m.substring(6))
                m.startsWith("folder:") -> File(filesDir, "ffonts/" + m.substring(7)).takeIf { it.exists() }?.let { Typeface.createFromFile(it) }
                m == "custom" -> prefs.getString("sf", null)?.let { Typeface.createFromFile(it) }
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun setFontMode(m: String) {
        prefs.edit().putString("fm", m).apply()
        loadFont(); applySub(); reopenSide(); showBadge()
    }

    // ---------- popup helpers (radio list + accent button) ----------
    private fun radioRow(t: String, on: Boolean, f: () -> Unit) = RadioButton(this).apply {
        text = t; isChecked = on; setTextColor(Color.WHITE); textSize = 16f
        buttonTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(acc(), 0xFFB4B4C6.toInt()))
        setPadding(dp(8), dp(12), dp(8), dp(12)); setSingleLine(false)
        setOnClickListener { f() }
    }

    private fun accentButton(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(acc()); textSize = 15f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(14), dp(12), dp(14))
        background = GradientDrawable().apply {
            setColor((acc() and 0xFFFFFF) or 0x33000000); setStroke(dp(1), acc()); cornerRadius = dp(14).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        setOnClickListener { f() }
    }

    private fun listDialog(title: String, rows: List<View>, btnText: String, btn2Text: String? = null, onBtn2: (() -> Unit)? = null, rowDp: Int = 50, onBtn: () -> Unit) {
        dlg?.dismiss()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; rows.forEach { addView(it) } }
        val sc = ScrollView(this).apply { addView(list) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16))
            addView(dialogHeader(title))
            addView(sc, LinearLayout.LayoutParams(-1, minOf(rows.size * dp(rowDp), (resources.displayMetrics.heightPixels * 0.5f).toInt())))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(accentButton(btnText, onBtn).apply {
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(12) }
                })
                if (btn2Text != null && onBtn2 != null) addView(accentButton(btn2Text, onBtn2).apply {
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(12); marginStart = dp(10) }
                })
            })
        }
        dlg = AlertDialog.Builder(this, DLG).setView(box).create().also {
            it.show()
            it.window?.setLayout(minOf(dp(460), (resources.displayMetrics.widthPixels * 0.92f).toInt()), -2)
        }
    }

    /** Dialog title + close (X) button. */
    private fun dialogHeader(title: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(10))
        addView(TextView(context).apply {
            text = title; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_close); setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundResource(R.drawable.circle_btn); contentDescription = "Close"
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setOnClickListener { dlg?.dismiss() }
        })
    }

    /** Card row for files / queue items: name, optional badge + size; `best` = accent card. */
    private fun fileRow(name: String, badge: String?, size: String?, best: Boolean, mark: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundResource(if (best) R.drawable.card_sel_bg else R.drawable.row_bg)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        addView(TextView(context).apply {
            text = (if (best) mark else "") + name; setTextColor(Color.WHITE); textSize = 15f; setSingleLine(false)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        if (!badge.isNullOrEmpty()) addView(TextView(context).apply {
            text = badge; setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(3), dp(8), dp(3)); setBackgroundResource(R.drawable.chip_bg)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
        })
        if (!size.isNullOrEmpty()) addView(TextView(context).apply {
            text = size; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
        })
        setOnClickListener { f() }
    }

    private fun subLabel(g: Tracks.Group, n: Int): String {
        val f = g.getTrackFormat(0)
        if (isExtFormat(f)) return ext[player.currentMediaItemIndex]?.name ?: (f.label ?: "External")
        return listOfNotNull(f.label, f.language).distinct().joinToString(" \u00B7 ").ifEmpty { "Track ${n + 1}" }
    }

    /** Subtitle popup: None + saare tracks (radio) + "Load External Subtitle". */
    private fun chooseSubTrack(gs: List<Tracks.Group>, k: Int) {
        pendingExt = -1
        val tp = player.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, k < 0)
        if (k >= 0) tp.addOverride(TrackSelectionOverride(gs[k].mediaTrackGroup, 0))
        player.trackSelectionParameters = tp.build()
        if (k >= 0 && !isExtFormat(gs[k].getTrackFormat(0))) gs[k].getTrackFormat(0).language?.let { prefs.edit().putString("ptl", it).apply() }
        prefs.edit().putBoolean("son", k >= 0).apply(); syncSubUi()
        subView.postDelayed({ showBadge() }, 150)
    }

    /** Inline track list for the Tracks tab (replaces the separate Track popup). */
    private fun subTrackRows(): List<View> {
        val gs = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        val sel = if (!subOn()) -1 else gs.indexOfFirst { it.isSelected }
        val rows = ArrayList<View>()
        rows.add(TextView(this).apply {
            text = "AVAILABLE TRACKS"; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(10), 0, dp(8))
        })
        val after = { closeSide() }
        rows.add(fileRow("None", null, null, sel < 0, "\u2713  ") { chooseSubTrack(gs, -1); after() })
        gs.forEachIndexed { n, g -> rows.add(fileRow(subLabel(g, n), null, null, n == sel, "\u2713  ") { chooseSubTrack(gs, n); after() }) }
        return rows
    }

    /** Font popup: Default, system fonts, assets/fonts ki files, Custom Font + "Load Font File". */
    private class FontItem(val name: String, val source: String, val mode: String, var face: Typeface?, val uri: Uri? = null, val fsize: Long = 0L) { var loading = false }

    private fun fontItems(): List<FontItem> {
        val out = ArrayList<FontItem>()
        out.add(FontItem("Default", "Default", "def", null))
        sysFonts.forEach { (n, fam) ->
            out.add(FontItem(n, "System", "sys:$fam", try { Typeface.create(fam, Typeface.NORMAL) } catch (e: Exception) { null }))
        }
        (try { assets.list("fonts") } catch (e: Exception) { null } ?: emptyArray())
            .filter { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }.sorted().forEach { fn ->
                val path = "fonts/$fn"
                out.add(FontItem(assetFontName(path), "App", "asset:$path", try { Typeface.createFromAsset(assets, path) } catch (e: Exception) { null }))
            }
        val sf = prefs.getString("sf", null)
        if (sf != null && File(sf).exists())
            out.add(FontItem("Custom Font" + (prefs.getString("sfn", null)?.let { " ($it)" } ?: ""), "Custom", "custom",
                try { Typeface.createFromFile(sf) } catch (e: Exception) { null }))
        // chune hue font folder ke SAARE fonts (preview background me load hota hai)
        prefs.getString("font_tree", null)?.let { t ->
            listFolder(t, setOf("ttf", "otf", "ttc"))?.forEach { fe ->
                out.add(FontItem(fe.name.substringBeforeLast('.'), "Folder", "folder:" + fe.name, null, fe.uri, fe.size))
            }
        }
        return out
    }

    /** Font card: search + filter chips + every font shown in its own face. */
    private fun fontDialog() {
        dlg?.dismiss()
        val m = fontMode()
        val items = fontItems()
        var filter = if (items.any { it.source == "Folder" }) "Folder" else "All"
        var query = ""
        val loader = Executors.newFixedThreadPool(2)
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun renderList() {
            listBox.removeAllViews()
            val q = query.trim().lowercase(Locale.ROOT)
            val shown = items.filter { (filter == "All" || it.source == filter) && (q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q)) }
            if (shown.isEmpty()) listBox.addView(TextView(this).apply {
                text = "No fonts found"; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(8), dp(14), dp(8), dp(14))
            })
            shown.forEach { fi ->
                val on = fi.mode == m
                listBox.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(12))
                    setBackgroundResource(if (on) R.drawable.card_sel_bg else R.drawable.row_bg)
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                    addView(TextView(context).apply {
                        text = fi.name + "  \u00B7  " + fi.source + (if (on) "  \u2713" else "")
                        setTextColor(if (on) acc() else 0xFFBBBBCC.toInt()); textSize = 12f
                    })
                    addView(TextView(context).apply {
                        text = "Aa Bb Cc 123  The quick brown fox \u0905\u0906\u0907"
                        setTextColor(Color.WHITE); textSize = 20f; setSingleLine(false)
                        val sample = this
                        if (fi.face != null) typeface = fi.face
                        else if (fi.uri != null && !fi.loading) {
                            fi.loading = true
                            loader.execute {
                                val f = copyFont(fi.uri, fi.mode.removePrefix("folder:"), fi.fsize)
                                val face = try { f?.let { Typeface.createFromFile(it) } } catch (e: Exception) { null }
                                fi.face = face; fi.loading = false
                                if (face != null) runOnUiThread { if (!isFinishing) sample.typeface = face }
                            }
                        }
                    })
                    setOnClickListener { dlg?.dismiss(); if (fi.uri != null) selectFolderFont(fi) else setFontMode(fi.mode) }
                })
            }
        }

        fun renderChips() {
            chipRow.removeAllViews()
            (listOf("All") + items.map { it.source }.distinct().filter { it != "Default" }).forEach { n ->
                chipRow.addView(TextView(this).apply {
                    text = n; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    setTextColor(if (n == filter) Color.WHITE else 0xFF9A9AAC.toInt())
                    setBackgroundResource(if (n == filter) R.drawable.tab_sel_bg else R.drawable.chip_bg)
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
                    setOnClickListener { filter = n; renderChips(); renderList() }
                })
            }
        }
        renderChips(); renderList()

        val search = android.widget.EditText(this).apply {
            hint = "Search fonts"; setHintTextColor(0xFF6B6B7A.toInt()); setTextColor(Color.WHITE); textSize = 15f
            setSingleLine(true); setBackgroundResource(R.drawable.row_bg); setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { query = s?.toString() ?: ""; renderList() }
            })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16))
            addView(dialogHeader("Fonts"))
            addView(search)
            addView(android.widget.HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false; addView(chipRow)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            })
            addView(ScrollView(context).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(accentButton(prefs.getString("font_tree", null)?.let { "Font folder  \u00B7  " + folderLabel(it) } ?: "Select font folder") { dlg?.dismiss(); pickFolder(4) }.apply {
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            })
        }
        dlg = AlertDialog.Builder(this, DLG).setView(box).create().also {
            it.show()
            it.window?.setLayout(minOf(dp(520), (resources.displayMetrics.widthPixels * 0.94f).toInt()), (resources.displayMetrics.heightPixels * 0.92f).toInt())
            it.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            it.setOnDismissListener { loader.shutdownNow() }
        }
    }

    /** Font folder se file ko app storage me copy karta hai (preview + select ke liye). */
    private fun copyFont(u: Uri, name: String, size: Long): File? = try {
        val dir = File(filesDir, "ffonts").apply { mkdirs() }
        val f = File(dir, name)
        if (!f.exists() || f.length() == 0L || (size > 0 && f.length() != size))
            contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        if (f.length() > 0) f else null
    } catch (e: Exception) { null }

    private fun selectFolderFont(fi: FontItem) {
        val u = fi.uri ?: return
        Thread {
            val f = copyFont(u, fi.mode.removePrefix("folder:"), fi.fsize)
            runOnUiThread { if (f != null) setFontMode(fi.mode) else show("Font could not be loaded") }
        }.start()
    }

    private val hideBadge = Runnable { findViewById<View>(R.id.subBadge).visibility = View.GONE }

    /** Chhota corner label: kaunsa subtitle + kaunsa font abhi laga hai. */
    private fun showBadge() {
        val b = findViewById<TextView>(R.id.subBadge)
        b.background = GradientDrawable().apply { setColor(0xCC101824.toInt()); setStroke(dp(1), 0x33FFFFFF); cornerRadius = dp(12).toFloat() }
        b.text = "Sub: " + currentSubName() + "\nFont: " + fontName()
        b.visibility = View.VISIBLE
        b.removeCallbacks(hideBadge)
        b.postDelayed(hideBadge, 2800)
    }

    private fun pickFile(r: Int) {
        if (!subPaused) closeSide()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), r)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        if (r == 3 || r == 4) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            prefs.edit().putString(if (r == 3) "sub_tree" else "font_tree", u.toString()).apply()
            if (r == 3) subOpenPage() else fontDialog()
            return
        }
        if (r == 1) { loadSubUri(u); closeSide() } else loadFontUri(u)
        player.play()
    }

    // ---------- folder pick (subtitle / font) ----------
    private class FEntry(val name: String, val uri: Uri, val size: Long)

    private fun pickFolder(r: Int) {
        if (!subPaused) closeSide()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), r)
    }

    /** Chune hue folder ki files (sirf allowed extensions), naam ke hisaab se sorted. */
    private fun listFolder(treeStr: String, exts: Set<String>): List<FEntry>? {
        return try {
            val tree = Uri.parse(treeStr)
            val docId = android.provider.DocumentsContract.getTreeDocumentId(tree)
            val kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val out = ArrayList<FEntry>()
            contentResolver.query(kids, arrayOf(
                android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                android.provider.DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val nm = c.getString(1) ?: continue
                    if (nm.substringAfterLast('.', "").lowercase(Locale.ROOT) !in exts) continue
                    out.add(FEntry(nm, android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)), c.getLong(2)))
                }
            } ?: return null
            out.sortedBy { it.name.lowercase(Locale.ROOT) }
        } catch (e: Exception) { null }
    }

    private fun folderLabel(treeStr: String): String = try {
        android.provider.DocumentsContract.getTreeDocumentId(Uri.parse(treeStr)).substringAfter(':').ifEmpty { "Storage" }
    } catch (e: Exception) { "Folder" }

    private fun videoBaseName(): String {
        val k = player.currentMediaItemIndex
        val raw = try { Uri.parse(uris[k]).lastPathSegment ?: "" } catch (e: Exception) { "" }
        return raw.substringAfterLast('/').substringAfterLast(':').substringBeforeLast('.').lowercase(Locale.ROOT)
    }

    /** Subtitle folder: saved folder ki saari subtitle files; current video se milta naam upar. */
    private fun subFolderDialog() {
        val tree = prefs.getString("sub_tree", null)
        if (tree == null) { pickFolder(3); return }
        val files = listFolder(tree, setOf("srt", "vtt", "ass", "ssa", "ttml", "dfxp", "xml"))
        if (files == null) { show("Folder not accessible. Select it again."); pickFolder(3); return }
        val base = videoBaseName()
        val sorted = files.sortedByDescending { base.isNotEmpty() && it.name.substringBeforeLast('.').lowercase(Locale.ROOT).let { n -> n == base || n.startsWith(base) || base.startsWith(n) } }
        val rows = ArrayList<View>()
        fun isMatch(n: String) = base.isNotEmpty() && n.substringBeforeLast('.').lowercase(Locale.ROOT).let { x -> x == base || x.startsWith(base) || base.startsWith(x) }
        fun hdr(t: String) = TextView(this).apply { text = t; setTextColor(0xFF9A9AAC.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(6), 0, dp(6)) }
        if (sorted.isEmpty()) rows.add(TextView(this).apply { text = "No subtitle files in this folder"; setTextColor(0xFFBBBBCC.toInt()); setPadding(dp(8), dp(12), dp(8), dp(12)) })
        var shownOther = false
        sorted.forEachIndexed { idx, fe ->
            val match = isMatch(fe.name)
            if (idx == 0 && match) rows.add(hdr("BEST MATCH FOR THIS VIDEO"))
            if (!match && !shownOther) { shownOther = true; rows.add(hdr(if (idx == 0) "SUBTITLE FILES" else "OTHER FILES")) }
            rows.add(fileRow(fe.name, fe.name.substringAfterLast('.', "").uppercase(Locale.ROOT), if (fe.size > 0) "${fe.size / 1024} KB" else null, match, "\u2605 ") {
                dlg?.dismiss(); loadSubUri(fe.uri); player.play()
            })
        }
        listDialog("Subtitles \u00B7 " + folderLabel(tree), rows, "Change Folder", null, null, 66) { dlg?.dismiss(); pickFolder(3) }
    }

    private fun loadSubUri(u: Uri) {
        run {
            val dn = (contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: u.lastPathSegment ?: "subtitle")
            val n = dn.lowercase()
            val (kind, mt) = when {
                n.endsWith(".vtt") -> "vtt" to MimeTypes.TEXT_VTT
                n.endsWith(".ass") || n.endsWith(".ssa") -> "ass" to MimeTypes.TEXT_SSA
                n.endsWith(".ttml") || n.endsWith(".dfxp") || n.endsWith(".xml") -> "ttml" to MimeTypes.APPLICATION_TTML
                n.endsWith(".srt") -> "srt" to MimeTypes.APPLICATION_SUBRIP
                else -> {
                    show("Unsupported subtitle format. Use SRT, VTT, ASS, SSA or TTML.")
                    player.play()
                    return
                }
            }
            val bytes = try { contentResolver.openInputStream(u)?.use { it.readBytes() } } catch (e: Exception) { null }
            if (bytes == null || bytes.isEmpty()) { show("Subtitle file could not be read"); player.play(); return }
            val txt = decodeText(bytes)
            val valid = when (kind) {
                "ass" -> txt.contains("[Events]", ignoreCase = true) &&
                    txt.lineSequence().any { it.trimStart().startsWith("Dialogue:", ignoreCase = true) }
                "ttml" -> txt.contains("<tt", ignoreCase = true) && txt.contains("<body", ignoreCase = true)
                "vtt" -> txt.trimStart().removePrefix("\uFEFF").startsWith("WEBVTT", ignoreCase = true) && tsRe.containsMatchIn(txt)
                else -> tsRe.containsMatchIn(txt)
            }
            if (!valid) { show("Subtitle file is invalid or unsupported"); player.play(); return }
            val i = player.currentMediaItemIndex
            val p = player.currentPosition
            ext[i]?.cur?.delete()
            ext[i] = ExtSub(txt, kind, mt, dn)
            clearTr(i)
            saveExt(i)
            pendingExt = i
            badgeAfterSelect = true
            buildExt(i)
            prefs.edit().putBoolean("son", true).apply()
            player.replaceMediaItem(i, item(i))
            player.seekTo(i, p)
            // Selection must happen after Media3 prepares the replacement item and exposes its
            // external text TrackGroup. Keep playback state and the existing player workflow.
            applySubOnOff()
            subView.postDelayed(extTrackRetry, 450)
            show("Subtitle added — loading track…")
        }
    }

    private fun loadFontUri(u: Uri) {
        run {
            try {
                val displayName = contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "custom.ttf"
                val extn = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (extn !in setOf("ttf", "otf", "ttc")) {
                    show("Unsupported font. Choose a TTF, OTF or TTC font file.")
                    player.play()
                    return
                }
                val f = File(filesDir, "subtitle_font.$extn")
                val copied = contentResolver.openInputStream(u)?.use { ins ->
                    f.outputStream().use { out -> ins.copyTo(out) }
                    f.length() > 0
                } ?: false
                if (!copied) throw IllegalStateException("Empty font file")
                val loaded = Typeface.createFromFile(f)
                prefs.edit().putString("sf", f.path).putString("fm", "custom").putString("sfn", displayName).apply()
                tf = loaded
                applySub()
                showBadge()
            } catch (e: Exception) { show("Font could not be loaded. Try a valid TTF/OTF/TTC file.") }
        }
    }

    private fun pick(type: Int) {
        val gs = player.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (gs.isEmpty()) { show("No tracks"); return }
        val off = type == C.TRACK_TYPE_TEXT
        val names = (if (off) listOf("Off") else listOf<String>()) +
            gs.mapIndexed { n, g -> (if (g.isSelected) "\u2713 " else "") + g.getTrackFormat(0).let { it.label ?: it.language ?: "Track ${n + 1}" } }
        AlertDialog.Builder(this, DLG).setItems(names.toTypedArray()) { _, i ->
            val k = if (off) i - 1 else i
            val tp = player.trackSelectionParameters.buildUpon().clearOverridesOfType(type).setTrackTypeDisabled(type, k < 0)
            if (k >= 0) tp.addOverride(TrackSelectionOverride(gs[k].mediaTrackGroup, 0))
            player.trackSelectionParameters = tp.build()
            if (type == C.TRACK_TYPE_AUDIO && k >= 0) gs[k].getTrackFormat(0).language?.let { prefs.edit().putString("pal", it).apply() }
            if (type == C.TRACK_TYPE_TEXT) { prefs.edit().putBoolean("son", k >= 0).apply(); syncSubUi() }
        }.show()
    }

    // ---------- video enhance (GPU colour matrix, no extra library) ----------
    private fun setEnh(b: Int, c: Int, s: Int, sh: Int = 0) {
        prefs.edit().putInt("eb", b).putInt("ec", c).putInt("es", s).putInt("esh", sh).apply()
        applyEnh(); reopenSide()
    }

    private fun applyEnh() {
        val b = prefs.getInt("eb", 0)
        val c = prefs.getInt("ec", 100) / 100f
        val m = ColorMatrix().apply { setSaturation(prefs.getInt("es", 100) / 100f) }
        val o = 128 * (1 - c) + b * 1.2f
        m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, o, 0f, c, 0f, 0f, o, 0f, 0f, c, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        // Night mode: warm (kam blue light) + dim; subtitles bhi thode dim
        val ns = if (night()) prefs.getInt("nightLvl", 60) / 100f else 0f
        if (ns > 0f) {
            val r = 1f - 0.30f * ns
            val gg = r * (1f - 0.20f * ns)
            val bb = r * (1f - 0.55f * ns)
            m.postConcat(ColorMatrix(floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, gg, 0f, 0f, 0f, 0f, 0f, bb, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        }
        subView.alpha = 1f - 0.35f * ns
        pv.videoSurfaceView?.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        applySharp()
    }

    /** Sharpness: 3x3 unsharp-mask shader (AGSL, Android 13+). 0 = band. */
    private fun applySharp() {
        if (Build.VERSION.SDK_INT < 33) return
        val v = pv.videoSurfaceView ?: return
        val amt = prefs.getInt("esh", 0) / 125f
        if (amt <= 0f) { v.setRenderEffect(null); return }
        try {
            val sh = RuntimeShader(SHARP_AGSL)
            sh.setFloatUniform("amount", amt)
            v.setRenderEffect(RenderEffect.createRuntimeShaderEffect(sh, "inputShader"))
        } catch (e: Exception) { v.setRenderEffect(null) }
    }

    // ---------- night mode ----------
    private fun night() = prefs.getBoolean("night", false)

    private fun syncNightUi() {
        if (night()) nightBtn.setColorFilter(acc()) else nightBtn.clearColorFilter()
    }

    private fun setNight(on: Boolean) {
        prefs.edit().putBoolean("night", on).apply()
        applyEnh(); syncNightUi()
        show(if (on) "Night mode ON" else "Night mode OFF")
    }

    // ---------- frame by frame ----------
    private fun frameMs(): Double {
        val fr = player.videoFormat?.frameRate ?: -1f
        return 1000.0 / (if (fr in 1f..240f) fr else 24f)
    }

    /** Tap = 1 frame, dabaye rakho = lagataar. dir: +1 aage, -1 peeche. Video pause ho jata hai. */
    private fun bindStep(v: View, dir: Int) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                    view.isPressed = true
                    stepDir = dir
                    stepFrame(dir)
                    pv.removeCallbacks(stepRepeat)
                    pv.postDelayed(stepRepeat, 450)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    pv.removeCallbacks(stepRepeat)
                }
            }
            true
        }
    }

    private fun stepFrame(dir: Int) {
        if (player.playbackState == Player.STATE_IDLE) return
        if (player.playWhenReady) player.pause()
        val f = frameMs()
        val now = SystemClock.uptimeMillis()
        val cur = player.currentPosition.toDouble()
        val lp = if (lastPtsUs >= 0) lastPtsUs / 1000.0 else -1.0
        val recent = stepPos >= 0 && now - stepAt < 700
        val base = when {
            recent && lp >= 0 && abs(lp - stepPos) < 0.6 * f -> lp        // frame render ho chuka: asli timestamp
            recent -> stepPos                                              // tez taps: apna hisaab
            lp >= 0 && abs(lp - cur) < 3 * f -> lp
            else -> cur
        }
        // exact seek pehla frame dikhata hai jiska time >= target. Isliye half-frame pehle ka target.
        var target = base + dir * f - 0.5 * f
        val dur = player.duration
        if (dur > 0 && target > dur) target = dur.toDouble()
        if (target < 0) target = 0.0
        stepPos = (base + dir * f).coerceAtLeast(0.0)
        stepAt = now
        pv.removeCallbacks(exactSeek)
        player.setSeekParameters(SeekParameters.EXACT)
        player.seekTo(target.toLong())
        pv.showController()
        val t = stepPos.toLong()
        show((if (dir > 0) "Frame +1" else "Frame -1") + "   " + String.format(Locale.US, "%d:%02d.%03d", t / 60000, t / 1000 % 60, t % 1000))
    }

    private fun setLock(on: Boolean) {
        locked = on
        pv.useController = !on
        unlockBtn.removeCallbacks(hideUnlock)
        if (on) flashUnlock() else unlockBtn.visibility = View.GONE
    }

    private fun flashUnlock() {
        unlockBtn.visibility = View.VISIBLE
        unlockBtn.removeCallbacks(hideUnlock)
        unlockBtn.postDelayed(hideUnlock, 2500)
    }

    /** Double-tap play/pause: letters ki jagah symbol (animated). */
    private fun flashPlay(playing: Boolean) {
        playFlash.animate().cancel()
        playFlash.removeCallbacks(hideFlash)
        playFlash.setImageResource(if (playing) R.drawable.ic_play else R.drawable.ic_pause)
        playFlash.visibility = View.VISIBLE
        playFlash.alpha = 0f; playFlash.scaleX = 0.7f; playFlash.scaleY = 0.7f
        playFlash.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140)
            .withEndAction { playFlash.postDelayed(hideFlash, 450) }.start()
    }

    /** MediaStore se width/height (rotation ke saath) -> true = vertical video. Pata na chale to null. */
    private fun peekPortrait(u: String?): Boolean? {
        if (u == null) return null
        return try {
            val cols = if (Build.VERSION.SDK_INT >= 29)
                arrayOf(MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.ORIENTATION)
            else arrayOf(MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT)
            contentResolver.query(Uri.parse(u), cols, null, null, null)?.use { c ->
                if (!c.moveToFirst()) return@use null
                var w = c.getInt(0); var h = c.getInt(1)
                if (cols.size > 2) { val r = c.getInt(2); if (r == 90 || r == 270) { val t = w; w = h; h = t } }
                if (w <= 0 || h <= 0) null else h > w
            }
        } catch (e: Exception) { null }
    }

    /** Instant +-10s: fast (keyframe) seek, taps accumulate (+10, +20, +30...). */
    private fun skip(dir: Int) {
        val now = SystemClock.uptimeMillis()
        if (dir != skipDir || now - lastSkipAt > 900) { skipAcc = 0L; skipBase = player.currentPosition }
        skipDir = dir; lastSkipAt = now
        skipAcc += 10_000L * dir
        val dur = player.duration
        val t = skipBase + skipAcc
        player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        player.seekTo(if (dur > 0) t.coerceIn(0L, dur) else t.coerceAtLeast(0L))
        pv.removeCallbacks(exactSeek); pv.postDelayed(exactSeek, 1200)
        val v = if (dir < 0) skipL else skipR
        (if (dir < 0) skipR else skipL).visibility = View.GONE
        v.text = (if (skipAcc > 0) "+" else "") + (skipAcc / 1000) + "s"
        v.visibility = View.VISIBLE
        v.animate().cancel()
        v.alpha = 1f; v.scaleX = 0.85f; v.scaleY = 0.85f
        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        v.removeCallbacks(hideSkip); v.postDelayed(hideSkip, 700)
    }

    private fun showLevel(label: String, pct: Int) {
        levelTxt.text = label
        levelBar.progress = pct.coerceIn(0, 100)
        levelBox.visibility = View.VISIBLE
        levelBox.removeCallbacks(hideLevel); levelBox.postDelayed(hideLevel, 900)
    }

    // ---- per-video speed ----
    private fun spdKey(i: Int) = "spd_" + (uris.getOrNull(i) ?: "").hashCode()
    private fun setSpeed(sp: Float) {
        player.setPlaybackSpeed(sp)
        prefs.edit().putFloat(spdKey(player.currentMediaItemIndex), sp).apply()
        show("${sp}x")
    }
    private fun defSpeed() = AppSettings.DEF_SPEED.get(this) / 100f
    private fun applySpeed() { player.setPlaybackSpeed(prefs.getFloat(spdKey(player.currentMediaItemIndex), defSpeed())) }

    // ---- A-B repeat ----
    private fun abRow(): View {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        val upd = {
            tv.text = "A-B repeat: " + (if (abA < 0) "off" else VideoInfo.dur(abA)) + (if (abB > 0) "  to  " + VideoInfo.dur(abB) else "")
        }
        upd()
        fun chip(l: String, f: () -> Unit) = btn(l) { f(); upd() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(2), dp(10), dp(2), dp(10))
            setBackgroundResource(R.drawable.chip_bg)
        }
        val row = LinearLayout(this).apply {
            addView(chip("Set A") { abA = player.currentPosition; abB = -1L })
            addView(chip("Set B") { if (abA >= 0 && player.currentPosition > abA) abB = player.currentPosition })
            addView(chip("Clear") { abA = -1L; abB = -1L })
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)); addView(tv); addView(row) }
    }

    /**
     * Previous button: 3 sec se zyada chal chuka ho ya pehle koi video na ho -> isi video ko shuru se.
     * Warna pichhla video. (Media3 ka seekToPreviousMediaItem() pehle/akele video par kuch nahi karta tha.)
     */
    private fun playPrevious() {
        if (player.currentPosition > 3000 || !player.hasPreviousMediaItem()) player.seekTo(0)
        else player.seekToPreviousMediaItem()
    }

    // ---- queue / playlist ----
    private fun queue() {
        val cur = player.currentMediaItemIndex
        val rows = uris.indices.map { i ->
            fileRow(names?.getOrNull(i) ?: Uri.parse(uris[i]).lastPathSegment ?: "Video", null, "#" + (i + 1), i == cur, "\u25B6\uFE0E  ") {
                dlg?.dismiss(); player.seekTo(i, 0L)
            }
        }
        listDialog("Queue (" + uris.size + ")", rows, "Close", null, null, 66) { dlg?.dismiss() }
    }

    private fun friendly(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "Video file not found (it may have been deleted or moved)."
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "No permission to open this video."
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "Network problem. Check your connection and tap Retry."
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "The server refused this link (it may have expired, or it needs a Referer). " +
            "Open Network stream again and fill the Referer field with the page address."
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ->
            if (player.currentMediaItem?.localConfiguration?.uri?.scheme?.startsWith("http") == true)
                "This does not look like a direct video link (it may be a webpage, protected or expired). Try a direct mp4 / mkv / m3u8 link."
            else "This file is corrupt or in an unsupported format."
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "This phone cannot decode this video format. Try switching the HW / SW decoder chip."
        else -> "Playback problem. Tap Retry or try another link."
    }

    // ---- seekbar thumbnail preview ----
    private fun scrubTo(pos: Long) {
        val dur = player.duration
        scrubTime.text = VideoInfo.dur(pos)
        if (dur > 0) {
            val frac = (pos.toFloat() / dur).coerceIn(0f, 1f)
            val room = (pv.width - dp(136)).coerceAtLeast(0)
            scrubBox.translationX = frac * room
        }
        scrubWant = pos
        if (!scrubBusy) loadScrubFrame()
    }

    private fun loadScrubFrame() {
        val uri = player.currentMediaItem?.localConfiguration?.uri ?: return
        if (uri.scheme != "content" && uri.scheme != "file") return
        val want = scrubWant
        scrubBusy = true
        scrubPool.execute {
            var bm: Bitmap? = null
            try {
                val key = uri.toString()
                if (mmr == null || mmrUri != key) {
                    try { mmr?.release() } catch (e: Exception) { }
                    mmr = MediaMetadataRetriever().also { it.setDataSource(this, uri) }
                    mmrUri = key
                }
                bm = if (Build.VERSION.SDK_INT >= 27)
                    mmr?.getScaledFrameAtTime(want * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 272, 156)
                else mmr?.getFrameAtTime(want * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } catch (e: Exception) { }
            runOnUiThread {
                scrubBusy = false
                if (bm != null) scrubImg.setImageBitmap(bm)
                if (scrubBox.visibility == View.VISIBLE && scrubWant != want) loadScrubFrame()
            }
        }
    }

    private fun show(t: String) {
        refreshRailState()
        info.removeCallbacks(hideInfo)
        info.text = t
        info.visibility = View.VISIBLE
        info.postDelayed(hideInfo, 800)
    }

    private fun mark(item: MediaItem, pos: Long, dur: Long) {
        val u = item.localConfiguration?.uri?.toString() ?: return
        if (Stash.isVaultPath(u)) return                      // private vault ke videos ki history nahi banti
        History.save(this, u, pos, dur, folder, item.mediaMetadata.title?.toString() ?: "Video")
    }

    private fun save() {
        if (resumeAsk) return
        val item = player.currentMediaItem ?: return
        val d = player.duration
        if (d > 0) mark(item, player.currentPosition, d)
    }

    private fun pip() {
        val b = PictureInPictureParams.Builder()
        val vs = player.videoSize
        if (vs.width > 0 && vs.height > 0) {
            val r = vs.width.toFloat() / vs.height
            if (r in 0.43f..2.35f) b.setAspectRatio(android.util.Rational(vs.width, vs.height))
        }
        try { enterPictureInPictureMode(b.build()) } catch (e: Exception) { }
    }

    // ---------- Settings se aaye extras: shortcuts, backward button, flip, clock, resume ask ----------
    private val scViews = ArrayList<Pair<View, BoolDef>>()
    private var backBtnView: TextView? = null
    private var mirror = false
    private var vflip = false

    private fun railBtn(icon: Int, desc: String, f: () -> Unit): ImageView = ImageView(this).apply {
        contentDescription = desc
        setImageResource(icon)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setBackgroundResource(R.drawable.glass_circle_btn)
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) }
        setOnClickListener { f() }
    }

    private fun applyFlip() {
        pv.videoSurfaceView?.let { it.scaleX = if (mirror) -1f else 1f; it.scaleY = if (vflip) -1f else 1f }
    }

    private fun setupExtras() {
        val items = findViewById<LinearLayout>(R.id.railItems)
        val spd = railBtn(R.drawable.ic_speed, "Speed") { speedPage() }
        val shot = railBtn(R.drawable.ic_camera, "Screenshot") { screenshot() }
        val eq = railBtn(R.drawable.ic_tune, "Equalizer") { eqPage() }
        val mir = railBtn(R.drawable.ic_mirror, "Mirror") { mirror = !mirror; applyFlip(); show(if (mirror) "Mirror ON" else "Mirror OFF") }
        val vf = railBtn(R.drawable.ic_vflip, "Vertical flip") { vflip = !vflip; applyFlip(); show(if (vflip) "Vertical flip ON" else "Vertical flip OFF") }
        val rep = railBtn(R.drawable.ic_repeat, "Repeat") { cycleRepeat() }
        val shuf = railBtn(R.drawable.ic_shuffle, "Shuffle") { toggleShuffle() }
        val ab = railBtn(R.drawable.ic_repeat_one, "A-B repeat") { cycleAb() }
        listOf(spd, shot, eq, mir, vf, rep, shuf, ab).forEach { items.addView(it) }

        // +85s forward button: hamesha ON, neeche-right (transport row ke end me)
        val pipHolder = findViewById<View>(R.id.pipBtn).parent as ViewGroup
        val bb = TextView(this).apply {
            gravity = Gravity.CENTER; minWidth = dp(60); setPadding(dp(14), 0, dp(14), 0)
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 14f
            setShadowLayer(4f, 0f, 1f, Color.BLACK)
            contentDescription = "Skip forward"
            setBackgroundResource(R.drawable.chip_strong_bg)
            layoutParams = LinearLayout.LayoutParams(-2, dp(48))
            setOnClickListener {
                val n = AppSettings.SKIP_S.get(this@PlayerActivity)
                val d = player.duration
                var t = player.currentPosition + n * 1000L
                if (d > 0L) t = minOf(t, d)
                player.seekTo(t); show("+" + n + "s")
            }
        }
        pipHolder.addView(bb)
        backBtnView = bb
        updateSkipLabel()

        // Rotate button neeche-right se hata kar shortcuts row me
        val rot = findViewById<View>(R.id.rotateBtn)
        (rot.parent as ViewGroup).removeView(rot)
        rot.setBackgroundResource(R.drawable.glass_circle_btn)
        rot.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) }
        items.addView(rot, 0)

        // PiP button neeche-right se hata kar shortcuts row me (rotate ke baad)
        val pipV = findViewById<View>(R.id.pipBtn)
        (pipV.parent as ViewGroup).removeView(pipV)
        pipV.setBackgroundResource(R.drawable.glass_circle_btn)
        pipV.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) }
        items.addView(pipV, 1)

        // Collapsible shortcuts (MX jaisa): row ke shuru me arrow, dabane par saare shortcuts chhup / dikh jaate hain
        railOpen = prefs.getBoolean("rail_open", true)
        val tg = railBtn(R.drawable.ic_chevron, "Shortcuts") {
            railOpen = !railOpen
            prefs.edit().putBoolean("rail_open", railOpen).apply()
            applyShortcuts()
        }
        tg.setBackgroundResource(R.drawable.glass_circle_btn)
        tg.setColorFilter(Color.WHITE)
        tg.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(10) }
        (railWrap as LinearLayout).addView(tg)         // scroll ke bahar, hamesha right side me
        railToggleV = tg

        railViews += muteBtn to AppSettings.SC_MUTE
        railViews += findViewById<View>(R.id.sleepBtn) to AppSettings.SC_SLEEP
        railViews += nightBtn to AppSettings.SC_NIGHT
        railViews += findViewById<View>(R.id.frameBackBtn) to AppSettings.SC_FRAME
        railViews += findViewById<View>(R.id.frameFwdBtn) to AppSettings.SC_FRAME
        railViews += rot to AppSettings.SC_ROTATE
        railViews += pipV to AppSettings.SC_PIP
        railViews += spd to AppSettings.SC_SPEED
        railViews += shot to AppSettings.SC_SHOT
        railViews += eq to AppSettings.SC_EQ
        railViews += mir to AppSettings.SC_MIRROR
        railViews += vf to AppSettings.SC_VFLIP
        railViews += rep to AppSettings.SC_REPEAT
        railViews += shuf to AppSettings.SC_SHUFFLE
        railViews += ab to AppSettings.SC_AB
        scViews += findViewById<View>(R.id.prevBtn) to AppSettings.PREV_NEXT
        scViews += findViewById<View>(R.id.nextBtn) to AppSettings.PREV_NEXT

        // ON / OFF dikhane wale shortcuts (selected state = accent ring)
        stateViews += muteBtn to { muted }
        stateViews += findViewById<View>(R.id.sleepBtn) to { sleepAt != 0L }
        stateViews += nightBtn to { night() }
        stateViews += spd to { player.playbackParameters.speed != 1f }
        stateViews += eq to { AppSettings.EQ_ON.get(this) }
        stateViews += mir to { mirror }
        stateViews += vf to { vflip }
        stateViews += rep to { player.repeatMode != Player.REPEAT_MODE_OFF }
        stateViews += shuf to { prefs.getBoolean("shuf", false) }
        stateViews += ab to { abA >= 0L }
        applyShortcuts()
        railWrap.post { fitRail() }
    }

    private val stateViews = ArrayList<Pair<View, () -> Boolean>>()

    private fun refreshRailState() {
        if (!::player.isInitialized) return
        stateViews.forEach { (v, f) -> try { v.isSelected = f() } catch (e: Exception) { } }
    }

    // ---------- zoom / pan, baaki time, repeat / shuffle / A-B shortcuts ----------
    private fun applyZoom() {
        val fr = pv.findViewById<View>(androidx.media3.ui.R.id.exo_content_frame) ?: return
        val w = fr.width.toFloat()
        val h = fr.height.toFloat()
        val mx = (zoom - 1f) * w / 2f
        val my = (zoom - 1f) * h / 2f
        panX = panX.coerceIn(-mx, mx); panY = panY.coerceIn(-my, my)
        fr.pivotX = w / 2f; fr.pivotY = h / 2f
        fr.scaleX = zoom; fr.scaleY = zoom; fr.translationX = panX; fr.translationY = panY
        layoutSubs()
    }

    private fun resetZoom() { zoom = 1f; panX = 0f; panY = 0f; applyZoom() }

    private fun updRemain() {
        val tv = durTv ?: return
        if (!AppSettings.SHOW_REMAIN.get(this)) return
        val d = player.duration
        if (d <= 0L) return
        tv.text = "-" + VideoInfo.dur((d - player.currentPosition).coerceAtLeast(0L))
    }

    private fun cycleRepeat() {
        val next = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        player.repeatMode = next
        prefs.edit().putInt("rep", next).apply()
        show("Repeat: " + when (next) { Player.REPEAT_MODE_ONE -> "this video"; Player.REPEAT_MODE_ALL -> "all videos"; else -> "off" })
    }

    private fun toggleShuffle() {
        val on = !prefs.getBoolean("shuf", false)
        prefs.edit().putBoolean("shuf", on).apply()
        player.shuffleModeEnabled = on
        show(if (on) "Shuffle on" else "Shuffle off")
    }

    private fun cycleAb() {
        val p = player.currentPosition
        when {
            abA < 0 -> { abA = p; abB = -1L; show("A set at " + VideoInfo.dur(p)) }
            abB < 0 -> { if (p > abA) { abB = p; show("Looping A to B") } else show("B must be after A") }
            else -> { abA = -1L; abB = -1L; show("A-B repeat off") }
        }
    }

    private val railViews = ArrayList<Pair<View, BoolDef>>()
    private var railOpen = true
    private var railToggleV: ImageView? = null
    private var fullTitle = ""

    private fun setTitleText(t: CharSequence?) {
        fullTitle = t?.toString() ?: ""
        ttl.text = fullTitle.replace('_', ' ')          // underscores ki jagah space: naam sahi line me toot-ta hai
    }

    /** Arrow shortcuts ke theek baad rahe (gap nahi). Shortcuts zyada hon to row screen tak limit hoti hai aur scroll hoti hai. */
    private fun fitRail() {
        val sv = findViewById<HorizontalScrollView>(R.id.railScroll) ?: return
        val inner = sv.getChildAt(0) ?: return
        inner.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val cw = inner.measuredWidth
        val total = (railWrap.parent as? View)?.width?.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val avail = total - dp(32) - dp(56)
        val want = if (cw > avail) avail else ViewGroup.LayoutParams.WRAP_CONTENT
        if (sv.layoutParams.width != want) { sv.layoutParams.width = want; sv.requestLayout() }
    }

    private fun applyShortcuts() {
        var any = false
        railViews.forEach { (v, d) ->
            val on = d.get(this)
            if (on) any = true
            v.visibility = if (on && railOpen) View.VISIBLE else View.GONE
        }
        scViews.forEach { (v, d) -> v.visibility = if (d.get(this)) View.VISIBLE else View.GONE }
        findViewById<ViewGroup>(R.id.skipRow)?.let { r ->
            r.visibility = if ((0 until r.childCount).any { r.getChildAt(it).visibility == View.VISIBLE }) View.VISIBLE else View.GONE
        }
        refreshRailState()
        railToggleV?.let { it.visibility = if (any) View.VISIBLE else View.GONE; it.rotation = if (railOpen) 180f else 0f }
        fitRail()
    }

    private var resumeAsk = false      // resume dialog open: position 0 history ko overwrite na kare

    private fun askResume(pos: Long) {
        resumeAsk = true
        player.pause()
        AlertDialog.Builder(this, DLG).setTitle("Resume playback?")
            .setMessage("Continue from " + VideoInfo.dur(pos) + " or start over?")
            .setCancelable(false)
            .setPositiveButton("Resume") { _, _ -> resumeAsk = false; player.seekTo(pos); player.play() }
            .setNegativeButton("Start over") { _, _ -> resumeAsk = false; player.play() }.show()
    }

    private val clockRun = object : Runnable {
        override fun run() {
            val tv = findViewById<TextView>(R.id.clockOv) ?: return
            val pct = try { (getSystemService(BATTERY_SERVICE) as android.os.BatteryManager).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) } catch (e: Exception) { -1 }
            tv.text = android.text.format.DateFormat.getTimeFormat(this@PlayerActivity).format(java.util.Date()) + (if (pct in 0..100) "   $pct%" else "")
            tv.postDelayed(this, 30_000L)
        }
    }

    override fun onUserLeaveHint() {
        if (::player.isInitialized && !locked && player.isPlaying && !AppSettings.BG_PLAY.get(this)) pip()
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        pv.useController = !inPip && !locked
    }

    // ---------- headset / bluetooth media buttons ----------
    private var msess: MediaSession? = null

    private var lastMetaKey: String? = null

    private fun syncMeta(s: MediaSession) {
        try {
            val item = player.currentMediaItem
            val u = item?.localConfiguration?.uri?.toString() ?: ""
            val title = if (Stash.isVaultPath(u)) "Private video" else (item?.mediaMetadata?.title?.toString() ?: "Video")
            val dur = player.duration.takeIf { it > 0 } ?: -1L
            val key = "$title|$dur"
            if (key == lastMetaKey) return
            lastMetaKey = key
            s.setMetadata(
                android.media.MediaMetadata.Builder()
                    .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, title)
                    .putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, dur)
                    .build()
            )
        } catch (e: Exception) { }
    }

    private fun setupSession() {
        lastMetaKey = null
        msess?.let { it.isActive = false; it.release() }
        val s = MediaSession(this, "NextGen Play")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { player.play() }
            override fun onPause() { player.pause() }
            override fun onStop() { player.pause() }
            override fun onSkipToNext() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
            override fun onSkipToPrevious() {
                playPrevious()
            }
            override fun onFastForward() { player.seekTo(player.currentPosition + 10_000) }
            override fun onRewind() { player.seekTo(maxOf(0L, player.currentPosition - 10_000)) }
            override fun onSeekTo(pos: Long) { player.seekTo(pos) }
        })
        s.isActive = true
        msess = s
        syncSession()
    }

    private fun syncSession() {
        val s = msess ?: return
        syncMeta(s)
        val playing = player.isPlaying || (player.playWhenReady && player.playbackState == Player.STATE_BUFFERING)
        val acts = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_STOP or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_FAST_FORWARD or PlaybackState.ACTION_REWIND or PlaybackState.ACTION_SEEK_TO
        s.setPlaybackState(PlaybackState.Builder().setActions(acts)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                player.currentPosition, if (playing) player.playbackParameters.speed else 0f).build())
    }

    override fun onPause() {
        super.onPause(); if (::player.isInitialized) save()
        Ads.onPlayerLeft()
    }     // library resume real-time (Main onResume se pehle)
    // ---------- Background play (Settings > Player > Playback) ----------
    private var bgVideoOff = false

    private fun videoOff(off: Boolean) {
        bgVideoOff = off
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, off).build()
    }

    /** Notification + foreground service. Player events par update hota hai. */
    private fun bgNotify() {
        if (!AppSettings.BG_PLAY.get(this) || isDestroyed) return
        BgPlay.token = msess?.sessionToken
        val i = android.content.Intent(this, BgPlayService::class.java).setAction(BgPlay.ACTION_SHOW)
            .putExtra("title", player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "NextGen Play")
            .putExtra("playing", player.isPlaying || (player.playWhenReady && player.playbackState == Player.STATE_BUFFERING))
        try { startForegroundService(i) } catch (e: Exception) { }
    }

    private fun bgAttach() {
        if (!AppSettings.BG_PLAY.get(this)) return
        BgPlay.handler = { a ->
            when (a) {
                BgPlay.ACTION_PLAY -> player.play()
                BgPlay.ACTION_PAUSE -> player.pause()
                BgPlay.ACTION_NEXT -> { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
                BgPlay.ACTION_PREV -> {
                    playPrevious()
                }
                BgPlay.ACTION_CLOSE -> finishAndRemoveTask()
                else -> {}
            }
        }
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { bgNotify() }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { bgNotify() }
        })
        bgNotify()
    }

    override fun onStart() {
        super.onStart()
        if (::player.isInitialized && bgVideoOff) videoOff(false)       // wapas aaye: video chalu
    }

    override fun onStop() {
        super.onStop()
        if (!::player.isInitialized) return
        save()
        // background play ON aur video chal raha ho to audio chalta rahe (video track band, battery bachti hai)
        if (AppSettings.BG_PLAY.get(this) && !isFinishing && !isInPictureInPictureMode &&
            player.playWhenReady && player.playbackState != Player.STATE_ENDED) videoOff(true)
        else player.pause()
    }
    override fun onDestroy() {
        super.onDestroy()
        BgPlay.handler = null; BgPlay.token = null
        stopService(android.content.Intent(this, BgPlayService::class.java))
        findViewById<View>(R.id.clockOv)?.removeCallbacks(clockRun)
        subView.removeCallbacks(tick); subView.removeCallbacks(reloadSub); subView.removeCallbacks(sleepRun); info.removeCallbacks(flushAudio)
        pv.removeCallbacks(exactSeek); pv.removeCallbacks(stepRepeat)
        syncCancel = true; trCancel = true; trPool.shutdownNow()
        scrubPool.execute { try { mmr?.release() } catch (e: Exception) { } }
        scrubPool.shutdown()
        ext.values.forEach { it.cur?.delete() }
        msess?.let { it.isActive = false; it.release() }
        fx.release()
        if (::player.isInitialized) player.release()
    }
}
