# libass (ass-media / ass-kt): native (JNI) + reflection ke liye
-keep class io.github.peerless2012.ass.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn io.github.peerless2012.**

# FFmpeg audio extension (LGPL): DefaultRenderersFactory reflection se load karta hai, JNI naam se dhoondta hai
-keep class androidx.media3.decoder.ffmpeg.** { *; }
# media3 decoder buffers: native code in fields ko naam se access karta hai
-keep class androidx.media3.decoder.** { *; }
# HLS: DefaultMediaSourceFactory reflection se load karta hai
-keep class androidx.media3.exoplayer.hls.** { *; }

# Unity Ads
-keep class com.unity3d.** { *; }
-dontwarn com.unity3d.**

# Unity LevelPlay (ironSource mediation) + adapters
-keep class com.unity3d.mediation.** { *; }
-keep class com.ironsource.** { *; }
-dontwarn com.ironsource.**
-keepattributes JavascriptInterface
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keep class com.google.android.gms.appset.** { *; }
-keep class com.google.android.gms.tasks.** { *; }
-dontwarn com.iab.omid.**
-keep class com.iab.omid.** { *; }
