#!/bin/sh
# Use: tools/make-version-json.sh <versionCode> <versionName> <apkFile> "<changelog>"
# version.json banata hai (APK ka SHA-256 ke saath). Isko GitHub Release me APK ke saath upload karo.
[ $# -lt 3 ] && { echo "Use: $0 <versionCode> <versionName> <apkFile> changelog"; exit 1; }
REPO=$(grep -o 'REPO = "[^"]*"' app/src/main/java/com/nextgen/play/Updater.kt | cut -d'"' -f2)
if command -v sha256sum >/dev/null 2>&1; then SHA=$(sha256sum "$3" | cut -d' ' -f1); else SHA=$(shasum -a 256 "$3" | cut -d' ' -f1); fi
SIZE=$(wc -c < "$3" | tr -d ' ')
LOG="$4"
[ -f "$LOG" ] && LOG=$(cat "$LOG")                                   # 4th argument file ka path ho to uska text
LOG=$(printf '%s' "$LOG" | sed ':a;N;$!ba;s/\\/\\\\/g;s/"/\\"/g;s/\n/\\n/g')   # JSON ke liye escape
cat > version.json <<EOF
{
  "versionCode": $1,
  "versionName": "$2",
  "apkUrl": "https://github.com/$REPO/releases/download/v$2/$(basename "$3")",
  "sha256": "$SHA",
  "sizeBytes": $SIZE,
  "changelog": "$LOG"
}
EOF
cat version.json
