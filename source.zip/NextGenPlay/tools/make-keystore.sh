#!/bin/sh
# Ek baar chalao: apni release key banata hai (nextgen-release.jks). Is file + password ka BACKUP zaroor rakho.
keytool -genkeypair -v -keystore nextgen-release.jks -alias nextgen -keyalg RSA -keysize 2048 -validity 10000
echo "Ab keystore.properties.example ko keystore.properties naam se copy karke password bharo."
