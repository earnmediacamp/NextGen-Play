#!/usr/bin/env bash
# LGPL-only FFmpeg audio decoder AAR for Media3 (androidx.media3.decoder.ffmpeg).
# Usage: tools/build_ffmpeg_lgpl.sh <output.aar>
# Needs: git, Android SDK + NDK (ANDROID_NDK_HOME), JDK 17. GitHub ubuntu-latest runner par ye sab pehle se hota hai.
set -euo pipefail
OUT="$(realpath -m "${1:?usage: build_ffmpeg_lgpl.sh <output.aar>}")"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
[ -d "$NDK" ] || { echo "Android NDK nahi mila (ANDROID_NDK_HOME set karo)"; exit 1; }
MEDIA3_TAG=1.8.0          # app ke media3 version se match
FFMPEG_TAG=n6.0
HOST=linux-x86_64; [ "$(uname)" = Darwin ] && HOST=darwin-x86_64
W=$(mktemp -d); cd "$W"
git clone --depth 1 -b "$MEDIA3_TAG" https://github.com/androidx/media.git
git clone --depth 1 -b "$FFMPEG_TAG" https://git.ffmpeg.org/ffmpeg.git
FFM="$W/ffmpeg"; MOD="$W/media/libraries/decoder_ffmpeg/src/main"
# sirf audio decoders; --enable-gpl / --enable-nonfree / libx264 / libx265 BILKUL NAHI
DECODERS=(vorbis opus flac alac pcm_mulaw pcm_alaw mp3 amrnb amrwb aac ac3 eac3 dca mlp truehd)
ln -s "$FFM" "$MOD/jni/ffmpeg"
( cd "$MOD/jni" && ./build_ffmpeg.sh "$MOD" "$NDK" "$HOST" 21 "${DECODERS[@]}" )

# Licence guard: FFmpeg ka configure output GPL / nonfree ho to build fail
grep -q "define CONFIG_GPL 0" "$FFM/config.h"      || { echo "FFmpeg GPL mode me bana hai - ABORT"; exit 1; }
grep -q "define CONFIG_NONFREE 0" "$FFM/config.h"  || { echo "FFmpeg nonfree mode me bana hai - ABORT"; exit 1; }

cd "$W/media"
./gradlew :lib-decoder-ffmpeg:assembleRelease --no-daemon || ./gradlew :libraries:decoder_ffmpeg:assembleRelease --no-daemon
AAR=$(find libraries/decoder_ffmpeg -name '*release*.aar' | head -1)
[ -n "$AAR" ] || { echo "AAR nahi bana"; exit 1; }
mkdir -p "$(dirname "$OUT")"; cp "$AAR" "$OUT"
echo "OK: $OUT (LGPL, CONFIG_GPL=0, CONFIG_NONFREE=0)"
