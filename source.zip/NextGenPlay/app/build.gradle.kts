import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Firebase Analytics: app/google-services.json ho tabhi plugin lagta hai. File na ho to app phir bhi build hota hai (analytics bas chalu nahi hota).
if (file("google-services.json").exists()) apply(plugin = "com.google.gms.google-services")

// Apni release key: NextGenPlay/keystore.properties (git me nahi jati). Nahi mili to debug key se build (sirf testing).
val verCode = (project.findProperty("verCode") as String?)?.toIntOrNull() ?: 2
val verName = (project.findProperty("verName") as String?) ?: "1.1"
val ksFile = rootProject.file("keystore.properties")
val ks = Properties().apply { if (ksFile.exists()) ksFile.inputStream().use { load(it) } }
// Start.io App ID: portal.start.io se. gradle.properties me `startioAppId=XXXX` ya build me -PstartioAppId=XXXX.
// Na do to demo ID (205489527) lagta hai aur sirf TEST ads aate hain.
val STARTIO_DEMO_ID = "205489527"
val startioId = (project.findProperty("startioAppId") as String?)?.trim().takeUnless { it.isNullOrEmpty() } ?: STARTIO_DEMO_ID

android {
    namespace = "com.nextgen.play"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nextgen.play"
        minSdk = 26
        targetSdk = 34
        versionCode = verCode
        versionName = verName
        resourceConfigurations += "en"
        manifestPlaceholders["startioAppId"] = startioId
        buildConfigField("String", "STARTIO_APP_ID", "\"$startioId\"")
        buildConfigField("boolean", "STARTIO_TEST", (startioId == STARTIO_DEMO_ID).toString())
        // ffmpeg ki native libs sirf phones ke ABI ki (x86 emulator wale hata diye) -> APK chhota
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    signingConfigs {
        create("release") {
            if (ksFile.exists()) {
                storeFile = rootProject.file(ks.getProperty("storeFile"))
                storePassword = ks.getProperty("storePassword")
                keyAlias = ks.getProperty("keyAlias")
                keyPassword = ks.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName(if (ksFile.exists()) "release" else "debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Kotlin 2.x: kotlinOptions ki jagah compilerOptions
kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.8.0")
    implementation("androidx.media3:media3-ui:1.8.0")
    implementation("io.github.peerless2012:ass-media:0.5.1")   // libass (ASS/SSA) - media3 1.8.0 par bani hai, versions saath rakhna
    // FFmpeg audio (AC3/EAC3/DTS/TrueHD...): LGPL build, local AAR. Banane ka tareeka: tools/build_ffmpeg_lgpl.sh
    // AAR na ho tab bhi app build + chalta hai (audio phone ke MediaCodec decoders se). NextLib (GPL-3.0) hata diya.
    if (file("libs/media3-decoder-ffmpeg-lgpl.aar").exists()) implementation(files("libs/media3-decoder-ffmpeg-lgpl.aar"))
    // Start.io ads. Version pin kiya hai (stable build ke liye; "5.+" se alag-alag build me alag SDK aa jata hai).
    // Naya version portal/GitHub (StartApp-SDK/android-sdk-demo) par dekh kar badlo.
    implementation("com.startapp:inapp-sdk:5.2.2")
    // Firebase Analytics (installs, active users, retention, uninstall estimate). Sirf Analytics, koi aur Firebase service nahi.
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("androidx.media3:media3-exoplayer-hls:1.8.0")   // .m3u8 streams
    implementation("androidx.media3:media3-exoplayer-dash:1.8.0")   // .mpd (DASH) streams
    implementation("androidx.media3:media3-exoplayer-rtsp:1.8.0")   // rtsp:// streams
    implementation("androidx.core:core:1.13.1")   // FileProvider (update install)
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")   // pull to refresh
}
