package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

/** Recycle bin (kind "t") aur private vault (kind "v", PIN ke peeche) ki screen. */
class StashActivity : Activity() {
    companion object {
        private const val KIND = "kind"
        private const val REQ_ALL = 21
        private const val REQ_CRED = 22

        fun openBin(a: Activity) { a.startActivity(Intent(a, StashActivity::class.java).putExtra(KIND, "t")) }

        fun openVault(a: Activity) {
            val go = { a.startActivity(Intent(a, StashActivity::class.java).putExtra(KIND, "v")) }
            if (Pin.has(a)) go() else Pin.setup(a, onDone = { go() })
        }
    }

    private class Holder(val thumb: ImageView, val t1: TextView, val t2: TextView, val chk: CheckBox)

    private var kind = Stash.TRASH
    private var txt = 0
    private var txt2 = 0
    private var acc = 0
    private var themeSig = ""
    private lateinit var content: LinearLayout
    private lateinit var lv: ListView
    private lateinit var emptyTv: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var actionBar: LinearLayout
    private lateinit var selInfo: TextView
    private lateinit var statTv: TextView
    private lateinit var restoreBtn: TextView
    private var items = listOf<Stash.Item>()
    private val chosen = LinkedHashSet<String>()
    private var unlocked = false
    private var gating = false
    private var toPlayer = false
    private val thumbs = LruCache<String, Bitmap>(60)
    private val pool = Executors.newFixedThreadPool(2)

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun attr(a: Int): Int { val tv = TypedValue(); theme.resolveAttribute(a, tv, true); return tv.data }
    private val vault: Boolean get() = kind == Stash.VAULT
    private fun say(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        setTheme(if (Themes.light(this)) R.style.Theme_NextGenPlay_Light else R.style.Theme_NextGenPlay)
        Themes.applyAccent(this)
        themeSig = Themes.sig(this)
        super.onCreate(b)
        kind = if (intent.getStringExtra(KIND) == "v") Stash.VAULT else Stash.TRASH
        if (vault) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        txt = attr(R.attr.appText); txt2 = attr(R.attr.appText2); acc = attr(R.attr.appAccent)
        val red = 0xFFE5484D.toInt()
        val line = (txt2 and 0xFFFFFF) or 0x55000000

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(10)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back); setColorFilter(txt); setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); setOnClickListener { finish() }
        })
        head.addView(TextView(this).apply {
            text = if (vault) "Private vault" else "Recycle bin"
            setTextColor(txt); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        head.addView(AppDialogs.pill(this, if (vault) "PIN" else "Empty bin", null, txt, line) {
            if (vault) changePin() else confirmEmpty()
        })
        root.addView(head)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        statTv = TextView(this).apply {
            setTextColor(acc); textSize = 12.5f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(5), dp(12), dp(5)); setBackgroundResource(R.drawable.chip_accent_bg)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8); marginStart = dp(8) }
            visibility = View.GONE
        }
        content.addView(statTv)
        content.addView(TextView(this).apply {
            text = if (vault) "Videos here are hidden from the library and from other gallery apps. This screen asks for your PIN."
            else "Deleted videos stay here for " + AppSettings.binDays(this@StashActivity) + " days, then they are removed for good. They still use storage until then."
            setTextColor(txt2); textSize = 12.5f; setLineSpacing(0f, 1.1f); setPadding(dp(8), dp(10), dp(8), dp(10))
        })
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        lv = ListView(this).apply {
            divider = null; dividerHeight = dp(6); isVerticalScrollBarEnabled = false; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            adapter = object : BaseAdapter() {
                override fun getCount() = items.size
                override fun getItem(i: Int) = items[i]
                override fun getItemId(i: Int) = i.toLong()
                override fun getView(i: Int, v: View?, p: ViewGroup): View = bindRow(i, v)
            }
        }
        frame.addView(lv)
        emptyTv = TextView(this).apply {
            text = if (vault) "The vault is empty.\nLong-press videos in the library, then More > Move to private vault."
            else "The recycle bin is empty."
            setTextColor(txt2); textSize = 15f; gravity = Gravity.CENTER; setLineSpacing(0f, 1.15f)
            layoutParams = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER); visibility = View.GONE
        }
        frame.addView(emptyTv)
        permBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), 0)
            layoutParams = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER); visibility = View.GONE
            addView(TextView(this@StashActivity).apply {
                text = "This screen needs \"All files access\" to reach the hidden folder where videos are kept."
                setTextColor(txt2); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(14))
            })
            addView(AppDialogs.pill(this@StashActivity, "Allow access", acc, Color.WHITE, acc) {
                if (Build.VERSION.SDK_INT >= 30) AllFiles.open(this@StashActivity, REQ_ALL)
            })
        }
        frame.addView(permBox)
        content.addView(frame)

        actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4)); visibility = View.GONE
        }
        selInfo = TextView(this).apply {
            setTextColor(txt); textSize = 13.5f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { selectAllToggle() }
        }
        actionBar.addView(selInfo)
        restoreBtn = AppDialogs.pill(this, if (vault) "Unlock" else "Restore", acc, Color.WHITE, acc) { restoreChosen() }
        actionBar.addView(restoreBtn)
        actionBar.addView(AppDialogs.pill(this, "Delete", red, Color.WHITE, red) { confirmDeleteChosen() }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
        })
        content.addView(actionBar)
        root.addView(content)
        setContentView(root)
    }

    // ---------- list ----------
    private fun rel(t: Long): String {
        val d = (System.currentTimeMillis() - t) / 86_400_000L
        return when { d <= 0L -> "today"; d == 1L -> "yesterday"; else -> "$d days ago" }
    }

    private fun bindRow(i: Int, convert: View?): View {
        val item = items[i]
        val view: View
        val h: Holder
        if (convert == null) {
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0x22000000)
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(60))
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                    }
                }
            }
            val t1 = TextView(this).apply { setTextColor(txt); textSize = 14f; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; typeface = Typeface.DEFAULT_BOLD }
            val t2 = TextView(this).apply { setTextColor(txt2); textSize = 12f; maxLines = 2; setPadding(0, dp(2), 0, 0) }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12); marginEnd = dp(8) }
                addView(t1); addView(t2)
            }
            val chk = CheckBox(this).apply { isClickable = false; isFocusable = false }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundResource(R.drawable.card_bg)
                addView(thumb); addView(col); addView(chk)
            }
            h = Holder(thumb, t1, t2, chk)
            row.tag = h
            view = row
        } else { view = convert; h = convert.tag as Holder }
        h.t1.text = item.name.substringBeforeLast('.', item.name)
        val info = ArrayList<String>()
        VideoInfo.size(item.size).let { if (it.isNotEmpty()) info += it }
        if (item.dur > 0) info += VideoInfo.dur(item.dur)
        if (!vault) {
            info += "from " + item.folder
            val left = AppSettings.binDays(this) - ((System.currentTimeMillis() - item.time) / 86_400_000L).toInt()
            info += "deleted " + rel(item.time) + "  \u00B7  " + (if (left <= 0) "removed soon" else "$left days left")
        }
        h.t2.text = info.joinToString("  \u00B7  ")
        val on = item.path in chosen
        h.chk.isChecked = on
        view.isActivated = on
        view.setOnClickListener { toggle(item) }
        h.thumb.setOnClickListener { if (vault) play(item) else toggle(item) }
        loadThumb(item.path, h.thumb)
        return view
    }

    private fun loadThumb(path: String, iv: ImageView) {
        iv.tag = path
        val hit = thumbs.get(path)
        if (hit != null) { iv.setImageBitmap(hit); return }
        iv.setImageDrawable(null)
        pool.execute {
            var bmp: Bitmap? = null
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(path)
                val f = r.getFrameAtTime(3_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (f != null) bmp = Bitmap.createScaledBitmap(f, 192, (192f * f.height / f.width).toInt().coerceAtLeast(1), true)
            } catch (e: Exception) { } finally { try { r.release() } catch (e2: Exception) { } }
            val out = bmp
            if (out != null) {
                thumbs.put(path, out)
                runOnUiThread { if (!isDestroyed && iv.tag == path) iv.setImageBitmap(out) }
            }
        }
    }

    private fun toggle(item: Stash.Item) {
        if (!chosen.add(item.path)) chosen.remove(item.path)
        refreshUi()
    }

    private fun selectAllToggle() {
        if (chosen.size == items.size) chosen.clear() else items.forEach { chosen.add(it.path) }
        refreshUi()
    }

    private fun refreshUi() {
        val ok = FileOps.canFiles(this)
        permBox.visibility = if (ok) View.GONE else View.VISIBLE
        emptyTv.visibility = if (ok && items.isEmpty()) View.VISIBLE else View.GONE
        lv.visibility = if (ok) View.VISIBLE else View.GONE
        (lv.adapter as BaseAdapter).notifyDataSetChanged()
        statTv.visibility = if (ok && items.isNotEmpty()) View.VISIBLE else View.GONE
        statTv.text = items.size.toString() + (if (items.size == 1) " video" else " videos") +
            VideoInfo.size(items.sumOf { it.size }).let { if (it.isEmpty()) "" else "  \u00B7  $it" }
        val sel = items.filter { it.path in chosen }
        actionBar.visibility = if (sel.isEmpty()) View.GONE else View.VISIBLE
        selInfo.text = sel.size.toString() + " selected" + VideoInfo.size(sel.sumOf { it.size }).let { if (it.isEmpty()) "" else "  \u00B7  $it" } + "\n(tap to select all / none)"
    }

    private fun reload() {
        Thread {
            val l = if (FileOps.canFiles(this)) Stash.list(this, kind) else emptyList()
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                items = l
                chosen.retainAll(l.map { it.path }.toSet())
                refreshUi()
            }
        }.start()
    }

    // ---------- actions ----------
    private fun play(item: Stash.Item) {
        toPlayer = true
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra("uris", arrayOf(Uri.fromFile(File(item.path)).toString()))
                .putExtra("names", arrayOf(item.name))
                .putExtra("folder", "Private vault")
        )
    }

    private fun restoreChosen() {
        val sel = items.filter { it.path in chosen }
        if (sel.isEmpty()) return
        restoreNext(sel, 0, 0)
    }

    private fun restoreNext(sel: List<Stash.Item>, i: Int, ok: Int) {
        if (isDestroyed) return
        if (i >= sel.size) {
            say(if (ok == sel.size) (if (vault) "$ok video(s) unlocked" else "$ok video(s) restored") else "$ok of ${sel.size} restored")
            chosen.clear(); reload(); return
        }
        Stash.restore(this, sel[i]) { good -> restoreNext(sel, i + 1, ok + if (good) 1 else 0) }
    }

    private fun confirmDeleteChosen() {
        val sel = items.filter { it.path in chosen }
        if (sel.isEmpty()) return
        AlertDialog.Builder(this, Themes.dialog(this))
            .setTitle("Delete " + sel.size + (if (sel.size == 1) " video" else " videos") + " for good?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> purge(sel) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirmEmpty() {
        if (items.isEmpty()) { say("The bin is already empty"); return }
        AlertDialog.Builder(this, Themes.dialog(this))
            .setTitle("Empty the recycle bin?")
            .setMessage(items.size.toString() + " video(s) will be removed for good.")
            .setPositiveButton("Empty") { _, _ -> purge(items) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun purge(sel: List<Stash.Item>) {
        Thread {
            sel.forEach { Stash.purge(this, it) }
            runOnUiThread { if (!isDestroyed) { chosen.clear(); say("Deleted"); reload() } }
        }.start()
    }

    // ---------- vault lock ----------
    private fun gate() {
        if (gating) return
        gating = true
        if (!Pin.has(this)) {
            Pin.setup(this, onDone = { gating = false; unlocked = true; showContent() }, onCancel = { gating = false; finish() })
            return
        }
        Pin.ask(this, "Private vault", forgot = { gating = false; forgotPin() },
            onOk = { gating = false; unlocked = true; showContent() },
            onCancel = { gating = false; finish() })
    }

    private fun showContent() { content.visibility = View.VISIBLE; reload() }

    private fun forgotPin() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val i = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Reset vault PIN", "Confirm your phone lock to set a new PIN") else null
        if (i == null) {
            say("Set a screen lock on your phone first, then try again")
            finish(); return
        }
        startActivityForResult(i, REQ_CRED)
    }

    private fun changePin() {
        Pin.ask(this, "Change PIN", null, onOk = { Pin.setup(this, onDone = { say("PIN changed") }) }, onCancel = { })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        when (r) {
            REQ_CRED -> {
                if (res == RESULT_OK) {
                    Pin.clear(this)
                    Pin.setup(this, onDone = { unlocked = true; showContent() }, onCancel = { finish() })
                } else finish()
            }
            REQ_ALL -> reload()
        }
    }

    override fun onResume() {
        super.onResume()
        if (themeSig != Themes.sig(this)) { recreate(); return }
        toPlayer = false
        if (vault && !unlocked) { content.visibility = View.INVISIBLE; gate() }
        else { content.visibility = View.VISIBLE; reload() }
    }

    override fun onStop() {
        super.onStop()
        if (vault && !isChangingConfigurations && !toPlayer) unlocked = false
    }

    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }
}
