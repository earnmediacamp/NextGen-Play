package com.nextgen.play

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore.Video.Media
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Collections

/**
 * Real file operations (move / copy / rename folder / recycle bin / private vault).
 * Ye sab "All files access" (Android 11+) ya WRITE_EXTERNAL_STORAGE (Android 9 aur neeche) maangte hain.
 */
object FileOps {
    private val SUB_EXT = setOf("srt", "ass", "ssa", "vtt", "sub", "idx", "smi", "sup")
    val VIDEO_EXT = setOf("mkv", "mp4", "m4v", "avi", "mov", "wmv", "flv", "webm", "ts", "m2ts", "3gp", "mpg", "mpeg", "ogv", "mts")

    fun canFiles(c: Context): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> AllFiles.granted()
        Build.VERSION.SDK_INT <= 28 -> c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else -> false
    }

    /** "/storage/emulated/0" ya "/storage/1A2B-3C4D" (path ka volume root). */
    fun volumeRoot(path: String): String? =
        Regex("^(/storage/(?:emulated/\\d+|[^/]+))(?:/|$)").find(path)?.groupValues?.get(1)

    /** Folder picker (document tree) -> asli path. Sirf phone / SD card storage; warna null. */
    fun treeToPath(u: Uri): String? = try {
        val id = DocumentsContract.getTreeDocumentId(u)           // "primary:Movies/Anime", "1A2B-3C4D:Videos", "raw:/storage/..."
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        val path = when {
            vol == "raw" -> rel
            else -> {
                val root = if (vol == "primary") "/storage/emulated/0" else "/storage/$vol"
                if (rel.isEmpty()) root else "$root/$rel"
            }
        }
        if (File(path).isDirectory) path else null
    } catch (e: Exception) { null }

    /**
     * Video ke saath ke subtitle files (same naam: "Ep1.srt", "Ep1.en.srt"). Agar koi lamba naam wali
     * dusri video ("Ep1.S01.mkv") usi subtitle ki maalik ban sakti ho to wo us video ki maani jati hai.
     */
    fun sidecars(videoPath: String): List<File> {
        val f = File(videoPath)
        val dir = f.parentFile ?: return emptyList()
        val base = f.name.substringBeforeLast('.', f.name)
        val sibs = dir.listFiles() ?: return emptyList()
        val others = sibs.filter { it.isFile && it != f && it.extension.lowercase() !in SUB_EXT }
        return sibs.filter { s ->
            s.isFile && s.extension.lowercase() in SUB_EXT && s.name.startsWith("$base.") &&
                others.none { o ->
                    val ob = o.name.substringBeforeLast('.', o.name)
                    ob.length > base.length && s.name.startsWith("$ob.")
                }
        }
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name)
        val ext = name.substring(base.length)
        var i = 1
        while (f.exists() && i < 1000) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    fun copyFile(src: File, dst: File, progress: ((Long) -> Unit)?, cancel: (() -> Boolean)?): Boolean {
        try {
            dst.parentFile?.mkdirs()
            FileInputStream(src).use { i ->
                FileOutputStream(dst).use { o ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        if (cancel?.invoke() == true) throw InterruptedException()
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        progress?.invoke(n.toLong())
                    }
                }
            }
            try { dst.setLastModified(src.lastModified()) } catch (e: Exception) { }
            return true
        } catch (e: Exception) {
            try { dst.delete() } catch (e2: Exception) { }
            return false
        }
    }

    /** Pehle rename (same volume par turant); na ho to copy + delete. */
    fun moveFile(src: File, dst: File, progress: ((Long) -> Unit)? = null, cancel: (() -> Boolean)? = null): Boolean {
        dst.parentFile?.mkdirs()
        val len = src.length()
        if (src.renameTo(dst)) { progress?.invoke(len); return true }
        if (!copyFile(src, dst, progress, cancel)) return false
        if (!src.delete()) { try { dst.delete() } catch (e: Exception) { }; return false }
        return true
    }

    /** MediaStore row tabhi hatao jab uski file sach me wahan nahi hai (kabhi existing file nahi mitati). */
    @Suppress("DEPRECATION")
    fun dropStaleRow(c: Context, uri: String) {
        try {
            var p: String? = null
            c.contentResolver.query(Uri.parse(uri), arrayOf(Media.DATA), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) p = cur.getString(0)
            }
            val path: String = p ?: return
            if (!File(path).exists()) c.contentResolver.delete(Uri.parse(uri), null, null)
        } catch (e: Exception) { }
    }

    /** dirPrefix ke andar jin rows ki file nahi bachi unhe hatao. */
    @Suppress("DEPRECATION")
    fun purgeMissing(c: Context, dirPrefix: String) {
        try {
            val ids = ArrayList<Long>()
            c.contentResolver.query(
                Media.EXTERNAL_CONTENT_URI, arrayOf(Media._ID, Media.DATA),
                Media.DATA + " LIKE ?", arrayOf("$dirPrefix%"), null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val p = cur.getString(1) ?: continue
                    if ((p == dirPrefix || p.startsWith("$dirPrefix/")) && !File(p).exists()) ids += cur.getLong(0)
                }
            }
            ids.forEach {
                try { c.contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, it), null, null) } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }

    /** Paths scan karo; done(path -> media uri) main thread par (zyada se zyada ~8 sec intezaar). */
    fun scan(c: Context, paths: List<String>, done: (Map<String, String?>) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val ps = paths.distinct()
        if (ps.isEmpty()) { main.post { done(emptyMap()) }; return }
        val res = Collections.synchronizedMap(HashMap<String, String?>())
        var fired = false
        main.postDelayed({ if (!fired) { fired = true; done(HashMap(res)) } }, 8000)
        try {
            MediaScannerConnection.scanFile(c.applicationContext, ps.toTypedArray(), null) { p, u ->
                res[p] = u?.toString()
                if (res.size >= ps.size) main.post { if (!fired) { fired = true; done(HashMap(res)) } }
            }
        } catch (e: Exception) {
            main.post { if (!fired) { fired = true; done(HashMap(res)) } }
        }
    }

    /** Move / rename ke baad video ka URI badal jata hai: history aur favourite naye URI par le jao. */
    fun migrate(c: Context, oldUri: String, newUri: String, folder: String, name: String) {
        if (oldUri == newUri) return
        History.get(c, oldUri)?.let { History.copyTo(c, it, newUri, folder, name) }
        History.remove(c, oldUri)
        val sp = AppSettings.sp(c)
        val fav = HashSet(sp.getStringSet("fav", emptySet()) ?: emptySet())
        if (fav.remove(oldUri)) { fav.add(newUri); sp.edit().putStringSet("fav", fav).apply() }
    }

    // ---------- move / copy ----------
    class Job(val video: Video, val destDir: File)
    class Result(val ok: Int, val failed: Int, val skipped: Int, val newPaths: Map<String, String>)

    /** Background thread par chalao. onProgress(index, total, bytesDone, name). */
    fun transfer(
        jobs: List<Job>, move: Boolean,
        onProgress: (Int, Int, Long, String) -> Unit, cancel: () -> Boolean
    ): Result {
        var ok = 0; var failed = 0; var skipped = 0
        var bytes = 0L
        val newPaths = HashMap<String, String>()
        for ((idx, job) in jobs.withIndex()) {
            if (cancel()) break
            val v = job.video
            onProgress(idx, jobs.size, bytes, v.name)
            val src = File(v.path)
            if (v.path.isEmpty() || !src.isFile) { failed++; continue }
            val same = try { src.parentFile?.canonicalPath == job.destDir.canonicalPath } catch (e: Exception) { false }
            if (same) { skipped++; continue }
            val subs = sidecars(v.path)
            val dst = uniqueFile(job.destDir, src.name)
            val prog: (Long) -> Unit = { n -> bytes += n; onProgress(idx, jobs.size, bytes, v.name) }
            val good = if (move) moveFile(src, dst, prog, cancel) else copyFile(src, dst, prog, cancel)
            if (!good) { failed++; continue }
            val ob = src.name.substringBeforeLast('.', src.name)
            val nb = dst.name.substringBeforeLast('.', dst.name)
            for (s in subs) {
                val suffix = if (s.name.length >= ob.length) s.name.substring(ob.length) else "." + s.extension
                val sd = uniqueFile(job.destDir, nb + suffix)
                if (move) moveFile(s, sd) else copyFile(s, sd, null, null)
            }
            newPaths[v.uri] = dst.absolutePath
            ok++
        }
        return Result(ok, failed, skipped, newPaths)
    }

    /** transfer() ke baad (main thread): purani rows hatao, nayi scan karo, history / fav migrate karo. */
    fun finish(c: Context, jobs: List<Job>, move: Boolean, r: Result, done: () -> Unit) {
        if (move) {
            for (j in jobs) if (r.newPaths.containsKey(j.video.uri)) dropStaleRow(c, j.video.uri)
        }
        val moved = jobs.filter { r.newPaths.containsKey(it.video.uri) }
        scan(c, moved.mapNotNull { r.newPaths[it.video.uri] }) { m ->
            if (move) {
                for (j in moved) {
                    val np = r.newPaths[j.video.uri] ?: continue
                    val nu = m[np] ?: continue
                    migrate(c, j.video.uri, nu, File(np).parentFile?.name ?: j.video.folder, File(np).name)
                }
            }
            done()
        }
    }
}
