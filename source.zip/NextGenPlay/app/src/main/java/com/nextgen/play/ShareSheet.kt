package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Apna share sheet: jo apps video (ya link) le sakte hain unki grid, app ke theme me.
 * Pichhli baar jo app chuni thi wo upar. "More" dabane par Android ka system chooser khulta hai.
 */
object ShareSheet {
    private const val KEY = "share_recent"

    @Suppress("DEPRECATION")
    fun show(a: Activity, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = VideoInfo.shareIntent(uris)
        val pm = a.packageManager
        val all: List<ResolveInfo> = try {
            pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        } catch (e: Exception) { emptyList<ResolveInfo>() }
        val found = all.filter { it.activityInfo.packageName != a.packageName }
        if (found.isEmpty()) { VideoInfo.share(a, uris); return }   // list nahi mili: system chooser

        val recent = (AppSettings.sp(a).getString(KEY, "") ?: "").split(",").filter { it.isNotBlank() }
        val labeled = found.map { it to it.loadLabel(pm).toString() }
        val sorted = labeled.sortedWith(compareBy<Pair<ResolveInfo, String>>(
            { val r = recent.indexOf(it.first.activityInfo.packageName); if (r < 0) 99 else r },
            { it.second.lowercase() }
        ))

        val tc = AppDialogs.col(a, R.attr.appText, Color.WHITE)
        val tc2 = AppDialogs.col(a, R.attr.appText2, 0xFFBBBBCC.toInt())
        val line = (tc2 and 0xFFFFFF) or 0x55000000
        val web = uris[0].scheme == "http" || uris[0].scheme == "https"
        fun dp(x: Int) = AppDialogs.dp(a, x)

        val dm = a.resources.displayMetrics
        val w = minOf(dp(440), (dm.widthPixels * 0.94f).toInt())
        val pad = dp(14)
        val cols = if (w >= dp(400)) 5 else 4
        val cellW = (w - 2 * pad) / cols

        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(18), pad, dp(14)) }
        box.addView(TextView(a).apply {
            text = if (web) "Share link" else "Share"; setTextColor(tc); textSize = 19f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), 0, dp(8), 0)
        })
        val sub = when {
            web -> uris[0].toString()
            uris.size > 1 -> uris.size.toString() + " videos"
            else -> ""
        }
        if (sub.isNotEmpty()) box.addView(TextView(a).apply {
            text = sub; setTextColor(tc2); textSize = 12.5f; maxLines = 1; ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(dp(8), dp(2), dp(8), 0)
        })

        lateinit var dlg: AlertDialog
        val grid = GridLayout(a).apply { columnCount = cols }
        sorted.forEach { (ri, label) ->
            val tile = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(10), dp(2), dp(6))
                layoutParams = GridLayout.LayoutParams().apply { width = cellW; height = -2 }
                addView(ImageView(a).apply {
                    setImageDrawable(try { ri.loadIcon(pm) } catch (e: Exception) { null })
                    layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                })
                addView(TextView(a).apply {
                    text = label; setTextColor(tc); textSize = 11.5f; gravity = Gravity.CENTER
                    maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(6), 0, 0)
                })
                setOnClickListener { dlg.dismiss(); launch(a, intent, ri) }
            }
            grid.addView(tile)
        }
        val rows = (sorted.size + cols - 1) / cols
        val maxH = (dm.heightPixels * 0.5f).toInt()
        box.addView(ScrollView(a).apply {
            addView(grid)
            layoutParams = LinearLayout.LayoutParams(-1, minOf(rows * dp(92) + dp(8), maxH)).apply { topMargin = dp(8) }
        })

        val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(dp(8), dp(10), dp(8), 0) }
        if (web) btns.addView(AppDialogs.pill(a, "Copy link", null, tc, line) {
            try {
                (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("link", uris[0].toString()))
                Toast.makeText(a, "Link copied", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { }
            dlg.dismiss()
        }.apply { layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) } })
        btns.addView(AppDialogs.pill(a, "More\u2026", null, tc, line) { dlg.dismiss(); VideoInfo.share(a, uris) })
        box.addView(btns)

        dlg = AppDialogs.show(a, box)
    }

    private fun launch(a: Activity, base: Intent, ri: ResolveInfo) {
        val i = Intent(base)
        i.setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
        try {
            a.startActivity(i)
            remember(a, ri.activityInfo.packageName)
        } catch (e: Exception) {
            Toast.makeText(a, "Could not open this app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun remember(c: Context, pkg: String) {
        val sp = AppSettings.sp(c)
        val l = ArrayList((sp.getString(KEY, "") ?: "").split(",").filter { it.isNotBlank() && it != pkg })
        l.add(0, pkg)
        sp.edit().putString(KEY, l.take(8).joinToString(",")).apply()
    }
}
