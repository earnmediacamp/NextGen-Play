package com.nextgen.play

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.Locale
import java.util.zip.Inflater

/**
 * MKV ke andar ka embedded ASS / SSA subtitle track padh ke poori .ass file ka text banata hai.
 * Is se translate poori file ki tarah ho sakta hai (Animated ASS ON me live translate nahi hota).
 * Sirf phone ki local MKV file par kaam karta hai. Video ke frames padhe nahi jaate: har block ka chhota header
 * dekh ke baaki skip kar dete hain.
 */
object MkvSubs {
    open class Err(msg: String) : Exception(msg)
    /** Is video me (ya selected track me) koi ASS/SSA track nahi mila. */
    class NoAss(msg: String) : Err(msg)

    class Result(val text: String, val name: String)

    private class Track {
        var number = 0L
        var type = 0L
        var codec = ""
        var lang = ""
        var name = ""
        var priv: ByteArray? = null
        var compAlgo = -1L
        var compSettings: ByteArray? = null
        val isAss: Boolean get() = codec == "S_TEXT/ASS" || codec == "S_TEXT/SSA" || codec == "S_ASS" || codec == "S_SSA"
    }

    private class Ev(val start: Long, val f: List<String>) {
        var end = -1L
    }

    /** Chhota windowed reader: seek karke sirf zaroori bytes padhta hai. */
    private class Rd(private val ch: FileChannel) {
        val len: Long = ch.size()
        var pos = 0L
        private val buf = ByteBuffer.allocate(1024)
        private var base = 0L
        private var lim = 0

        private fun fill(): Boolean {
            ch.position(pos)
            buf.clear()
            val n = ch.read(buf)
            base = pos
            lim = if (n > 0) n else 0
            return lim > 0
        }

        fun u8(): Int {
            if (pos < base || pos >= base + lim) { if (!fill()) return -1 }
            val v = buf.get((pos - base).toInt()).toInt() and 0xFF
            pos++
            return v
        }

        fun bytes(n: Int): ByteArray {
            val out = ByteArray(n)
            var i = 0
            while (i < n) {
                if (pos < base || pos >= base + lim) { if (!fill()) throw Err("Unexpected end of the video file.") }
                val avail = (base + lim - pos).toInt()
                val c = minOf(avail, n - i)
                System.arraycopy(buf.array(), (pos - base).toInt(), out, i, c)
                pos += c
                i += c
            }
            return out
        }

        fun uint(n: Int): Long {
            var v = 0L
            for (i in 0 until n) v = (v shl 8) or (u8() and 0xFF).toLong()
            return v
        }

        /** Element ID (marker bits ke saath). -1 = kharab data. */
        fun id(): Long {
            val b = u8()
            if (b <= 0) return -1
            val n = Integer.numberOfLeadingZeros(b) - 23
            if (n > 4) return -1
            var v = b.toLong()
            for (i in 1 until n) v = (v shl 8) or (u8() and 0xFF).toLong()
            return v
        }

        /** EBML size / vint. -1 = unknown size, -2 = kharab data. */
        fun vsize(): Long {
            val b = u8()
            if (b <= 0) return -2
            val n = Integer.numberOfLeadingZeros(b) - 23
            if (n > 8) return -2
            val mask = 0xFF shr n
            var v = (b and mask).toLong()
            var allOnes = v == mask.toLong()
            for (i in 1 until n) {
                val x = u8() and 0xFF
                if (x != 0xFF) allOnes = false
                v = (v shl 8) or x.toLong()
            }
            return if (allOnes) -1 else v
        }
    }

    private fun open(ctx: Context, s: String, closers: MutableList<Closeable>): FileChannel {
        val u = Uri.parse(s)
        return when (u.scheme) {
            "content" -> {
                val pfd = ctx.contentResolver.openFileDescriptor(u, "r") ?: throw Err("The video file could not be opened.")
                closers.add(pfd)
                val fis = FileInputStream(pfd.fileDescriptor)
                closers.add(fis)
                fis.channel
            }
            "file" -> {
                val r = RandomAccessFile(File(u.path ?: ""), "r")
                closers.add(r)
                r.channel
            }
            null, "" -> {
                val r = RandomAccessFile(File(s), "r")
                closers.add(r)
                r.channel
            }
            else -> throw Err("This is a network video. The embedded subtitle can be read only from a file on the phone.")
        }
    }

    private fun iso3(c: String): String = try { Locale(c).isO3Language } catch (e: Exception) { c }
    private fun sameLang(a: String, b: String) = a.isNotBlank() && b.isNotBlank() && iso3(a.lowercase()) == iso3(b.lowercase())

    /** Player me jo embedded track selected hai (id / language / label) use file ke track se milao. */
    private fun choose(tracks: List<Track>, hintId: String?, hintLang: String?, hintLabel: String?): Track {
        val subs = tracks.filter { it.type == 17L || it.isAss }
        val ass = subs.filter { it.isAss }
        if (ass.isEmpty()) throw NoAss("No ASS/SSA subtitle track found in this video.")
        var m: Track? = null
        if (!hintId.isNullOrEmpty()) {
            m = subs.firstOrNull { hintId == it.number.toString() || hintId.endsWith(":" + it.number) || hintId.endsWith("/" + it.number) }
        }
        if (m == null && !hintLabel.isNullOrBlank()) {
            m = subs.firstOrNull { it.name == hintLabel && (hintLang.isNullOrBlank() || sameLang(hintLang, it.lang)) }
        }
        if (m == null && !hintLang.isNullOrBlank()) {
            val l = subs.filter { sameLang(hintLang, it.lang) }
            if (l.size == 1) m = l[0]
        }
        if (m == null) return ass[0]
        if (!m.isAss) throw NoAss("The selected embedded subtitle is not ASS/SSA.")
        return m
    }

    private fun header(priv: ByteArray?): String {
        var h = String(priv ?: ByteArray(0), Charsets.UTF_8).removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        val i = h.indexOf("[Events]", ignoreCase = true)
        if (i >= 0) h = h.substring(0, i)
        h = h.trimEnd()
        if (h.isBlank()) {
            h = "[Script Info]\nScriptType: v4.00+\nPlayResX: 1280\nPlayResY: 720\n\n[V4+ Styles]\n" +
                "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n" +
                "Style: Default,Arial,48,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,1,2,10,10,30,1"
        }
        return h + "\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    }

    private fun inflate(b: ByteArray): ByteArray {
        val inf = Inflater()
        inf.setInput(b)
        val bo = ByteArrayOutputStream()
        val tmp = ByteArray(4096)
        try {
            while (!inf.finished()) {
                val n = inf.inflate(tmp)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                bo.write(tmp, 0, n)
            }
        } finally { inf.end() }
        return bo.toByteArray()
    }

    private fun assTime(ms: Long): String {
        val t = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d:%02d.%02d", t / 3600000, t / 60000 % 60, t / 1000 % 60, (t % 1000) / 10)
    }

    private fun str(rd: Rd, size: Long): String =
        if (size in 0..100000) String(rd.bytes(size.toInt()), Charsets.UTF_8).trimEnd('\u0000') else { rd.pos += size.coerceAtLeast(0); "" }

    fun extract(
        ctx: Context, uriStr: String, hintId: String?, hintLang: String?, hintLabel: String?,
        progress: (Int) -> Unit, cancelled: () -> Boolean
    ): Result {
        val closers = ArrayList<Closeable>()
        try {
            val rd = Rd(open(ctx, uriStr, closers))
            if (rd.len < 64) throw Err("The video file is too small.")
            if (rd.uint(4) != 0x1A45DFA3L) throw Err("Reading an embedded subtitle works for MKV files only.")
            rd.pos = 0

            val tracks = ArrayList<Track>()
            var scale = 1_000_000L
            var clusterTc = 0L
            var wanted: Track? = null
            var started = false
            val evs = ArrayList<Ev>()
            var lastEv: Ev? = null
            var groupDur = -1L
            var lastPct = -1

            while (rd.pos < rd.len) {
                if (cancelled()) throw Err("Cancelled")
                val pct = (rd.pos * 100 / rd.len).toInt()
                if (pct != lastPct) { lastPct = pct; progress(pct) }

                val id = rd.id()
                if (id < 0) break
                val size = rd.vsize()
                if (size == -2L) break
                val cur = tracks.lastOrNull()

                when (id) {
                    // masters: andar ghuso (size ki zaroorat nahi, isliye unknown-size bhi chalta hai)
                    0x18538067L, 0x1549A966L, 0x1654AE6BL, 0x6D80L, 0x6240L, 0x5034L -> {}
                    0x1F43B675L -> {
                        if (!started) {
                            started = true
                            wanted = choose(tracks, hintId, hintLang, hintLabel)
                        }
                    }
                    0xA0L -> { groupDur = -1; lastEv = null }
                    0xAEL -> tracks.add(Track())
                    0x2AD7B1L -> { scale = rd.uint(size.toInt()); if (scale <= 0) scale = 1_000_000L }
                    0xE7L -> clusterTc = rd.uint(size.toInt())
                    0xD7L -> { val v = rd.uint(size.toInt()); cur?.number = v }
                    0x83L -> { val v = rd.uint(size.toInt()); cur?.type = v }
                    0x86L -> { val v = str(rd, size); cur?.codec = v }
                    0x22B59CL -> { val v = str(rd, size); cur?.lang = v }
                    0x536EL -> { val v = str(rd, size); cur?.name = v }
                    0x63A2L -> {
                        if (size in 0..4_000_000) { val v = rd.bytes(size.toInt()); cur?.priv = v } else if (size > 0) rd.pos += size
                    }
                    0x4254L -> { val v = rd.uint(size.toInt()); cur?.compAlgo = v }
                    0x4255L -> {
                        if (size in 0..100000) { val v = rd.bytes(size.toInt()); cur?.compSettings = v } else if (size > 0) rd.pos += size
                    }
                    0x9BL -> {
                        val d = rd.uint(size.toInt())
                        val le = lastEv
                        if (le != null) le.end = le.start + d * scale / 1_000_000L else groupDur = d
                    }
                    0xA1L, 0xA3L -> {
                        if (size < 4) { if (size > 0) rd.pos += size; lastEv = null }
                        else {
                            val w = wanted
                            val start = rd.pos
                            val tn = if (w != null) rd.vsize() else -1L
                            val hdr = (rd.pos - start) + 3
                            if (w == null || tn != w.number || size < hdr) {
                                rd.pos = start + size
                                lastEv = null
                            } else {
                                val rel = ((rd.u8() shl 8) or rd.u8()).toShort().toInt()
                                val flags = rd.u8()
                                val plen = size - hdr
                                if ((flags and 0x06) != 0 || plen <= 0 || plen > 1_000_000) {
                                    rd.pos = start + size
                                    lastEv = null
                                } else {
                                    var data = rd.bytes(plen.toInt())
                                    try {
                                        if (w.compAlgo == 0L) data = inflate(data)
                                        else if (w.compAlgo == 3L) data = (w.compSettings ?: ByteArray(0)) + data
                                    } catch (e: Exception) { data = ByteArray(0) }
                                    // block = ReadOrder,Layer,Style,Name,MarginL,MarginR,MarginV,Effect,Text
                                    val f = String(data, Charsets.UTF_8).trimEnd('\n', '\r').split(",", limit = 9)
                                    if (f.size == 9) {
                                        val startMs = (clusterTc + rel) * scale / 1_000_000L
                                        val ev = Ev(startMs, f)
                                        if (id == 0xA1L && groupDur >= 0) ev.end = startMs + groupDur * scale / 1_000_000L
                                        evs.add(ev)
                                        lastEv = if (id == 0xA1L) ev else null
                                    } else lastEv = null
                                }
                            }
                        }
                    }
                    else -> {
                        if (size < 0) break
                        rd.pos += size
                    }
                }
            }

            val w = wanted ?: throw NoAss("No ASS/SSA subtitle track found in this video.")
            if (evs.isEmpty()) throw Err("The embedded subtitle has no lines.")
            val sorted = evs.sortedBy { it.start }
            val sb = StringBuilder(header(w.priv))
            for (e in sorted) {
                val end = if (e.end > e.start) e.end else e.start + 3000
                val f = e.f
                // Dialogue: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
                sb.append("Dialogue: ").append(f[1]).append(',').append(assTime(e.start)).append(',').append(assTime(end)).append(',')
                    .append(f[2]).append(',').append(f[3]).append(',').append(f[4]).append(',').append(f[5]).append(',')
                    .append(f[6]).append(',').append(f[7]).append(',').append(f[8]).append('\n')
            }
            progress(100)
            val label = if (w.name.isNotBlank()) w.name else if (w.lang.isNotBlank()) "Embedded ASS (" + w.lang + ")" else "Embedded ASS"
            return Result(sb.toString(), label)
        } finally {
            for (c in closers) { try { c.close() } catch (_: Exception) { } }
        }
    }
}
