package com.nextgen.play

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Recycle bin (kind 't') aur private vault (kind 'v').
 * Video ko usi storage volume ke hidden folder (.NextGenTrash / .NextGenVault, andar .nomedia) me rename karke
 * le jaate hain (turant, extra space nahi). Original path, naam, resume position SharedPreferences me.
 */
object Stash {
    const val TRASH = 't'
    const val VAULT = 'v'
    private const val PREF = "stash"
    private const val TRASH_DIR = ".NextGenTrash"
    private const val VAULT_DIR = ".NextGenVault"

    class Item(
        val kind: Char, val path: String, val orig: String, val name: String, val size: Long, val dur: Long,
        val time: Long, val folder: String, val pos: Long, val side: List<Pair<String, String>>
    )

    private fun sp(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun key(i: Item) = i.kind.toString() + ":" + i.path

    fun isStashPath(p: String) = p.contains("/$VAULT_DIR/") || p.contains("/$TRASH_DIR/")
    fun isVaultPath(p: String) = p.contains("/$VAULT_DIR/")

    private fun dirFor(kind: Char, srcPath: String): File? {
        val root = FileOps.volumeRoot(srcPath) ?: return null
        val d = File(root, if (kind == TRASH) TRASH_DIR else VAULT_DIR)
        if (!d.exists() && !d.mkdirs()) return null
        val nm = File(d, ".nomedia")
        if (!nm.exists()) { try { nm.createNewFile() } catch (e: Exception) { } }
        return d
    }

    private fun enc(i: Item): String = JSONObject().apply {
        put("o", i.orig); put("n", i.name); put("s", i.size); put("d", i.dur); put("t", i.time); put("f", i.folder); put("p", i.pos)
        put("sc", JSONArray().apply { i.side.forEach { put(JSONArray().put(it.first).put(it.second)) } })
    }.toString()

    private fun dec(kind: Char, path: String, s: String): Item? = try {
        val j = JSONObject(s)
        val side = ArrayList<Pair<String, String>>()
        j.optJSONArray("sc")?.let { a -> for (k in 0 until a.length()) { val p = a.getJSONArray(k); side += (p.getString(0) to p.getString(1)) } }
        Item(kind, path, j.getString("o"), j.getString("n"), j.optLong("s"), j.optLong("d"), j.optLong("t"), j.optString("f"), j.optLong("p"), side)
    } catch (e: Exception) { null }

    /** Video (aur uske subtitle files) ko stash me daalo. Worker thread par chalao. true = ho gaya. */
    fun stash(c: Context, kind: Char, v: Video): Boolean {
        if (v.path.isEmpty()) return false
        val src = File(v.path)
        if (!src.isFile) return false
        val dir = dirFor(kind, v.path) ?: return false
        val tag = java.lang.Long.toString(System.nanoTime(), 36)
        val dst = File(dir, tag + "_" + src.name)
        val subs = FileOps.sidecars(v.path)
        val size = src.length()
        if (!FileOps.moveFile(src, dst)) return false
        val side = ArrayList<Pair<String, String>>()
        for (s in subs) {
            val sd = File(dir, tag + "_" + s.name)
            if (FileOps.moveFile(s, sd)) side += (sd.absolutePath to s.absolutePath)
        }
        val e = History.get(c, v.uri)
        val item = Item(kind, dst.absolutePath, v.path, v.name, size, v.dur, System.currentTimeMillis(), v.folder, e?.pos ?: 0L, side)
        sp(c).edit().putString(key(item), enc(item)).apply()
        FileOps.dropStaleRow(c, v.uri)
        try { android.media.MediaScannerConnection.scanFile(c.applicationContext, arrayOf(v.path), null, null) } catch (ex: Exception) { }
        return true
    }

    fun list(c: Context, kind: Char): List<Item> {
        val out = ArrayList<Item>()
        val drop = ArrayList<String>()
        for ((k, v) in sp(c).all) {
            if (!k.startsWith("$kind:") || v !is String) continue
            val path = k.substring(2)
            val item = dec(kind, path, v)
            val root = FileOps.volumeRoot(path)
            when {
                item == null -> drop += k
                File(path).isFile -> out += item
                root != null && !File(root).exists() -> { }          // SD card nikla hua: baad me wapas aa sakta hai
                else -> drop += k
            }
        }
        if (drop.isNotEmpty()) sp(c).edit().apply { drop.forEach { remove(it) } }.apply()
        return out.sortedByDescending { it.time }
    }

    /** Wapas original jagah (naam takraye to "(1)" lagta hai). done(true/false) main thread par. */
    fun restore(c: Context, item: Item, done: (Boolean) -> Unit) {
        Thread {
            var newPath: String? = null
            try {
                val src = File(item.path)
                val orig = File(item.orig)
                val dir = orig.parentFile
                if (src.isFile && dir != null) {
                    dir.mkdirs()
                    val dst = FileOps.uniqueFile(dir, orig.name)
                    if (FileOps.moveFile(src, dst)) {
                        newPath = dst.absolutePath
                        val nb = dst.name.substringBeforeLast('.', dst.name)
                        val ob = orig.name.substringBeforeLast('.', orig.name)
                        for ((stashed, o) in item.side) {
                            val s = File(stashed)
                            if (!s.isFile) continue
                            val on = File(o).name
                            val suffix = if (on.length >= ob.length) on.substring(ob.length) else "." + File(o).extension
                            FileOps.moveFile(s, FileOps.uniqueFile(dir, nb + suffix))
                        }
                        sp(c).edit().remove(key(item)).apply()
                    }
                }
            } catch (e: Exception) { }
            val np = newPath
            Handler(Looper.getMainLooper()).post {
                if (np == null) done(false)
                else FileOps.scan(c, listOf(np)) { m ->
                    val u = m[np]
                    if (u != null && item.pos > 0L && item.dur > 0L) History.save(c, u, item.pos, item.dur, File(np).parentFile?.name ?: item.folder, File(np).name)
                    done(true)
                }
            }
        }.start()
    }

    /** Hamesha ke liye hatao (file + subtitles + record). Worker thread par chalao. */
    fun purge(c: Context, item: Item) {
        try { File(item.path).delete() } catch (e: Exception) { }
        item.side.forEach { try { File(it.first).delete() } catch (e: Exception) { } }
        sp(c).edit().remove(key(item)).apply()
    }

    fun emptyAll(c: Context, kind: Char) = list(c, kind).forEach { purge(c, it) }

    /** Bin me N din se purane items hatao. */
    fun autoPurge(c: Context, days: Int) {
        val cut = System.currentTimeMillis() - days * 86_400_000L
        list(c, TRASH).filter { it.time < cut }.forEach { purge(c, it) }
    }

    fun count(c: Context, kind: Char): Int = list(c, kind).size
}
