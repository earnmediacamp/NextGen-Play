package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.res.ColorStateList

/** Library menu ki saari settings (prefs "set"). MainActivity aur LibraryMenu dono yahin se padhte hain. */
object Lib {
    val SORTS = listOf("Title", "Date", "Played time", "Status", "Length", "Size", "Resolution", "Path", "Frame rate", "Type")
    val FIELDS = listOf(
        "Thumbnail" to "fld_thumb", "Length" to "fld_len", "File extension" to "fld_ext",
        "Played time" to "fld_played", "Resolution" to "fld_res", "Frame rate" to "fld_fps",
        "Path" to "fld_path", "Size" to "fld_size", "Date" to "fld_date",
        "Clean name" to "fld_clean"
    )
    private val FIELD_DEF = mapOf("fld_thumb" to true, "fld_len" to true, "fld_ext" to true, "fld_size" to true)

    fun sp(c: Context) = c.getSharedPreferences("set", Context.MODE_PRIVATE)
    fun field(c: Context, k: String) = sp(c).getBoolean(k, FIELD_DEF[k] ?: false)
    /** 0 = All folders, 1 = Files, 2 = Folders (path tree) */
    fun vmode(c: Context) = sp(c).getInt("vmode", 0).coerceIn(0, 2)
    fun vsort(c: Context) = sp(c).getInt("vsort", 0).coerceIn(0, SORTS.size - 1)
    fun vdesc(c: Context) = sp(c).getBoolean("vdesc", false)
    /** 0 = Comfortable, 1 = Compact (chhota thumbnail, zyada videos ek screen par). */
    val DENSITY = listOf("Comfortable", "Compact")
    fun density(c: Context) = sp(c).getInt("density", 0).coerceIn(0, 1)
    /** "[Group] Show_Name_12 [1080p]" -> "Show Name 12". Sirf dikhane ke liye; asli file name nahi badalta. */
    fun cleanName(base: String): String {
        var s = base
        s = s.replace(Regex("^\\s*(\\[[^\\]]*\\]\\s*)+"), "")
        s = s.replace(Regex("(\\s*\\[[^\\]]*\\])+\\s*$"), "")
        s = s.replace('_', ' ')
        if (!s.contains(' ') && s.count { it == '.' } >= 2) s = s.replace('.', ' ')
        s = s.replace(Regex("\\s{2,}"), " ").trim()
        return if (s.isEmpty()) base else s
    }
    /** Naam kitni lines me dikhe: 1 / 2 / 3 / 0 = Full (poora naam). Default 3. */
    val TITLE_LINES = listOf("1 line" to 1, "2 lines" to 2, "3 lines" to 3, "Full" to 0)
    fun titleLines(c: Context) = sp(c).getInt("title_lines", 3).let { if (it in 0..3) it else 3 }
    /** TextView ko naam ki lines + ellipsis do. 1 line = middle (shuru + aakhir dikhe), multi-line = end. */
    fun applyTitle(tv: TextView, c: Context, minTwoInGrid: Boolean = false) {
        val n = titleLines(c)
        tv.maxLines = if (n == 0) Int.MAX_VALUE else n
        tv.minLines = if (minTwoInGrid) (if (n == 0) 2 else minOf(2, n)) else 1
        tv.ellipsize = if (n == 1) android.text.TextUtils.TruncateAt.MIDDLE else android.text.TextUtils.TruncateAt.END
    }
    fun sortLabel(c: Context) = SORTS[vsort(c)] + (if (vdesc(c)) "  ↓" else "  ↑")
}

/** View Mode + Layout + Sort + Fields dialog. Cancel = kuch save nahi, Done = save + onDone(). */
object LibraryMenu {
    fun show(a: Activity, dlgTheme: Int, tc: Int, tc2: Int, accent: Int, grid: Boolean, onDone: () -> Unit) {
        val sp = Lib.sp(a)
        var vmode = Lib.vmode(a)
        var isGrid = grid
        var sort = Lib.vsort(a)
        var desc = Lib.vdesc(a)
        var tl = Lib.titleLines(a)
        var den = Lib.density(a)
        val fields = HashMap<String, Boolean>()
        Lib.FIELDS.forEach { fields[it.second] = Lib.field(a, it.second) }
        fun dp(x: Int) = (x * a.resources.displayMetrics.density).toInt()

        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(6)) }
        val scroll = ScrollView(a).apply { addView(box) }
        var dialog: AlertDialog? = null
        lateinit var rebuild: () -> Unit

        fun title(t: String) = TextView(a).apply {
            this.text = t; setTextColor(tc); textSize = 19f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(4), 0, dp(10))
        }
        fun divider() = View(a).apply {
            setBackgroundColor((tc2 and 0xFFFFFF) or 0x33000000)
            layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(10); bottomMargin = dp(12) }
        }
        fun tile(icon: Int, label: String, sel: Boolean, w: Float, f: () -> Unit) = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6))
            layoutParams = LinearLayout.LayoutParams(0, -2, w)
            addView(ImageView(a).apply {
                setImageResource(icon); setColorFilter(if (sel) accent else tc2)
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(30))
            })
            addView(TextView(a).apply {
                this.text = label; setTextColor(if (sel) accent else tc2); textSize = 12f; gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
            setOnClickListener { f() }
        }
        fun chip(label: String, sel: Boolean, w: Float, f: () -> Unit) = TextView(a).apply {
            this.text = label; gravity = Gravity.CENTER; textSize = 13f; setSingleLine(true)
            setTextColor(if (sel) accent else tc)
            setPadding(dp(2), dp(11), dp(2), dp(11))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (sel) (accent and 0xFFFFFF) or 0x2A000000 else 0x00000000)
                setStroke(dp(1), if (sel) accent else (tc2 and 0xFFFFFF) or 0x55000000)
            }
            layoutParams = LinearLayout.LayoutParams(0, -2, w).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setOnClickListener { f() }
        }

        rebuild = {
            val y = scroll.scrollY
            box.removeAllViews()
            // View mode | Layout
            box.addView(LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 3f)
                    addView(title("View Mode"))
                    addView(LinearLayout(a).apply {
                        addView(tile(R.drawable.ic_folder, "All folders", vmode == 0, 1f) { vmode = 0; rebuild() })
                        addView(tile(R.drawable.ic_file, "Files", vmode == 1, 1f) { vmode = 1; rebuild() })
                        addView(tile(R.drawable.ic_tree, "Folders", vmode == 2, 1f) { vmode = 2; rebuild() })
                    })
                })
                addView(View(a).apply {
                    setBackgroundColor((tc2 and 0xFFFFFF) or 0x33000000)
                    layoutParams = LinearLayout.LayoutParams(dp(1), dp(60)).apply { gravity = Gravity.BOTTOM; setMargins(dp(4), 0, dp(4), dp(6)) }
                })
                addView(LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 2f)
                    addView(title("Layout"))
                    addView(LinearLayout(a).apply {
                        addView(tile(R.drawable.ic_list, "List", !isGrid, 1f) { isGrid = false; rebuild() })
                        addView(tile(R.drawable.ic_grid, "Grid", isGrid, 1f) { isGrid = true; rebuild() })
                    })
                })
            })
            box.addView(divider())
            // Sort
            box.addView(title("Sort"))
            Lib.SORTS.chunked(5).forEachIndexed { r, names ->
                box.addView(LinearLayout(a).apply {
                    names.forEachIndexed { c, n -> val idx = r * 5 + c; addView(chip(n, sort == idx, 1f) { sort = idx; rebuild() }) }
                })
            }
            box.addView(LinearLayout(a).apply {
                setPadding(0, dp(6), 0, 0)
                addView(chip("↑  A to Z", !desc, 1f) { desc = false; rebuild() })
                addView(chip("↓  Z to A", desc, 1f) { desc = true; rebuild() })
            })
            box.addView(divider())
            // Title lines
            box.addView(title("Title lines"))
            box.addView(LinearLayout(a).apply {
                Lib.TITLE_LINES.forEach { (label, n) -> addView(chip(label, tl == n, 1f) { tl = n; rebuild() }) }
            })
            box.addView(divider())
            // Density
            box.addView(title("Density"))
            box.addView(LinearLayout(a).apply {
                Lib.DENSITY.forEachIndexed { i, label -> addView(chip(label, den == i, 1f) { den = i; rebuild() }) }
            })
            box.addView(divider())
            // Fields
            box.addView(title("Fields"))
            Lib.FIELDS.chunked(3).forEach { row ->
                box.addView(LinearLayout(a).apply {
                    row.forEach { (label, key) ->
                        addView(CheckBox(a).apply {
                            this.text = label; setTextColor(tc); textSize = 13f
                            buttonTintList = ColorStateList.valueOf(accent)
                            isChecked = fields[key] == true
                            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                            setOnCheckedChangeListener { _, c -> fields[key] = c }
                        })
                    }
                    repeat(3 - row.size) { addView(View(a).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }) }
                })
            }
            // Buttons
            box.addView(divider())
            box.addView(LinearLayout(a).apply {
                gravity = Gravity.END
                fun b(t: String, col: Int, f: () -> Unit) = addView(TextView(a).apply {
                    this.text = t; setTextColor(col); textSize = 16f; typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setPadding(dp(18), dp(10), dp(18), dp(10)); setOnClickListener { f() }
                })
                b("Cancel", tc2) { dialog?.dismiss() }
                b("Done", accent) {
                    val e = sp.edit().putInt("vmode", vmode).putBoolean("grid", isGrid).putInt("vsort", sort).putBoolean("vdesc", desc).putInt("title_lines", tl).putInt("density", den)
                    fields.forEach { (k, v) -> e.putBoolean(k, v) }
                    e.apply()
                    dialog?.dismiss()
                    onDone()
                }
            })
            scroll.post { scroll.scrollTo(0, y) }
        }
        rebuild()
        dialog = AlertDialog.Builder(a, dlgTheme).setView(scroll).create().also {
            it.show()
            it.window?.setLayout(minOf(dp(460), (a.resources.displayMetrics.widthPixels * 0.94f).toInt()), -2)
        }
    }
}
