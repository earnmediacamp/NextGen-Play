package com.nextgen.play

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * Firebase Analytics wrapper. Anonymous counts hi: naam, video list, file path kuch nahi bhejte.
 * google-services.json na ho ya Firebase fail ho to app par koi asar nahi (sab try/catch me).
 * Apne aap milta hai: first_open (install), session / active users, retention, app_remove (uninstall andaza), country, app version.
 */
object Stats {
    private var fa: FirebaseAnalytics? = null

    fun init(c: Context) {
        try { fa = FirebaseAnalytics.getInstance(c.applicationContext) } catch (_: Throwable) { fa = null }
    }

    fun log(name: String, vararg params: Pair<String, Any>) {
        try {
            val b = Bundle()
            for ((k, v) in params) when (v) {
                is Int -> b.putLong(k, v.toLong())
                is Long -> b.putLong(k, v)
                else -> b.putString(k, v.toString())
            }
            fa?.logEvent(name, b)
        } catch (_: Throwable) { }
    }
}
