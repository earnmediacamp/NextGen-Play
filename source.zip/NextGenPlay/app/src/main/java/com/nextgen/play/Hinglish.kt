package com.nextgen.play

/**
 * Hindi (Devanagari) text ko English letters me badalta hai (Hinglish): "आप कैसे हैं" -> "aap kaise hain".
 * Offline hai, koi library nahi. Rules simple hain (schwa deletion, matra, anusvara), isliye kabhi kabhi spelling thodi alag aa sakti hai.
 */
object Hinglish {
    private class U(val c: String, var v: String?, var nasal: String = "")   // v: null = inherent "a", "" = koi vowel nahi (halant)

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'ळ' to "l", 'व' to "v",
        'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h",
        '\u0958' to "q", '\u0959' to "kh", '\u095A' to "g", '\u095B' to "z", '\u095C' to "r", '\u095D' to "rh", '\u095E' to "f", '\u095F' to "y"
    )
    private val nukta = mapOf('क' to "q", 'ख' to "kh", 'ग' to "g", 'ज' to "z", 'ड' to "r", 'ढ' to "rh", 'फ' to "f")
    private val matra = mapOf(
        '\u093E' to "aa", '\u093F' to "i", '\u0940' to "ee", '\u0941' to "u", '\u0942' to "oo", '\u0943' to "ri",
        '\u0947' to "e", '\u0948' to "ai", '\u094B' to "o", '\u094C' to "au",
        '\u0945' to "e", '\u0946' to "e", '\u0949' to "o", '\u094A' to "o"
    )
    private val indep = mapOf(
        '\u0905' to "a", '\u0906' to "aa", '\u0907' to "i", '\u0908' to "ee", '\u0909' to "u", '\u090A' to "oo", '\u090B' to "ri",
        '\u090F' to "e", '\u0910' to "ai", '\u0913' to "o", '\u0914' to "au",
        '\u090D' to "e", '\u090E' to "e", '\u0911' to "o", '\u0912' to "o"
    )
    // Aam shabdon ki spelling jo rules se alag likhi jaati hai
    private val fixes = mapOf(
        "men" to "mein", "nahin" to "nahi", "kuchh" to "kuch", "kyon" to "kyun", "koee" to "koi",
        "chaahie" to "chahiye", "chaahiye" to "chahiye", "yah" to "yeh", "vah" to "woh", "vaha" to "woh"
    )

    private fun isWordChar(ch: Char): Boolean =
        ch in '\u0900'..'\u097F' && ch != '\u0964' && ch != '\u0965' && ch !in '\u0966'..'\u096F'

    fun convert(text: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (isWordChar(ch)) {
                var j = i
                while (j < text.length && isWordChar(text[j])) j++
                sb.append(word(text.substring(i, j)))
                i = j
            } else {
                when (ch) {
                    '\u0964', '\u0965' -> sb.append('.')
                    in '\u0966'..'\u096F' -> sb.append('0' + (ch - '\u0966'))
                    else -> sb.append(ch)
                }
                i++
            }
        }
        // har line ka pehla akshar bada
        return sb.toString().split("\n").joinToString("\n") { s ->
            if (s.isNotEmpty() && s[0].isLowerCase()) s[0].uppercaseChar() + s.substring(1) else s
        }
    }

    private fun readNasal(w: String, start: Int, u: U): Int {
        var i = start
        while (i < w.length && (w[i] == '\u0901' || w[i] == '\u0902' || w[i] == '\u0903')) {
            u.nasal += if (w[i] == '\u0903') "h" else "n"
            i++
        }
        return i
    }

    private fun word(w: String): String {
        val us = ArrayList<U>()
        var i = 0
        while (i < w.length) {
            val ch = w[i]
            val base = cons[ch]
            val iv = indep[ch]
            if (base != null) {
                var s: String = base
                i++
                if (i < w.length && w[i] == '\u093C') { s = nukta[ch] ?: s; i++ }
                var v: String? = null
                if (i < w.length) {
                    val nx = w[i]
                    if (nx == '\u094D') { v = ""; i++ }
                    else if (matra.containsKey(nx)) { v = matra[nx]; i++ }
                }
                val u = U(s, v)
                i = readNasal(w, i, u)
                us.add(u)
            } else if (iv != null) {
                i++
                val u = U("", iv)
                i = readNasal(w, i, u)
                us.add(u)
            } else {
                i++      // anjaan chihna (nukta akela, avagraha...) chhod do
            }
        }
        val n = us.size
        if (n == 0) return ""
        // shabd ke ant ka "a" hat jata hai (kitab, ghar), akele akshar me nahi (na, ka)
        if (n > 1 && us[n - 1].v == null) us[n - 1].v = ""
        // beech ka "a": dayen se baayen (samajhna -> samajh-na). Pichhle akshar par anusvara ho to nahi hatata (zindagi)
        for (k in n - 2 downTo 1) {
            val u = us[k]
            if (u.v == null && us[k - 1].v != "" && us[k - 1].nasal.isEmpty() && us[k + 1].v != "") u.v = ""
        }
        val sb = StringBuilder()
        for (k in 0 until n) {
            val u = us[k]
            sb.append(u.c)
            val v = u.v
            when {
                v == null -> sb.append('a')
                v.isEmpty() -> {}
                u.c.isEmpty() -> { if (k > 0 && v == "e") sb.append('y'); sb.append(v) }
                else -> sb.append(shorten(v, k, n))
            }
            if (u.nasal.isNotEmpty()) {
                var nas = u.nasal
                if (nas == "n" && k + 1 < n && us[k + 1].c.isNotEmpty() && us[k + 1].c[0] in "pbm") nas = "m"
                sb.append(nas)
            }
        }
        val out = sb.toString()
        return fixes[out] ?: out
    }

    /** Lambe vowels ko Hinglish me chhota karna: mera (meraa nahi), kya, ki, tu. Pehle akshar me lamba rehta hai: kaam, theek. */
    private fun shorten(v: String, k: Int, n: Int): String = when (v) {
        "aa" -> if (n == 1 || k > 0) "a" else "aa"
        "ee" -> if (n == 1 || k == n - 1) "i" else "ee"
        "oo" -> if (n == 1 || k == n - 1) "u" else "oo"
        else -> v
    }
}
