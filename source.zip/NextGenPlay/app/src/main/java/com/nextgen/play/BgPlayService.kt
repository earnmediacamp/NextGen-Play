package com.nextgen.play

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.session.MediaSession
import android.os.Build
import android.os.IBinder

/** PlayerActivity aur BgPlayService ke beech ka pul. Player activity ke paas hi rehta hai, service sirf process zinda rakhti hai aur notification dikhati hai. */
object BgPlay {
    const val ACTION_SHOW = "com.nextgen.play.BG_SHOW"
    const val ACTION_PLAY = "com.nextgen.play.BG_PLAY"
    const val ACTION_PAUSE = "com.nextgen.play.BG_PAUSE"
    const val ACTION_NEXT = "com.nextgen.play.BG_NEXT"
    const val ACTION_PREV = "com.nextgen.play.BG_PREV"
    const val ACTION_CLOSE = "com.nextgen.play.BG_CLOSE"
    @Volatile var handler: ((String) -> Unit)? = null
    @Volatile var token: MediaSession.Token? = null
}

/** Foreground service (mediaPlayback): background me audio chalte waqt notification + play/pause/next/prev/close. */
class BgPlayService : Service() {
    private val ch = "bg_play"
    private val nid = 4101

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val a = intent?.action
        if (intent != null && a == BgPlay.ACTION_SHOW) show(intent)
        else if (a != null) {
            val h = BgPlay.handler
            if (h == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }   // activity ja chuki hai
            else h(a)
        }
        return START_NOT_STICKY
    }

    private fun act(icon: Int, label: String, action: String): Notification.Action =
        Notification.Action.Builder(
            Icon.createWithResource(this, icon), label,
            PendingIntent.getService(this, action.hashCode(), Intent(this, BgPlayService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        ).build()

    private fun show(i: Intent) {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(ch) == null)
            nm.createNotificationChannel(NotificationChannel(ch, "Background play", NotificationManager.IMPORTANCE_LOW))
        val playing = i.getBooleanExtra("playing", false)
        val title = i.getStringExtra("title") ?: "NextGen Play"
        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: Intent()
        val open = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val style = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
        BgPlay.token?.let { style.setMediaSession(it) }
        val n = Notification.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_audio)
            .setContentTitle(title)
            .setContentText(if (playing) "Playing" else "Paused")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(act(R.drawable.ic_prev, "Previous", BgPlay.ACTION_PREV))
            .addAction(if (playing) act(R.drawable.ic_pause, "Pause", BgPlay.ACTION_PAUSE) else act(R.drawable.ic_play, "Play", BgPlay.ACTION_PLAY))
            .addAction(act(R.drawable.ic_next, "Next", BgPlay.ACTION_NEXT))
            .addAction(act(R.drawable.ic_close, "Close", BgPlay.ACTION_CLOSE))
            .setStyle(style)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(nid, n)
    }
}
