package com.nextgen.play

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checks what a network link really is, before the player opens it.
 *  - Follows redirects itself (also http -> https), so the player gets the final address.
 *  - Detects HLS / DASH even when the link has no .m3u8 / .mpd ending (ExoPlayer would treat it as a plain file).
 *  - If the link is a normal web page, looks inside the page for direct video addresses
 *    (og:video, <video>, <source>, .m3u8 / .mpd / .mp4 links). Sites that hide their streams behind
 *    scripts or DRM (YouTube, Instagram and similar) cannot be opened this way.
 */
object NetProbe {
    const val HTML = "text/html"
    const val HLS = "application/x-mpegURL"
    const val DASH = "application/dash+xml"
    const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** url = final address after redirects. mime = HLS, DASH, HTML or null (plain file / unknown). candidates = video links found on a page. */
    class Result(val url: String, val mime: String?, val candidates: List<String> = emptyList())

    /** Referer for a link: the page it came from, or the site's own address. */
    fun refererFor(url: String, given: String?): String {
        if (!given.isNullOrBlank()) return given
        return try { val u = URL(url); u.protocol + "://" + u.host + "/" } catch (e: Exception) { "" }
    }

    fun probe(url: String, referer: String? = null): Result {
        var cur = url
        try {
            for (hop in 0..6) {
                val c = URL(cur).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000; c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Accept", "*/*")
                c.setRequestProperty("Range", "bytes=0-4095")
                val ref = refererFor(cur, referer)
                if (ref.isNotEmpty()) c.setRequestProperty("Referer", ref)
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location"); c.disconnect()
                    if (loc.isNullOrBlank()) break
                    cur = URL(URL(cur), loc).toString(); continue
                }
                val ct = (c.contentType ?: "").lowercase()
                val stream = (if (code >= 400) c.errorStream else c.inputStream)
                val buf = ByteArrayOutputStream()
                var htmlLike = false
                try {
                    stream?.use { ins ->
                        val b = ByteArray(8192)
                        var total = 0
                        var limit = 4096
                        while (total < limit) {
                            val n = ins.read(b, 0, minOf(b.size, limit - total))
                            if (n < 0) break
                            buf.write(b, 0, n); total += n
                            if (total >= 4096 && !htmlLike) {
                                val h = buf.toString("ISO-8859-1").trimStart('﻿', ' ', '\n', '\r', '\t')
                                htmlLike = code < 400 && (ct.startsWith("text/html") || h.startsWith("<!doctype html", true) || h.startsWith("<html", true))
                                if (htmlLike) limit = 700_000        // web page: read more, to find video links inside
                            }
                        }
                    }
                } catch (e: Exception) { }
                c.disconnect()
                val text = buf.toString("UTF-8")
                val t = text.trimStart('﻿', ' ', '\n', '\r', '\t')
                val html = code < 400 && (ct.startsWith("text/html") || t.startsWith("<!doctype html", true) || t.startsWith("<html", true))
                return when {
                    t.startsWith("#EXTM3U") || ct.contains("mpegurl") -> Result(cur, HLS)
                    ct.contains("dash+xml") || t.contains("<MPD", true) -> Result(cur, DASH)
                    html -> Result(cur, HTML, findMedia(text, cur))
                    else -> Result(cur, null)
                }
            }
        } catch (e: Exception) { }
        return Result(cur, null)
    }

    private val META = listOf(
        Regex("""<meta[^>]+(?:property|name)=["']og:video(?::url|:secure_url)?["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
        Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']og:video(?::url|:secure_url)?["']""", RegexOption.IGNORE_CASE),
        Regex("""<meta[^>]+(?:property|name)=["']twitter:player:stream["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    )
    private val TAG = Regex("""<(?:video|source)\b[^>]*?\bsrc=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val RAW = Regex("""https?://[^\s"'<>\\)]+?\.(?:m3u8|mpd|mp4|webm|mkv|mov|m4v)(?:\?[^\s"'<>\\)]*)?""", RegexOption.IGNORE_CASE)

    private fun findMedia(html0: String, base: String): List<String> {
        val html = html0.replace("\\/", "/").replace("\\u002F", "/").replace("\\u0026", "&").replace("&amp;", "&")
        val found = LinkedHashSet<String>()
        fun add(s: String) {
            val x = s.trim()
            if (x.isEmpty() || x.startsWith("blob:") || x.startsWith("data:")) return
            try { found.add(URL(URL(base), x).toString()) } catch (e: Exception) { }
        }
        META.forEach { r -> r.findAll(html).forEach { add(it.groupValues[1]) } }
        TAG.findAll(html).forEach { add(it.groupValues[1]) }
        RAW.findAll(html).forEach { add(it.value) }
        // a stream playlist is better than a single file; page's own address is not a video
        return found.filter { it != base }.sortedBy { if (Regex("""\.(m3u8|mpd)(\?|$)""", RegexOption.IGNORE_CASE).containsMatchIn(it)) 0 else 1 }.take(10)
    }
}
