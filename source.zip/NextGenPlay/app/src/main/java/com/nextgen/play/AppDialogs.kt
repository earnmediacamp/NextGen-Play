package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * "All files access" (Android 11+). Mil jaye to delete / rename par Android ka confirm dialog nahi aata,
 * sirf hamara apna dialog. Nahi mile to purana system flow chalta rehta hai.
 */
object AllFiles {
    fun granted(): Boolean = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
    fun asked(c: Context): Boolean = AppSettings.sp(c).getBoolean("allfiles_asked", false)
    fun markAsked(c: Context) { AppSettings.sp(c).edit().putBoolean("allfiles_asked", true).apply() }

    /** Is app ka "All files access" wala Settings page. req >= 0 ho to result ke saath. */
    fun open(a: Activity, req: Int) {
        if (Build.VERSION.SDK_INT < 30) return
        val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + a.packageName))
        try {
            if (req >= 0) a.startActivityForResult(i, req) else a.startActivity(i)
        } catch (e: Exception) {
            try {
                val j = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                if (req >= 0) a.startActivityForResult(j, req) else a.startActivity(j)
            } catch (e2: Exception) {
                Toast.makeText(a, "Could not open Settings", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

/** App ke theme ke apne dialogs (delete confirm, permission). Share sheet ke liye ShareSheet.kt. */
object AppDialogs {
    internal fun dp(c: Context, x: Int) = (x * c.resources.displayMetrics.density).toInt()

    internal fun col(a: Activity, id: Int, fallback: Int): Int {
        val tv = TypedValue()
        return if (a.theme.resolveAttribute(id, tv, true)) tv.data else fallback
    }

    internal fun show(a: Activity, view: View, maxDp: Int = 440): AlertDialog =
        AlertDialog.Builder(a, Themes.dialog(a)).setView(view).create().also {
            it.show()
            it.window?.setLayout(minOf(dp(a, maxDp), (a.resources.displayMetrics.widthPixels * 0.94f).toInt()), -2)
        }

    /** Gol kinaare wala button. fill = null to sirf outline. */
    internal fun pill(a: Activity, label: String, fill: Int?, textColor: Int, stroke: Int, f: () -> Unit): TextView =
        TextView(a).apply {
            text = label; gravity = Gravity.CENTER; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(textColor)
            setPadding(dp(a, 18), dp(a, 11), dp(a, 18), dp(a, 11))
            background = GradientDrawable().apply {
                cornerRadius = dp(a, 12).toFloat()
                setColor(fill ?: Color.TRANSPARENT)
                setStroke(dp(a, 1), stroke)
            }
            setOnClickListener { f() }
        }

    /** Delete se pehle: video ka thumbnail, naam (3 tak), kul size. "Delete" dabane par onYes. */
    fun confirmDelete(a: Activity, vs: List<Video>, thumb: Bitmap?, onYes: () -> Unit) {
        if (vs.isEmpty()) return
        val tc = col(a, R.attr.appText, Color.WHITE)
        val tc2 = col(a, R.attr.appText2, 0xFFBBBBCC.toInt())
        val red = 0xFFE5484D.toInt()
        val line = (tc2 and 0xFFFFFF) or 0x55000000

        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 22), dp(a, 20), dp(a, 22), dp(a, 16))
        }
        val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (thumb != null) {
            head.addView(ImageView(a).apply {
                setImageBitmap(thumb); scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = LinearLayout.LayoutParams(dp(a, 84), dp(a, 54)).apply { marginEnd = dp(a, 14) }
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(a, 10).toFloat())
                    }
                }
            })
        }
        val sz = VideoInfo.size(vs.sumOf { it.size })
        head.addView(LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(TextView(a).apply {
                text = if (vs.size == 1) "Delete this video?" else "Delete " + vs.size + " videos?"
                setTextColor(tc); textSize = 19f; typeface = Typeface.DEFAULT_BOLD
            })
            if (sz.isNotEmpty()) addView(TextView(a).apply {
                text = sz; setTextColor(tc2); textSize = 13f; setPadding(0, dp(a, 2), 0, 0)
            })
        })
        box.addView(head)

        val names = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(a, 14), 0, dp(a, 4)) }
        vs.take(3).forEach { v ->
            names.addView(TextView(a).apply {
                text = v.name; setTextColor(tc); textSize = 14f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(a, 3), 0, dp(a, 3))
            })
        }
        if (vs.size > 3) names.addView(TextView(a).apply {
            text = "+ " + (vs.size - 3) + " more"; setTextColor(tc2); textSize = 13f; setPadding(0, dp(a, 3), 0, dp(a, 3))
        })
        box.addView(names)
        box.addView(TextView(a).apply {
            text = "This cannot be undone."; setTextColor(tc2); textSize = 12.5f; setPadding(0, dp(a, 8), 0, dp(a, 18))
        })

        lateinit var dlg: AlertDialog
        val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        btns.addView(pill(a, "Cancel", null, tc, line) { dlg.dismiss() })
        btns.addView(pill(a, "Delete", red, Color.WHITE, red) { dlg.dismiss(); onYes() }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(a, 10) }
        })
        box.addView(btns)
        dlg = show(a, box)
    }

    /** Ek baar: "All files access" do to delete / rename ek tap me. */
    fun askAllFiles(a: Activity, onAllow: () -> Unit, onNotNow: () -> Unit, onDismiss: () -> Unit) {
        val tc = col(a, R.attr.appText, Color.WHITE)
        val tc2 = col(a, R.attr.appText2, 0xFFBBBBCC.toInt())
        val acc = col(a, R.attr.appAccent, 0xFF5088E0.toInt())
        val line = (tc2 and 0xFFFFFF) or 0x55000000
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 22), dp(a, 20), dp(a, 22), dp(a, 16))
        }
        box.addView(TextView(a).apply {
            text = "Quick delete & rename"; setTextColor(tc); textSize = 19f; typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(a).apply {
            text = "Allow \"All files access\" and deleting or renaming your videos works in one tap, without Android " +
                "asking every time. It is used only for the videos you choose to delete or rename. " +
                "You can change this any time in Settings > Privacy."
            setTextColor(tc2); textSize = 14f; setLineSpacing(0f, 1.15f); setPadding(0, dp(a, 10), 0, dp(a, 18))
        })
        var done = false
        lateinit var dlg: AlertDialog
        val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        btns.addView(pill(a, "Not now", null, tc, line) { done = true; dlg.dismiss(); onNotNow() })
        btns.addView(pill(a, "Allow", acc, Color.WHITE, acc) { done = true; dlg.dismiss(); onAllow() }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(a, 10) }
        })
        box.addView(btns)
        dlg = show(a, box)
        dlg.setOnDismissListener { if (!done) onDismiss() }
    }
}
