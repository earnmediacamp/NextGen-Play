package com.nextgen.play

/** Privacy policy ka text. App ke Settings > Privacy me dikhta hai. Wahi text web page (privacy-policy/index.html) me bhi hai. */
object PrivacyText {
    val SECTIONS: List<Pair<String, String>> = listOf(
        "Summary" to "NextGen Play is a video player for files on your phone and links you type in yourself. It has no accounts, no ads and no analytics. We do not collect, store or sell your personal data.",
        "What stays on your phone" to "Your video list, watch history, favourites, added subtitles and settings are stored only on your phone. They are never uploaded. The app asks for permission to read videos on your device so it can list and play them, and for notifications so background play can show its controls. On Android 11 and newer you can also choose to give the app \"All files access\". It is used only to delete or rename the videos you pick, so Android does not ask each time. It is optional, can be turned off in Settings, and is never used to read or upload other files. Uninstalling the app or clearing its data deletes everything.",
        "Features that use the internet" to "Network links: when you enter a link, the app connects straight to that server. That server can see your IP address and what you request. We do not run those servers.\n\nSubtitle translation (optional): if you allow it, the text of subtitle lines is sent to Google's translation service so it can be translated. Video and audio are never sent. Google's privacy policy applies to that text. You can turn this off at any time in Settings > Privacy. Hinglish conversion happens on your phone.\n\nUpdate check: the app contacts GitHub, where releases are hosted, about once a day to see if a new version exists and to download it when you choose. GitHub can see your IP address.",
        "Ads and tracking" to "There are none. If that ever changes, this policy will be updated first and you will be asked before anything is turned on.",
        "Children" to "NextGen Play is not directed at children under 13. We collect no data from anyone, including children.",
        "Your choices" to "You can turn online translation off in Settings > Privacy, skip update checks by not using the updater, and delete all app data by clearing storage or uninstalling.",
        "Changes" to "If this policy changes, the new version will appear here with a new date.",
        "Contact" to "Questions or requests: " + AppSettings.CONTACT_EMAIL
    )
}

/** Open-source licences (Settings > Privacy me dikhta hai). README ki credits table se milta hai. */
object LicenseText {
    const val INTRO = "NextGen Play is released under GPL-3.0 because it includes NextLib, which is GPL-3.0. It stands on the work of these projects."
    val ITEMS: List<Pair<String, String>> = listOf(
        "Media3 / ExoPlayer" to "Google. Playback engine, player UI, HLS. Apache-2.0.",
        "libass" to "libass contributors. ASS/SSA subtitle rendering. ISC.",
        "ass-media" to "peerless2012. Connects libass to Media3. See its repository for the licence.",
        "NextLib" to "Anil Kumar Beesetti. FFmpeg audio and video decoders for Media3. GPL-3.0.",
        "FFmpeg" to "FFmpeg developers. The codecs inside NextLib. See NextLib.",
        "AndroidX Core, SwipeRefreshLayout" to "Google. Update install and pull to refresh. Apache-2.0.",
        "Poppins" to "Indian Type Foundry. Bundled font. SIL Open Font License 1.1.",
        "bsdiff" to "Colin Percival. Small patch updates. BSD.",
        "Google Translate web service" to "Google. Optional subtitle translation (a service, no code copied). Service terms."
    )
}
