package com.nextgen.play

/** Privacy policy ka text. App ke Settings > Privacy me dikhta hai. Wahi text web page (privacy-policy/index.html) me bhi hai. */
object PrivacyText {
    val SECTIONS: List<Pair<String, String>> = listOf(
        "Summary" to "NextGen Play is a video player for files on your phone and links you type in yourself. It has no accounts. It shows ads from Start.io on the video list. We do not collect, store or sell your personal data ourselves.",
        "What stays on your phone" to "Your video list, watch history, favourites, added subtitles and settings are stored only on your phone. They are never uploaded. The app asks for permission to read videos on your device so it can list and play them, and for notifications so background play can show its controls. On Android 11 and newer you can also choose to give the app \"All files access\". It is used only for the videos and folders you pick: to delete, rename, move or copy them, to keep them in the recycle bin, and to hide them in the private vault (a hidden folder on your own storage). Nothing in the bin or vault leaves your phone, and Android does not have to ask each time. It is optional, can be turned off in Settings, and is never used to read or upload other files. Uninstalling the app or clearing its data deletes everything.",
        "Features that use the internet" to "Network links: when you enter a link, the app connects straight to that server. That server can see your IP address and what you request. We do not run those servers.\n\nSubtitle translation (optional): if you allow it, the text of subtitle lines is sent to Google's translation service so it can be translated. Video and audio are never sent. Google's privacy policy applies to that text. You can turn this off at any time in Settings > Privacy. Hinglish conversion happens on your phone.\n\nUpdate check: the app contacts GitHub, where releases are hosted, about once a day to see if a new version exists and to download it when you choose. GitHub can see your IP address.",
        "Ads and tracking" to "NextGen Play shows one banner ad at the bottom of the video list and, at most once every 3 hours, one full-screen video ad after you finish watching a video and return to the list. You can also choose to watch rewarded videos to remove ads for a limited time (6, 12 or 24 hours); the reward is only given after you watch the video fully. Ads are never shown during playback. The app also uses Google Firebase Analytics for anonymous usage statistics such as installs and active users; it does not use your advertising ID for this. They are provided by Start.io, which may use your advertising ID, IP address and approximate device information to choose and measure ads. Depending on your region, Start.io asks for your consent first. You can reset or disable your advertising ID in your phone's Settings > Privacy > Ads. See Start.io's privacy policy (start.io/policy/privacy-policy) for details.",
        "Children" to "NextGen Play is not directed at children under 13, and ads are not meant for children.",
        "Your choices" to "You can turn online translation off in Settings > Privacy, skip update checks by not using the updater, and delete all app data by clearing storage or uninstalling.",
        "Changes" to "If this policy changes, the new version will appear here with a new date.",
        "Contact" to "Questions or requests: " + AppSettings.CONTACT_EMAIL
    )
}

/** Open-source licences (Settings > Privacy me dikhta hai). README ki credits table se milta hai. */
object LicenseText {
    const val INTRO = "NextGen Play's own code is MIT licensed. It stands on the work of these projects, which keep their own licences."
    val ITEMS: List<Pair<String, String>> = listOf(
        "Media3 / ExoPlayer" to "Google. Playback engine, player UI, HLS. Apache-2.0.",
        "libass" to "libass contributors. ASS/SSA subtitle rendering. ISC.",
        "ass-media" to "peerless2012. Connects libass to Media3. MIT.",
        "FFmpeg" to "FFmpeg developers. Audio decoders (AC3, EAC3, DTS, TrueHD...), built from FFmpeg source (tag n6.0) with GPL and non-free parts disabled (LGPL-2.1+). Source: ffmpeg.org. The build script is tools/build_ffmpeg_lgpl.sh in the project repository, so the libraries can be rebuilt.",
        "Firebase Analytics" to "Google. Anonymous usage statistics (installs, active users, app version, country, rewarded-video use). Proprietary SDK, used under Google terms; it is not part of the open-source code.",
        "Start.io SDK" to "Start.io. Ads. Proprietary SDK, used under Start.io's terms; it is not part of the open-source code.",
        "AndroidX Core, SwipeRefreshLayout" to "Google. Update install and pull to refresh. Apache-2.0.",
        "Poppins" to "Indian Type Foundry. Bundled font. SIL Open Font License 1.1.",
        "bsdiff" to "Colin Percival. Small patch updates. BSD.",
        "Google Translate web service" to "Google. Optional subtitle translation (a service, no code copied). Service terms."
    )
}
