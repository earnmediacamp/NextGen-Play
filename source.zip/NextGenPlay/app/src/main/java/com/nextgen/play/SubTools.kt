package com.nextgen.play

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/** Subtitle text se timing nikalna (auto sync ke liye). Sirf srt / vtt / ass. */
object SubParse {
    val tsRe = Regex("""((?:\d+:)?\d+:\d{2}[,.]\d{1,3})(\s*-->\s*)((?:\d+:)?\d+:\d{2}[,.]\d{1,3})""")
    private val tsPart = Regex("""(?:(\d+):)?(\d+):(\d{2})[,.](\d{1,3})""")
    private val assPart = Regex("""(\d+):(\d{2}):(\d{2})[.:](\d{1,2})""")
    private val assDlg = Regex("""^\s*Dialogue:[^,]*,(\d+:\d{2}:\d{2}[.:]\d{1,2}),(\d+:\d{2}:\d{2}[.:]\d{1,2}),(.*)$""")
    private val drawRe = Regex("""\\p[1-9]""")
    private val braces = Regex("""\{[^}]*\}""")

    fun ts(s: String): Long {
        val m = tsPart.matchEntire(s.trim()) ?: return 0L
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        return ((h * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(3, '0').toLong()
    }

    fun ass(s: String): Long {
        val m = assPart.matchEntire(s.trim()) ?: return 0L
        return ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toLong()) * 60 + m.groupValues[3].toLong()) * 1000 +
            m.groupValues[4].padEnd(2, '0').toLong() * 10
    }

    /** Har subtitle line ka [start, end] ms me. Unsupported kind (ttml) par khali list. */
    fun intervals(text: String, kind: String): List<LongArray> {
        val out = ArrayList<LongArray>()
        when (kind) {
            "ass" -> for (line in text.lineSequence()) {
                val m = assDlg.matchEntire(line) ?: continue
                val parts = m.groupValues[3].split(",", limit = 7)
                val body = if (parts.size == 7) parts[6] else ""
                if (drawRe.containsMatchIn(body)) continue           // vector drawing, bolne wali line nahi
                if (braces.replace(body, "").isBlank()) continue
                val a = ass(m.groupValues[1]); val b = ass(m.groupValues[2])
                if (b > a) out.add(longArrayOf(a, b))
            }
            "srt", "vtt" -> for (m in tsRe.findAll(text)) {
                val a = ts(m.groupValues[1]); val b = ts(m.groupValues[3])
                if (b > a) out.add(longArrayOf(a, b))
            }
        }
        return out
    }
}

/**
 * Subtitle auto sync: video ki awaaz me speech kahan hai (band-pass energy) ko subtitle ke "bol rahe hain" signal se
 * cross-correlate karke delay nikalta hai. Do jagah (shuru + beech) check karke speed (fps mismatch) bhi nikalta hai.
 */
object AutoSync {
    class Result(val delayMs: Long, val speed: Double, val note: String)
    class Fail(msg: String) : Exception(msg)

    private const val HOP = 40                  // ms, 25 features / second
    private const val MIN_RATIO = 1.8           // best peak / second-best peak
    private const val MIN_Z = 5.0               // best peak z-score

    private class Peak(val k: Int, val ratio: Double)

    fun run(ctx: Context, uri: String, durMs: Long, subs: List<LongArray>, progress: (Int) -> Unit, cancelled: () -> Boolean): Result {
        if (subs.size < 20) throw Fail("Too few subtitle lines to sync.")
        val maxEnd = subs.maxOf { it[1] }
        val dur = if (durMs > 0) durMs else maxEnd + 60_000L
        val win = 6 * 60_000L
        val plan = ArrayList<LongArray>()                   // [start, length]
        if (dur >= 16 * 60_000L) {
            val aS = (dur * 0.04).toLong().coerceIn(30_000L, 120_000L)
            val bS = minOf((dur * 0.62).toLong(), dur - win - 90_000L)
            plan.add(longArrayOf(aS, win))
            if (bS > aS + win + 120_000L) plan.add(longArrayOf(bS, win))
        } else {
            plan.add(longArrayOf(0L, minOf(dur, 12 * 60_000L)))
        }
        val totalH = ((maxEnd + 400_000L) / HOP).toInt() + 1
        val sub = FloatArray(totalH)
        for (iv in subs) {
            val a = (iv[0] / HOP).toInt().coerceAtLeast(0)
            val b = (iv[1] / HOP).toInt().coerceAtMost(totalH - 1)
            var h = a
            while (h <= b) { sub[h] = 1f; h++ }
        }
        val peaks = ArrayList<Peak?>()
        var centerK = 0
        for ((n, p) in plan.withIndex()) {
            val feat = features(ctx, uri, p[0], p[1], { f -> progress(((n + f) / plan.size * 92f).toInt()) }, cancelled)
            val a = speech(feat)
            val radius = (if (n == 0) 90_000 else 60_000) / HOP
            val pk = search(a, sub, (p[0] / HOP).toInt(), centerK, radius)
            peaks.add(pk)
            if (n == 0 && pk != null) centerK = pk.k
        }
        progress(100)
        val pa = peaks.getOrNull(0)
        val pb = peaks.getOrNull(1)
        val ta = plan[0][0] + plan[0][1] / 2.0
        if (pa != null && pb != null) {
            val tb = plan[1][0] + plan[1][1] / 2.0
            val dA = pa.k.toDouble() * HOP
            val dB = pb.k.toDouble() * HOP
            // sub ka asli time t, audio me T = t + d. Do points (tA, TA) aur (tB, TB) se T = s*t + D.
            val tA = ta - dA
            val tB = tb - dB
            val s = (tb - ta) / (tB - tA)
            if (abs(dB - dA) >= 400.0 && s in 0.9..1.1 && abs(s - 1.0) >= 0.0005) {
                val d = ta - s * tA
                return Result(d.toLong(), s, "Delay " + fmt(d.toLong()) + ", speed " + String.format(java.util.Locale.US, "%.4fx", s))
            }
            val d = ((dA + dB) / 2).toLong()
            return Result(d, 1.0, "Delay " + fmt(d))
        }
        val one = pa ?: pb ?: throw Fail("Could not find a sync. The subtitle may not belong to this video, or there is very little speech.")
        val d = one.k.toLong() * HOP
        return Result(d, 1.0, "Delay " + fmt(d))
    }

    private fun fmt(ms: Long) = (if (ms > 0) "+" else "") + String.format(java.util.Locale.US, "%.2f s", ms / 1000.0)

    /** Energy (log) ko 0..1 "speech" signal me badalna. */
    private fun speech(e: FloatArray): FloatArray {
        val s = e.copyOf()
        s.sort()
        val lo = s[(s.size * 0.20).toInt().coerceIn(0, s.size - 1)]
        val hi = s[(s.size * 0.92).toInt().coerceIn(0, s.size - 1)]
        val d = maxOf(hi - lo, 0.5f)
        return FloatArray(e.size) { ((e[it] - lo) / d).coerceIn(0f, 1f) }
    }

    /** Subtitle ko k hops (k*40ms) late karke audio se match score; best k (confident ho tabhi). */
    private fun search(a: FloatArray, sub: FloatArray, wsH: Int, center: Int, radius: Int): Peak? {
        val n = a.size
        var mean = 0.0
        for (v in a) mean += v
        mean /= n
        val c = FloatArray(n) { (a[it] - mean).toFloat() }
        val cnt = 2 * radius + 1
        val sc = DoubleArray(cnt)
        for (j in 0 until cnt) {
            val k = center - radius + j
            val lo = wsH - k
            val i0 = maxOf(0, -lo)
            val i1 = minOf(n, sub.size - lo)
            var s = 0.0
            var i = i0
            while (i < i1) { s += c[i] * sub[lo + i]; i++ }
            sc[j] = s
        }
        var b = 0
        for (j in 1 until cnt) if (sc[j] > sc[b]) b = j
        var m = 0.0
        for (v in sc) m += v
        m /= cnt
        var vr = 0.0
        for (v in sc) vr += (v - m) * (v - m)
        val sd = sqrt(vr / cnt)
        var second = -Double.MAX_VALUE
        for (j in 0 until cnt) if (abs(j - b) > 25 && sc[j] > second) second = sc[j]
        val ratio = if (second - m <= 1e-9) 99.0 else (sc[b] - m) / (second - m)
        val z = (sc[b] - m) / (sd + 1e-9)
        if (b == 0 || b == cnt - 1) return null             // search range ke kinare par = bharosa nahi
        if (sc[b] <= 0.0 || ratio < MIN_RATIO || z < MIN_Z) return null
        return Peak(center - radius + b, ratio)
    }

    private class Biquad(private val b0: Double, private val b1: Double, private val b2: Double, private val a1: Double, private val a2: Double) {
        private var z1 = 0.0
        private var z2 = 0.0
        fun p(x: Double): Double {
            val y = b0 * x + z1
            z1 = b1 * x - a1 * y + z2
            z2 = b2 * x - a2 * y
            return y
        }
        companion object {
            fun low(f: Double, sr: Int): Biquad {
                val w = 2 * PI * f / sr
                val al = sin(w) / (2 * 0.7071)
                val c = cos(w)
                val a0 = 1 + al
                return Biquad((1 - c) / 2 / a0, (1 - c) / a0, (1 - c) / 2 / a0, -2 * c / a0, (1 - al) / a0)
            }
            fun high(f: Double, sr: Int): Biquad {
                val w = 2 * PI * f / sr
                val al = sin(w) / (2 * 0.7071)
                val c = cos(w)
                val a0 = 1 + al
                return Biquad((1 + c) / 2 / a0, -(1 + c) / a0, (1 + c) / 2 / a0, -2 * c / a0, (1 - al) / a0)
            }
        }
    }

    private class Feat(val nH: Int, val startUs: Long) {
        val sumSq = DoubleArray(nH)
        val cnt = IntArray(nH)
        private var sr = 48000
        private var dec = 1
        private var hp: Biquad? = null
        private var lp: Biquad? = null
        private var accS = 0.0
        private var accN = 0

        fun setRate(rate: Int) {
            sr = rate
            dec = maxOf(1, rate / 16000)
            val eff = rate / dec
            hp = Biquad.high(300.0, eff)
            lp = Biquad.low(minOf(3400.0, eff * 0.45), eff)
        }

        fun feed(ob: ByteBuffer, off: Int, size: Int, ptsUs: Long, ch: Int, flt: Boolean) {
            val h = hp ?: return
            val l = lp ?: return
            ob.position(off)
            ob.limit(off + size)
            ob.order(ByteOrder.nativeOrder())
            val frames = size / ((if (flt) 4 else 2) * ch)
            val fb = if (flt) ob.asFloatBuffer() else null
            val sb = if (!flt) ob.asShortBuffer() else null
            var idx = 0
            for (f in 0 until frames) {
                var m = 0.0
                for (c in 0 until ch) {
                    m += if (fb != null) fb.get(idx).toDouble() else (sb?.get(idx)?.toDouble() ?: 0.0) / 32768.0
                    idx++
                }
                m /= ch
                accS += m
                accN++
                if (accN >= dec) {
                    val x = accS / accN
                    accS = 0.0
                    accN = 0
                    val y = l.p(h.p(x))
                    val tUs = ptsUs + (f.toLong() * 1_000_000L) / sr
                    if (tUs >= startUs) {
                        val hop = ((tUs - startUs) / 1000L / HOP).toInt()
                        if (hop in 0 until nH) { sumSq[hop] += y * y; cnt[hop]++ }
                    }
                }
            }
        }
    }

    /** [startMs, startMs+lenMs) ka speech-band log energy, har 40ms ke liye. */
    private fun features(ctx: Context, uri: String, startMs: Long, lenMs: Long, prog: (Float) -> Unit, cancelled: () -> Boolean): FloatArray {
        val nH = (lenMs / HOP).toInt()
        if (nH < 50) throw Fail("Video is too short to sync.")
        val feat = Feat(nH, startMs * 1000L)
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            try {
                if (uri.startsWith("http", true)) ex.setDataSource(uri) else ex.setDataSource(ctx, Uri.parse(uri), null)
            } catch (e: Exception) { throw Fail("Could not open the video file.") }
            var inFmt: MediaFormat? = null
            for (t in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(t)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("audio/")) continue
                var c: MediaCodec? = null
                try {
                    c = MediaCodec.createDecoderByType(mime)
                    c.configure(f, null, null, 0)
                } catch (e: Exception) {
                    try { c?.release() } catch (e2: Exception) { }
                    continue
                }
                codec = c
                inFmt = f
                ex.selectTrack(t)
                break
            }
            val cd = codec ?: throw Fail("No decoder for this video's audio format on this phone.")
            val fmt = inFmt ?: throw Fail("No audio track found in the video.")
            var sr = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48000
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var flt = false
            feat.setRate(sr)
            val startUs = startMs * 1000L
            val endUs = (startMs + lenMs) * 1000L
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            cd.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var idle = 0
            while (!outDone) {
                if (cancelled()) throw Fail("Cancelled")
                if (!inDone) {
                    val ii = cd.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = cd.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        val st = ex.sampleTime
                        if (n < 0 || st < 0 || st > endUs) {
                            cd.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            cd.queueInputBuffer(ii, 0, n, st, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = cd.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = cd.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    flt = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    feat.setRate(sr)
                    idle = 0
                } else if (oi >= 0) {
                    idle = 0
                    val ob = cd.getOutputBuffer(oi)
                    if (ob != null && info.size > 0 && ch > 0) feat.feed(ob, info.offset, info.size, info.presentationTimeUs, ch, flt)
                    cd.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    prog(((info.presentationTimeUs - startUs).toFloat() / (lenMs * 1000f)).coerceIn(0f, 1f))
                } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER && inDone) {
                    if (++idle > 300) outDone = true        // decoder ruk gaya: jo mila usse kaam chalao
                }
            }
        } catch (e: Fail) {
            throw e
        } catch (e: Exception) {
            throw Fail("Could not decode audio (" + (e.message ?: e.javaClass.simpleName) + ").")
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            try { codec?.release() } catch (e: Exception) { }
            try { ex.release() } catch (e: Exception) { }
        }
        val e = FloatArray(nH)
        var minV = Float.MAX_VALUE
        var valid = 0
        for (i in 0 until nH) {
            if (feat.cnt[i] > 0) {
                e[i] = ln(1e-10 + feat.sumSq[i] / feat.cnt[i]).toFloat()
                if (e[i] < minV) minV = e[i]
                valid++
            }
        }
        if (valid < nH * 0.6) throw Fail("Audio was not fully decoded (only $valid / $nH).")
        for (i in 0 until nH) if (feat.cnt[i] == 0) e[i] = minV
        return e
    }
}

/** Subtitle translate (Google Translate ka free web endpoint, sirf INTERNET permission). */
object SubTranslate {
    class Err(msg: String) : Exception(msg)

    val LANGS: List<Pair<String, String>> = listOf(
        "English" to "en", "Hindi" to "hi", "Hinglish (Hindi, English letters)" to "hi-Latn", "Urdu" to "ur", "Bengali" to "bn", "Marathi" to "mr", "Gujarati" to "gu",
        "Punjabi" to "pa", "Tamil" to "ta", "Telugu" to "te", "Kannada" to "kn", "Malayalam" to "ml", "Nepali" to "ne",
        "Arabic" to "ar", "Indonesian" to "id", "Malay" to "ms", "Filipino" to "tl", "Thai" to "th", "Vietnamese" to "vi",
        "Japanese" to "ja", "Korean" to "ko", "Chinese (Simplified)" to "zh-CN", "Spanish" to "es", "Portuguese" to "pt",
        "French" to "fr", "German" to "de", "Italian" to "it", "Russian" to "ru", "Turkish" to "tr"
    )

    fun langName(code: String): String = LANGS.firstOrNull { it.second == code }?.first ?: code

    private val leadTags = Regex("""^(\{[^}]*\})+""")
    private val anyBrace = Regex("""\{[^}]*\}""")
    private val htmlTag = Regex("""<[^>]*>""")
    private val spaces = Regex("""\s+""")
    private val drawRe = Regex("""\\p[1-9]""")

    // ---------- network ----------
    private fun post(q: String, lang: String): String {
        val c = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + URLEncoder.encode(lang, "UTF-8") +
            "&dt=t&ie=UTF-8&oe=UTF-8").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            c.outputStream.use { it.write(("q=" + URLEncoder.encode(q, "UTF-8")).toByteArray(Charsets.UTF_8)) }
            if (c.responseCode != 200) throw Err("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun parse(body: String): String {
        val segs = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segs.length()) {
            val s = segs.optJSONArray(i) ?: continue
            sb.append(s.optString(0, ""))
        }
        return sb.toString()
    }

    private fun call(q: String, lang: String): String {
        // Hinglish = Hindi me translate karke Roman letters me badalna (Google ke paas Hinglish target nahi hai)
        val hinglish = lang == "hi-Latn"
        val tl = if (hinglish) "hi" else lang
        for (attempt in 0 until 3) {
            try {
                val r = parse(post(q, tl))
                return if (hinglish) Hinglish.convert(r) else r
            } catch (e: Exception) {
                try { Thread.sleep(400L * (attempt + 1)) } catch (ie: InterruptedException) { break }
            }
        }
        throw Err("No response from the translate server. Check your internet and try again.")
    }

    private fun one(t: String, lang: String): String = call(t, lang).replace("\n", " ").trim()

    /** Ek request me kai lines (har line = ek subtitle). Line count na mile to line-by-line fallback. */
    private fun batch(part: List<String>, lang: String): List<String> {
        if (part.size == 1) return listOf(one(part[0], lang))
        var lines = call(part.joinToString("\n"), lang).split("\n")
        if (lines.isNotEmpty() && lines.last().isEmpty()) lines = lines.dropLast(1)
        if (lines.size == part.size) return lines.map { it.trim() }
        return part.map { one(it, lang) }
    }

    /** texts me newline nahi hona chahiye. Result same order / same size. */
    fun translateAll(texts: List<String>, lang: String, progress: (Int) -> Unit, cancelled: () -> Boolean): List<String> {
        if (texts.isEmpty()) return emptyList()
        val batches = ArrayList<IntRange>()
        var s = 0
        var chars = 0
        for (i in texts.indices) {
            chars += texts[i].length + 1
            if (chars > 2500 || i - s + 1 >= 40) { batches.add(s..i); s = i + 1; chars = 0 }
        }
        if (s < texts.size) batches.add(s until texts.size)
        val out = arrayOfNulls<String>(texts.size)
        val err = AtomicReference<Exception?>(null)
        val done = AtomicInteger(0)
        val latch = CountDownLatch(batches.size)
        val pool = Executors.newFixedThreadPool(3)
        try {
            for (r in batches) {
                pool.execute {
                    try {
                        if (!cancelled() && err.get() == null) {
                            val res = batch(texts.subList(r.first, r.last + 1), lang)
                            for ((j, t) in res.withIndex()) out[r.first + j] = t
                            progress(done.incrementAndGet() * 100 / batches.size)
                        }
                    } catch (e: Exception) {
                        err.compareAndSet(null, e)
                    } finally {
                        latch.countDown()
                    }
                }
            }
            latch.await()
        } finally {
            pool.shutdownNow()
        }
        if (cancelled()) throw Err("Cancelled")
        err.get()?.let { throw it }
        return out.map { it ?: "" }
    }

    // ---------- whole subtitle file ----------
    fun translateFile(text: String, kind: String, lang: String, progress: (Int) -> Unit, cancelled: () -> Boolean): String = when (kind) {
        "srt", "vtt" -> fileSrt(text, lang, progress, cancelled)
        "ass" -> fileAss(text, lang, progress, cancelled)
        else -> throw Err("Translation is not supported for this subtitle format (SRT, VTT and ASS work).")
    }

    private fun clean(s: String) = spaces.replace(htmlTag.replace(anyBrace.replace(s, ""), ""), " ").trim()

    private fun fileSrt(text: String, lang: String, progress: (Int) -> Unit, cancelled: () -> Boolean): String {
        val nl = if (text.contains("\r\n")) "\r\n" else "\n"
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split("\n")
        val starts = ArrayList<Int>()
        val ends = ArrayList<Int>()
        var i = 0
        while (i < lines.size) {
            if (SubParse.tsRe.containsMatchIn(lines[i])) {
                var j = i + 1
                while (j < lines.size && lines[j].isNotBlank()) j++
                if (j > i + 1) { starts.add(i + 1); ends.add(j) }
                i = j
            } else i++
        }
        val keys = ArrayList<String>()
        val leads = ArrayList<String>()
        for (c in starts.indices) {
            val joined = lines.subList(starts[c], ends[c]).joinToString(" ")
            keys.add(clean(joined))
            leads.add(leadTags.find(joined)?.value ?: "")
        }
        val uniq = LinkedHashMap<String, Int>()
        for (k in keys) if (k.isNotEmpty() && !uniq.containsKey(k)) uniq[k] = uniq.size
        if (uniq.isEmpty()) throw Err("No translatable text found in the subtitle.")
        val tr = translateAll(uniq.keys.toList(), lang, progress, cancelled)
        val out = ArrayList<String>(lines.size)
        var c = 0
        var li = 0
        while (li < lines.size) {
            if (c < starts.size && li == starts[c]) {
                val t = if (keys[c].isEmpty()) "" else tr[uniq[keys[c]] ?: 0]
                if (t.isBlank()) { for (x in starts[c] until ends[c]) out.add(lines[x]) }
                else out.add(leads[c] + t)
                li = ends[c]
                c++
            } else {
                out.add(lines[li])
                li++
            }
        }
        return out.joinToString(nl)
    }

    private fun fileAss(text: String, lang: String, progress: (Int) -> Unit, cancelled: () -> Boolean): String {
        val nl = if (text.contains("\r\n")) "\r\n" else "\n"
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split("\n")
        val idxs = ArrayList<Int>()
        val heads = ArrayList<String>()
        val leads = ArrayList<String>()
        val keys = ArrayList<String>()
        for ((i, line) in lines.withIndex()) {
            if (!line.trimStart().startsWith("Dialogue:", true)) continue
            val parts = line.split(",", limit = 10)
            if (parts.size < 10) continue
            val raw = parts[9]
            if (drawRe.containsMatchIn(raw)) continue
            val key = spaces.replace(anyBrace.replace(raw, "").replace("\\N", " ").replace("\\n", " ").replace("\\h", " "), " ").trim()
            if (key.isEmpty()) continue
            idxs.add(i)
            heads.add(parts.subList(0, 9).joinToString(","))
            leads.add(leadTags.find(raw)?.value ?: "")
            keys.add(key)
        }
        val uniq = LinkedHashMap<String, Int>()
        for (k in keys) if (!uniq.containsKey(k)) uniq[k] = uniq.size
        if (uniq.isEmpty()) throw Err("No translatable text found in the subtitle.")
        val tr = translateAll(uniq.keys.toList(), lang, progress, cancelled)
        val out = lines.toMutableList()
        for (n in idxs.indices) {
            val t = tr[uniq[keys[n]] ?: 0]
            if (t.isBlank()) continue
            out[idxs[n]] = heads[n] + "," + leads[n] + t.replace("\n", "\\N")
        }
        return out.joinToString(nl)
    }
}
