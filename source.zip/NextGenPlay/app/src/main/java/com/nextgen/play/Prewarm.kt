package com.nextgen.play

import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil

/**
 * Runs once when the library opens, on a background thread, so the first video starts faster:
 * the phone's decoder list is read now (it takes a few hundred ms the first time) and the player classes are loaded.
 */
@androidx.annotation.OptIn(UnstableApi::class)
object Prewarm {
    @Volatile private var started = false

    fun start() {
        if (started) return
        started = true
        Thread {
            try { Thread.currentThread().priority = Thread.MIN_PRIORITY } catch (e: Exception) { }
            listOf("video/avc", "video/hevc", "video/x-vnd.on2.vp9", "video/av01", "audio/mp4a-latm", "audio/ac3", "audio/eac3", "audio/opus")
                .forEach { m ->
                    try { MediaCodecUtil.getDecoderInfos(m, false, false) } catch (e: Throwable) { }
                }
            listOf(
                "androidx.media3.exoplayer.ExoPlayerImpl",
                "androidx.media3.exoplayer.DefaultLoadControl",
                "androidx.media3.exoplayer.source.DefaultMediaSourceFactory",
                "androidx.media3.extractor.DefaultExtractorsFactory",
                "androidx.media3.exoplayer.video.MediaCodecVideoRenderer",
                "androidx.media3.exoplayer.audio.MediaCodecAudioRenderer"
            ).forEach { n -> try { Class.forName(n) } catch (e: Throwable) { } }
        }.start()
    }
}
