package com.nextgen.play

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.Video.Media
import android.provider.MediaStore.Video.Thumbnails
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.GridView
import android.media.MediaScannerConnection
import android.media.MediaExtractor
import android.media.MediaFormat
import java.text.DateFormat
import java.util.Date
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

class Video(
    val id: Long, val uri: String, val name: String, val dur: Long, val folder: String,
    val size: Long = 0L, val path: String = "", val added: Long = 0L, val w: Int = 0, val h: Int = 0
) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
}
class Folder(val name: String, val videos: List<Video>)

class MainActivity : Activity() {

    private val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    private val cache = LruCache<String, Bitmap>(120)
    private val pool = Executors.newFixedThreadPool(4)
    private var all = listOf<Video>()
    private var folders = listOf<Folder>()
    private var openName: String? = null
    private val prefs by lazy { getSharedPreferences("set", MODE_PRIVATE) }
    private val TREE = "\u0000tree-view"
    private var treeDir: String? = null
    private val fpsMap = HashMap<String, Float>()
    private val fpsPending = HashSet<String>()
    private val HIDROW = "\u0000hidden-row"
    private var showHid = false
    private val blue by lazy { attr(R.attr.appAccent) }      // accent (theme ke hisab se)
    private val txt by lazy { attr(R.attr.appText) }
    private fun attr(a: Int): Int {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(a, tv, true)
        return tv.data
    }
    private val grey = 0xFF6B6B7A.toInt()
    private val FAV = "\u2605 Favourites"
    private val ALLV = "\u0000all-videos"
    private val DLG: Int get() = Themes.dialog(this)

    /** "NG" safed + "PLAY" accent colour (chhota naam, header me poora dikhta hai). */
    private fun brand(): CharSequence = android.text.SpannableString("NG PLAY").apply {
        setSpan(android.text.style.ForegroundColorSpan(blue), 3, 7, 0)
    }

    // multiselect / search / pending system-dialog actions
    private val sel = LinkedHashSet<String>()
    private var selecting = false
    private var curVids = listOf<Video>()
    private var query = ""
    private var searchFolder: String? = null          // folder ke andar se search khola ho to sirf usi folder me dhoondo
    private val statCache = HashMap<String, String>()  // folder card ka "watched / new" text (render ke time reset)
    private lateinit var folderBar: View
    private lateinit var folderInfo: TextView
    private lateinit var btnResume: TextView
    private lateinit var btnPlayAll: TextView
    private var pendingDel: List<String> = emptyList()
    private var pendingRename: Pair<Video, String>? = null
    private var afterPerm: (() -> Unit)? = null
    private val REQ_DEL = 10
    private val REQ_DEL29 = 11
    private val REQ_REN = 12
    private val REQ_REN29 = 13
    private val REQ_ALL = 14                      // "All files access" Settings page se wapsi
    private var afterGrant: (() -> Unit)? = null
    private var renameViaPrompt = false

    private lateinit var list: GridView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var titleTv: TextView
    private lateinit var sortBtn: TextView
    private lateinit var searchBtn: View
    private lateinit var homeBack: View
    private lateinit var searchBox: EditText
    private lateinit var header: View
    private lateinit var selBar: View
    private lateinit var selCount: TextView
    private lateinit var recent: android.widget.LinearLayout
    private lateinit var recentBox: View
    private lateinit var recentHdr: TextView
    private lateinit var recentScroll: View
    private var shownVmode = -1

    /** Continue Watching row ka open / band hona (header tap ya Settings se). */
    private fun updRecent() {
        val open = AppSettings.CONT_RECENT.get(this)
        recentScroll.visibility = if (open) View.VISIBLE else View.GONE
        recentHdr.text = (if (open) "\u25BE  " else "\u25B8  ") + "Continue Watching"
    }

    override fun onCreate(b: Bundle?) {
        setTheme(if (Themes.light(this)) R.style.Theme_NextGenPlay_Light else R.style.Theme_NextGenPlay)
        Themes.applyAccent(this)
        themeSig = Themes.sig(this)
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.menuBtn).setOnClickListener { openMenu() }
        list = findViewById(R.id.list)
        list.isFastScrollEnabled = true
        folderBar = findViewById(R.id.folderBar)
        folderInfo = findViewById(R.id.folderInfo)
        btnResume = findViewById(R.id.btnResume)
        btnPlayAll = findViewById(R.id.btnPlayAll)
        swipe = findViewById(R.id.swipe)
        swipe.setColorSchemeColors(blue)
        swipe.setProgressBackgroundColorSchemeColor(attr(R.attr.appSurface2))
        swipe.setOnRefreshListener { refresh() }
        titleTv = findViewById(R.id.title)
        sortBtn = findViewById(R.id.sortBtn)
        searchBtn = findViewById(R.id.searchBtn)
        searchBox = findViewById(R.id.searchBox)
        header = findViewById(R.id.header)
        selBar = findViewById(R.id.selBar)
        selCount = findViewById(R.id.selCount)
        selCount.setOnClickListener { val v = selVideos(); if (v.size == 1) showInfo(v) }
        recent = findViewById(R.id.recent)
        recentBox = findViewById(R.id.recentBox)
        homeBack = findViewById(R.id.homeBack)
        homeBack.setOnClickListener { onBackPressed() }
        titleTv.text = brand()
        recentHdr = findViewById(R.id.recentHdr)
        recentScroll = findViewById(R.id.recentScroll)
        updRecent()
        recentHdr.setOnClickListener { AppSettings.CONT_RECENT.set(this, !AppSettings.CONT_RECENT.get(this)); updRecent() }
        sortBtn.setOnClickListener { openLibMenu() }
        openName = when (Lib.vmode(this)) { 1 -> ALLV; 2 -> TREE; else -> null }
        shownVmode = Lib.vmode(this)
        getSharedPreferences("fpsc", MODE_PRIVATE).all.forEach { (k, v) -> if (v is Float) fpsMap[k] = v }

        // search
        searchBtn.setOnClickListener {
            if (searchBox.visibility == View.VISIBLE) closeSearch()
            else {
                searchFolder = openName?.takeIf { it != ALLV && it != TREE && it != FAV }
                searchBox.hint = searchFolder?.let { "Search in " + it.substringAfterLast('/') } ?: "Search videos"
                searchBox.visibility = View.VISIBLE
                searchBox.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox, 0)
            }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s.toString().trim(); clearSel(); render() }
        })

        // multiselect bar
        findViewById<View>(R.id.selClose).setOnClickListener { clearSel() }
        findViewById<View>(R.id.selAll).setOnClickListener {
            curVids.forEach { sel.add(it.uri) }; selecting = sel.isNotEmpty(); refreshSel()
        }
        findViewById<View>(R.id.selShare).setOnClickListener { ShareSheet.show(this, selVideos().map { Uri.parse(it.uri) }) }
        findViewById<View>(R.id.selDel).setOnClickListener { deleteSelected() }
        findViewById<View>(R.id.selMore).setOnClickListener { moreMenu() }

        Updater.check(this, false)
        Prewarm.start()
        handleShare(intent)

        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(perm), 1)
    }

    private var themeSig = ""

    // ---- real-time resume: player history badalte hi library refresh (PiP / wapas aane par bhi) ----
    private var lastEntry: Entry? = null
    private var lastVideo: Video? = null
    private var recentSig = ""
    private val liveHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val liveRun = Runnable { liveRefresh() }
    private val histListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        liveHandler.removeCallbacks(liveRun); liveHandler.postDelayed(liveRun, 250)
    }

    override fun onStart() {
        super.onStart()
        History.prefs(this).registerOnSharedPreferenceChangeListener(histListener)
    }

    override fun onStop() {
        super.onStop()
        History.prefs(this).unregisterOnSharedPreferenceChangeListener(histListener)
        liveHandler.removeCallbacks(liveRun)
    }

    /** Sabse latest dekhi hui video (jo library me hai aur hidden nahi) = us folder par resume indicator. */
    private fun computeLast() {
        val byUri = HashMap<String, Video>()
        all.forEach { byUri[it.uri] = it }
        val h = hid()
        val e = History.recent(this, 30).firstOrNull { x -> byUri[x.uri]?.let { v -> showHid || v.folder !in h } == true }
        lastEntry = e
        lastVideo = e?.let { byUri[it.uri] }
    }

    private fun liveRefresh() {
        if (isDestroyed || isFinishing || all.isEmpty()) return
        computeLast()
        (list.adapter as? BaseAdapter)?.notifyDataSetChanged()
        if (openName == null && query.isEmpty()) showRecent()
    }

    override fun onResume() {
        super.onResume()
        if (themeSig != Themes.sig(this)) { recreate(); return }      // ThemeActivity me theme / accent badla
        Updater.resume(this)
        Updater.check(this, false)                                     // app wapas khulte hi naya update ho to popup
        updRecent()                                                    // Settings me Continue Watching badla ho to
        if (Lib.vmode(this) != shownVmode) {                           // Settings me view mode badla ho to
            shownVmode = Lib.vmode(this)
            openName = when (shownVmode) { 1 -> ALLV; 2 -> TREE; else -> null }
            treeDir = null
            clearSel()
        }
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 2) {
            val next = afterPerm; afterPerm = null
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) next?.invoke()
            else Toast.makeText(this, "Permission needed", Toast.LENGTH_LONG).show()
            return
        }
        if (r.isEmpty() || r[0] != PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Permission is needed to show your videos", Toast.LENGTH_LONG).show()
    }

    override fun onBackPressed() {
        when {
            selecting -> clearSel()
            searchBox.visibility == View.VISIBLE -> closeSearch()
            openName == TREE -> when {
                treeDir != null -> treeUp()
                Lib.vmode(this) == 2 -> super.onBackPressed()
                else -> { openName = null; render() }
            }
            openName != null -> { openName = null; render() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }

    private fun closeSearch() {
        query = ""
        searchFolder = null
        searchBox.hint = "Search videos"
        searchBox.setText("")
        searchBox.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchBox.windowToken, 0)
        render()
    }

    // ---------- data ----------
    /** Pull to refresh: nayi / delete hui files MediaStore me scan karke list dobara banata hai. */
    private fun refresh() {
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) { swipe.isRefreshing = false; return }
        val known = all.map { it.path }.filter { it.isNotEmpty() }
        pool.execute {
            val exts = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "ts", "flv", "wmv", "mpg", "mpeg")
            val toScan = LinkedHashSet<String>()
            val knownSet = known.toHashSet()
            known.forEach { if (!File(it).exists()) toScan += it }          // delete ho chuki files (list se hategi)
            known.mapNotNull { File(it).parentFile }.distinct().forEach { d ->
                d.listFiles()?.forEach { f ->
                    if (f.isFile && f.extension.lowercase() in exts && f.path !in knownSet) toScan += f.path   // nayi files
                }
            }
            if (toScan.isNotEmpty()) {
                val latch = CountDownLatch(toScan.size)
                try {
                    MediaScannerConnection.scanFile(this, toScan.toTypedArray(), null) { _, _ -> latch.countDown() }
                    latch.await(6, TimeUnit.SECONDS)
                } catch (e: Exception) { }
            }
            runOnUiThread {
                if (!isDestroyed) {
                    load()
                    swipe.isRefreshing = false
                    Toast.makeText(this, "Refreshed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun load() {
        val v = ArrayList<Video>()
        contentResolver.query(
            Media.EXTERNAL_CONTENT_URI,
            arrayOf(Media._ID, Media.DISPLAY_NAME, Media.DURATION, Media.BUCKET_DISPLAY_NAME, Media.SIZE, Media.DATA, Media.DATE_ADDED, Media.WIDTH, Media.HEIGHT),
            null, null, Media.DATE_ADDED + " DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                v += Video(
                    id, ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id).toString(),
                    c.getString(1) ?: "Video", c.getLong(2), c.getString(3) ?: "Other",
                    c.getLong(4), c.getString(5) ?: "", c.getLong(6), c.getInt(7), c.getInt(8)
                )
            }
        }
        all = v
        folders = v.groupBy { it.folder }.map { Folder(it.key, it.value) }.sortedWith(Comparator { a, b -> natCmp(a.name, b.name) })
        sel.retainAll(v.map { it.uri }.toSet())
        if (sel.isEmpty()) selecting = false
        render()
    }

    // favourites = pin: har folder me upar, aur home par "Favourites" folder
    private fun favs(): Set<String> = prefs.getStringSet("fav", emptySet()) ?: emptySet()
    private fun setFavs(s: Set<String>) = prefs.edit().putStringSet("fav", HashSet(s)).apply()

    private fun shownFolders(): List<Folder> {
        val f = favs()
        val fv = all.filter { it.uri in f }
        val h = hid()
        val sorted = sortFolders(folders)
        return (if (fv.isEmpty()) emptyList() else listOf(Folder(FAV, fv))) + sorted.filter { showHid || it.name !in h }
    }

    // hidden folders: long-press folder -> Hide / Unhide
    private fun hid(): Set<String> = prefs.getStringSet("hid", emptySet()) ?: emptySet()
    private fun hiddenCount(): Int = folders.count { it.name in hid() }

    private fun dpx(x: Int) = (x * resources.displayMetrics.density).toInt()

    /** Home filter chips: Folders | All videos | Favourites. Only shown on the home level (not inside a normal folder / search). */
    private fun renderChips() {
        val bar = findViewById<View>(R.id.chipBar)
        val box = findViewById<android.widget.LinearLayout>(R.id.chips)
        val home = query.isEmpty() && !selecting && (openName == null || openName == ALLV || openName == FAV || openName == TREE)
        bar.visibility = if (home) View.VISIBLE else View.GONE
        if (!home) return
        box.removeAllViews()
        val cur = when (openName) { ALLV -> 1; FAV -> 2; TREE -> -1; else -> 0 }
        listOf("Folders", "All videos", "Favourites").forEachIndexed { i, n ->
            box.addView(TextView(this).apply {
                text = n; textSize = 14f; typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = android.view.Gravity.CENTER
                setTextColor(if (i == cur) blue else attr(R.attr.appText2))
                setBackgroundResource(if (i == cur) R.drawable.chip_accent_bg else R.drawable.chip_soft_bg)
                setPadding(dpx(16), dpx(8), dpx(16), dpx(8))
                layoutParams = android.widget.LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dpx(8) }
                setOnClickListener {
                    when (i) {
                        0 -> openName = null
                        1 -> openName = ALLV
                        else -> if (shownFolders().any { it.name == FAV }) openName = FAV
                            else { Toast.makeText(this@MainActivity, "No favourites yet. Long-press a video, then More > Favourite.", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                    }
                    render()
                }
            })
        }
    }

    private fun render() { renderBody(); renderChips() }

    private fun renderBody() {
        updateBars()
        if (query.isNotEmpty()) {
            val h = hid()
            val sf = searchFolder
            val base = if (sf != null) all.filter { it.folder == sf } else all
            showVideos(Folder("Search", base.filter { it.name.contains(query, true) && (showHid || it.folder !in h) }), true)
            return
        }
        if (openName == ALLV) {
            val h = hid()
            showVideos(Folder("All videos", all.filter { showHid || it.folder !in h }), false)
            return
        }
        if (openName == TREE) { showTree(); return }
        val f = shownFolders().find { it.name == openName }
        if (f == null) { openName = null; showFolders() } else showVideos(f, false)
    }

    // ---------- folders screen ----------
    private fun showFolders() {
        setupGrid()
        statCache.clear()
        folderBar.visibility = View.GONE
        titleTv.text = brand()
        homeBack.visibility = View.GONE
        sortBtn.text = Lib.sortLabel(this)
        sortBtn.visibility = View.VISIBLE
        curVids = emptyList()
        computeLast()
        val fl = shownFolders() + (if (hiddenCount() > 0) listOf(Folder(HIDROW, emptyList())) else emptyList())
        list.adapter = object : ArrayAdapter<Folder>(this, if (grid()) R.layout.item_folder_grid else R.layout.item_folder, R.id.t1, fl) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                val f = getItem(i)!!
                val isLast = lastVideo?.folder == f.name
                if (f.name == HIDROW) {
                    view.findViewById<TextView>(R.id.t1).apply {
                        text = if (showHid) "Hide hidden folders" else "Hidden folders (" + hiddenCount() + ")"
                        setTextColor(grey)
                    }
                    view.findViewById<TextView>(R.id.t2).text = "Tap to " + (if (showHid) "hide" else "show")
                    view.findViewById<View>(R.id.last).visibility = View.GONE
                    view.findViewById<ImageView>(R.id.cover).apply { tag = null; setImageDrawable(null) }
                    return view
                }
                val isHidden = f.name in hid()
                view.findViewById<TextView>(R.id.t1).apply {
                    Lib.applyTitle(this, this@MainActivity, grid())
                    text = f.name
                    setTextColor(if (isLast) blue else if (isHidden) grey else txt)
                }
                view.findViewById<TextView>(R.id.t2).text =
                    f.videos.size.toString() + (if (f.videos.size == 1) " video" else " videos") +
                        VideoInfo.size(f.videos.sumOf { it.size }).let { z -> if (z.isEmpty()) "" else "  \u00B7  " + z } +
                        watchedInfo(f) +
                        (if (isHidden) "  \u00B7  hidden" else "")
                val cv = view.findViewById<ImageView>(R.id.cover)
                val first = f.videos.firstOrNull()
                if (first != null) thumb(first, cv) else { cv.tag = null; cv.setImageDrawable(null) }
                bindLastChip(view.findViewById(R.id.last), isLast)
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ ->
            if (fl[i].name == HIDROW) { showHid = !showHid; render() } else { openName = fl[i].name; render() }
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val f = fl[i]
            if (f.name != FAV && f.name != HIDROW) {
                val isHidden = f.name in hid()
                AlertDialog.Builder(this, DLG).setTitle(f.name)
                    .setItems(arrayOf(if (isHidden) "Unhide folder" else "Hide folder")) { _, _ ->
                        val n = HashSet(hid())
                        if (isHidden) n.remove(f.name) else n.add(f.name)
                        prefs.edit().putStringSet("hid", n).apply()
                        render()
                    }.show()
            }
            true
        }
        showRecent()
    }

    private fun showRecent() {
        val byUri = HashMap<String, Video>()
        all.forEach { byUri[it.uri] = it }
        val items = History.recent(this, 20)
            .filter { it.dur > 0 && !History.finished(it) }
            .mapNotNull { e -> byUri[e.uri]?.let { e to it } }
            .filter { showHid || it.second.folder !in hid() }
            .take(8)

        val sig = items.joinToString(";") { it.first.uri + "@" + (it.first.pos / 1000) }
        recentBox.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        if (sig == recentSig && recent.childCount == items.size) return
        recentSig = sig
        recent.removeAllViews()
        for ((e, v) in items) {
            val card = layoutInflater.inflate(R.layout.item_recent, recent, false)
            card.findViewById<TextView>(R.id.t1).text = v.name
            card.findViewById<TextView>(R.id.t2).text = fmt(e.dur - e.pos) + " left"
            card.findViewById<ProgressBar>(R.id.bar).progress = (e.pos * 1000 / e.dur).toInt()
            thumb(v, card.findViewById(R.id.img))
            card.setOnClickListener {
                val f = folders.firstOrNull { it.name == v.folder }
                val l = if (f != null) ordered(f) else listOf(v)
                play(l, l.indexOf(v).coerceAtLeast(0))
            }
            recent.addView(card)
        }
        recentBox.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- videos inside a folder (select mode yahin) ----------
    private fun showVideos(f: Folder, search: Boolean) {
        setupGrid()
        titleTv.text = if (search) "Search (" + f.videos.size + ")" else f.name
        homeBack.visibility = View.VISIBLE
        recentBox.visibility = View.GONE
        val vids = ordered(f)
        curVids = vids
        bindFolderBar(vids, !search)
        sortBtn.text = Lib.sortLabel(this)
        sortBtn.visibility = View.VISIBLE
        computeLast()
        val fv = favs()
        list.adapter = object : ArrayAdapter<Video>(this, if (grid()) R.layout.item_video_grid else R.layout.item_video, R.id.t1, vids) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val view = super.getView(i, v, p)
                bindVideo(view, getItem(i)!!, fv)
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ -> if (selecting) toggleSel(vids[i]) else play(vids, i) }
        list.setOnItemLongClickListener { _, _, i, _ -> selecting = true; toggleSel(vids[i]); true }
    }

    private fun ordered(f: Folder): List<Video> {
        val base = sortVideos(f.videos)
        val fv = favs()
        return base.filter { it.uri in fv } + base.filter { it.uri !in fv }
    }

    private fun play(videos: List<Video>, i: Int) {
        val q = videos.drop(i).take(100)
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra("uris", q.map { it.uri }.toTypedArray())
                .putExtra("names", q.map { it.name }.toTypedArray())
                .putExtra("folder", q[0].folder)
        )
    }

    private fun fmt(ms: Long) = VideoInfo.dur(ms)

    // ---------- grid view + theme menu ----------
    private fun grid() = prefs.getBoolean("grid", false)

    private fun setupGrid() {
        val g = grid()
        list.numColumns = if (g) (resources.configuration.screenWidthDp / 170).coerceIn(2, 5) else 1
        val pad = if (g) (10 * resources.displayMetrics.density).toInt() else 0
        list.setPadding(pad, list.paddingTop, pad, list.paddingBottom)
    }

    private fun openMenu() {
        val items = arrayOf("Settings", "Open network stream (URL)")
        AlertDialog.Builder(this, DLG).setItems(items) { _, w ->
            when (w) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                else -> urlDialog()
            }
        }.show()
    }

    /** Network link: mp4 / mkv / m3u8 / mpd / rtsp, or a web page that has a video inside. Clipboard me link ho to pehle se bhar deta hai. */
    private fun urlDialog() {
        val clip = try {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).primaryClip
                ?.getItemAt(0)?.text?.toString()?.trim()?.takeIf { it.startsWith("http", true) || it.startsWith("rtsp", true) }
        } catch (e: Exception) { null }
        val d = resources.displayMetrics.density
        val et = EditText(this).apply {
            hint = "https://...  (video, stream or page link)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            if (clip != null) { setText(clip); setSelection(clip.length) }
        }
        val ref = EditText(this).apply {
            hint = "Referer (optional, if the site needs it)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val pad = (20 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0)
            addView(et); addView(ref)
        }
        AlertDialog.Builder(this, DLG).setTitle("Open network stream").setView(box)
            .setPositiveButton("Play") { _, _ -> openUrl(et.text.toString().trim(), ref.text.toString().trim().ifEmpty { null }, 0) }
            .setNegativeButton("Cancel", null).show()
    }

    /** Checks the link first (type, redirects, video inside a page) and then starts the player. depth limits page -> page hops. */
    private fun openUrl(u: String, referer: String?, depth: Int) {
        if (!(u.startsWith("http://", true) || u.startsWith("https://", true) || u.startsWith("rtsp://", true))) {
            Toast.makeText(this, "Link must start with http://, https:// or rtsp://", Toast.LENGTH_LONG).show()
            return
        }
        if (u.startsWith("rtsp://", true)) { launchNet(u, "", referer); return }
        Toast.makeText(this, "Checking link…", Toast.LENGTH_SHORT).show()
        Thread {
            val r = NetProbe.probe(u, referer)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (r.mime != NetProbe.HTML) { launchNet(r.url, r.mime ?: "", referer); return@runOnUiThread }
                val c = r.candidates
                when {
                    c.isEmpty() || depth >= 2 -> AlertDialog.Builder(this, DLG).setTitle("No video found on this page")
                        .setMessage("This link opens a web page and no direct video address was found in it. " +
                            "Some sites (YouTube, Instagram and similar) keep their streams hidden, so they cannot be opened from the page link. " +
                            "Paste the direct video link (mp4, mkv, m3u8, mpd) instead.")
                        .setPositiveButton("OK", null).show()
                    c.size == 1 -> openUrl(c[0], r.url, depth + 1)
                    else -> AlertDialog.Builder(this, DLG).setTitle("Videos found on this page")
                        .setItems(c.map { Uri.parse(it).lastPathSegment?.takeIf { s -> s.isNotBlank() } ?: it }.toTypedArray()) { _, w ->
                            openUrl(c[w], r.url, depth + 1)
                        }.setNegativeButton("Cancel", null).show()
                }
            }
        }.start()
    }

    private fun launchNet(u: String, mime: String, referer: String?) {
        val nm = Uri.parse(u).lastPathSegment?.takeIf { it.isNotBlank() } ?: u
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("uris", arrayOf(u)).putExtra("names", arrayOf(nm)).putExtra("folder", "Network")
            .putExtra("mimes", arrayOf(mime)).putExtra("referer", referer ?: ""))
    }

    /** Share > NextGen Play from any app: pick the first link out of the shared text and play it. */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val m = Regex("""(?i)\b(?:https?|rtsp)://[^\s]+""").find(t) ?: run {
            Toast.makeText(this, "No link found in the shared text", Toast.LENGTH_LONG).show(); return
        }
        i.action = null                                   // do not run again on rotation
        openUrl(m.value.trimEnd('.', ',', ')', ']'), null, 0)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    // ---------- library menu (view mode / layout / sort / fields) ----------
    private fun openLibMenu() {
        val before = Lib.vmode(this)
        LibraryMenu.show(this, DLG, txt, attr(R.attr.appText2), blue, grid()) {
            shownVmode = Lib.vmode(this)
            if (Lib.vmode(this) != before) {
                openName = when (Lib.vmode(this)) { 1 -> ALLV; 2 -> TREE; else -> null }
                treeDir = null
            }
            clearSel()
            render()
        }
    }

    private fun statusRank(e: Entry?): Int = when {
        e == null || e.dur <= 0 -> 1
        History.finished(e) -> 2
        else -> 0
    }

    private fun histMap(): Map<String, Entry> {
        val m = HashMap<String, Entry>()
        History.recent(this, Int.MAX_VALUE).forEach { m[it.uri] = it }
        return m
    }

    private fun sortVideos(vs: List<Video>): List<Video> {
        val key = Lib.vsort(this)
        val h: Map<String, Entry> = if (key == 2 || key == 3) histMap() else emptyMap()
        if (key == 8) ensureFps(vs)
        val byName = Comparator<Video> { a, b -> natCmp(a.name, b.name) }
        val cmp: Comparator<Video> = when (key) {
            1 -> compareBy<Video> { it.added }.thenComparing(byName)
            2 -> compareBy<Video> { h[it.uri]?.time ?: 0L }.thenComparing(byName)
            3 -> compareBy<Video> { statusRank(h[it.uri]) }.thenComparing(byName)
            4 -> compareBy<Video> { it.dur }.thenComparing(byName)
            5 -> compareBy<Video> { it.size }.thenComparing(byName)
            6 -> compareBy<Video> { it.w.toLong() * it.h }.thenComparing(byName)
            7 -> Comparator<Video> { a, b -> natCmp(a.path, b.path) }
            8 -> compareBy<Video> { fpsMap[it.uri] ?: 0f }.thenComparing(byName)
            9 -> compareBy<Video> { it.ext }.thenComparing(byName)
            else -> byName
        }
        val sorted = vs.sortedWith(cmp)
        return if (Lib.vdesc(this)) sorted.reversed() else sorted
    }

    private fun sortFolders(fs: List<Folder>): List<Folder> {
        val key = Lib.vsort(this)
        val h: Map<String, Entry> = if (key == 2) histMap() else emptyMap()
        val cmp: Comparator<Folder> = when (key) {
            1 -> compareBy<Folder> { x -> x.videos.maxOfOrNull { it.added } ?: 0L }
            2 -> compareBy<Folder> { x -> x.videos.maxOfOrNull { h[it.uri]?.time ?: 0L } ?: 0L }
            4 -> compareBy<Folder> { x -> x.videos.sumOf { it.dur } }
            5 -> compareBy<Folder> { x -> x.videos.sumOf { it.size } }
            else -> Comparator<Folder> { a, b -> natCmp(a.name.substringAfterLast('/'), b.name.substringAfterLast('/')) }
        }
        val sorted = fs.sortedWith(cmp)
        return if (Lib.vdesc(this)) sorted.reversed() else sorted
    }

    // ---- frame rate (MediaStore me nahi hota: background me nikal ke cache) ----
    private val fpsRun = Runnable {
        if (!isDestroyed) {
            if (Lib.vsort(this) == 8 && fpsPending.isEmpty()) render()
            else (list.adapter as? BaseAdapter)?.notifyDataSetChanged()
        }
    }

    private fun computeFps(u: Uri): Float {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(this, u, null)
            var r = -1f
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") != true) continue
                if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                    r = try { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                        catch (e: Exception) { try { f.getFloat(MediaFormat.KEY_FRAME_RATE) } catch (e2: Exception) { -1f } }
                }
                break
            }
            r
        } catch (e: Exception) { -1f } finally { try { ex.release() } catch (e: Exception) { } }
    }

    private fun ensureFps(vs: List<Video>) {
        for (v in vs) {
            if (fpsMap.containsKey(v.uri) || !fpsPending.add(v.uri)) continue
            try {
                pool.execute {
                    val f = computeFps(Uri.parse(v.uri))
                    runOnUiThread {
                        fpsPending.remove(v.uri)
                        fpsMap[v.uri] = f
                        getSharedPreferences("fpsc", MODE_PRIVATE).edit().putFloat(v.uri, f).apply()
                        liveHandler.removeCallbacks(fpsRun); liveHandler.postDelayed(fpsRun, 400)
                    }
                }
            } catch (e: Exception) { fpsPending.remove(v.uri) }
        }
    }

    private fun fpsLabel(f: Float) = String.format(java.util.Locale.US, "%.3f", f).trimEnd('0').trimEnd('.') + " fps"

    /** Folder card: "5/12 watched  ·  2 new" (render ke time ek baar nikal ke cache). */
    private fun watchedInfo(f: Folder): String = statCache.getOrPut(f.name) {
        if (f.videos.isEmpty()) return@getOrPut ""
        val now = System.currentTimeMillis() / 1000
        val newSecs = AppSettings.NEW_DAYS.get(this) * 86400L
        var w = 0; var fresh = 0
        for (v in f.videos) {
            val e = History.get(this, v.uri)
            if (e != null && History.finished(e)) w++
            else if (e == null && v.added > 0 && now - v.added < newSecs) fresh++
        }
        (if (w > 0) "  \u00B7  " + w + "/" + f.videos.size + " watched" else "") +
            (if (fresh > 0) "  \u00B7  " + fresh + " new" else "")
    }

    /** Folder khulne par upar bar: videos / size / watched / new + Resume + Play all. */
    private fun bindFolderBar(vids: List<Video>, show: Boolean) {
        if (!show || vids.isEmpty()) { folderBar.visibility = View.GONE; return }
        folderBar.visibility = View.VISIBLE
        val now = System.currentTimeMillis() / 1000
        val newSecs = AppSettings.NEW_DAYS.get(this) * 86400L
        var watched = 0; var fresh = 0
        var resume: Pair<Video, Entry>? = null
        for (v in vids) {
            val e = History.get(this, v.uri)
            if (e != null && History.finished(e)) watched++
            else if (e == null && v.added > 0 && now - v.added < newSecs) fresh++
            if (e != null && e.dur > 0 && !History.finished(e) && (resume == null || e.time > resume.second.time)) resume = v to e
        }
        val parts = ArrayList<String>()
        parts.add(vids.size.toString() + (if (vids.size == 1) " video" else " videos"))
        VideoInfo.size(vids.sumOf { it.size }).let { if (it.isNotEmpty()) parts.add(it) }
        if (watched > 0) parts.add("$watched watched")
        if (fresh > 0) parts.add("$fresh new")
        folderInfo.text = parts.joinToString("  \u00B7  ")
        val r = resume
        btnResume.visibility = if (r != null) View.VISIBLE else View.GONE
        btnResume.setOnClickListener { if (r != null) play(vids, vids.indexOf(r.first).coerceAtLeast(0)) }
        btnPlayAll.setOnClickListener { play(vids, 0) }
    }

    // ---- ek video row / card (list + grid + tree) ----
    private fun bindVideo(view: View, x: Video, fv: Set<String>) {
        val e = History.get(this, x.uri)
        val done = e != null && History.finished(e)
        val t3 = view.findViewById<TextView>(R.id.t3)
        val bar = view.findViewById<ProgressBar>(R.id.bar)
        view.findViewById<View>(R.id.card).isActivated = x.uri in sel
        val showThumb = Lib.field(this, "fld_thumb")
        val showLen = Lib.field(this, "fld_len")
        view.findViewById<View>(R.id.thumbBox).visibility = if (showThumb) View.VISIBLE else View.GONE
        val compact = Lib.density(this) == 1
        view.findViewById<View>(R.id.thumbBox).let { tb ->
            val lp = tb.layoutParams
            val wantH = dpx(if (grid()) (if (compact) 78 else 108) else (if (compact) 50 else 68))
            val wantW = if (grid()) lp.width else dpx(if (compact) 88 else 116)
            if (lp.height != wantH || lp.width != wantW) { lp.height = wantH; lp.width = wantW; tb.layoutParams = lp }
        }
        view.findViewById<View>(R.id.card).let { c ->
            val pd = dpx(if (compact) 5 else 8)
            if (c.paddingTop != pd) c.setPadding(pd, pd, pd, pd)
        }
        val base = x.name.substringBeforeLast('.', x.name)
        val extPart = x.name.substring(base.length)
        val shown = if (Lib.field(this, "fld_clean")) Lib.cleanName(base) else base
        val nm = if (Lib.field(this, "fld_ext")) shown + extPart else shown
        view.findViewById<TextView>(R.id.t1).apply {
            Lib.applyTitle(this, this@MainActivity, grid())
            text = (if (x.uri in fv) "\u2605 " else "") + nm
            setTextColor(if (x.uri == lastEntry?.uri) blue else if (done) grey else txt)
        }
        view.findViewById<TextView>(R.id.dur).apply {
            text = fmt(x.dur)
            visibility = if (showLen && showThumb) View.VISIBLE else View.GONE
        }
        val info = ArrayList<String>()
        if (showLen && !showThumb) info.add(fmt(x.dur))
        if (Lib.field(this, "fld_size")) VideoInfo.size(x.size).let { if (it.isNotEmpty()) info.add(it) }
        if (Lib.field(this, "fld_res") && x.w > 0 && x.h > 0) info.add(x.w.toString() + "x" + x.h)
        if (Lib.field(this, "fld_fps")) {
            val f = fpsMap[x.uri]
            if (f == null) ensureFps(listOf(x)) else if (f > 0) info.add(fpsLabel(f))
        }
        if (Lib.field(this, "fld_played") && e != null && e.dur > 0) info.add("Played " + fmt(e.pos))
        if (Lib.field(this, "fld_date") && x.added > 0) info.add(DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(x.added * 1000)))
        if (Lib.field(this, "fld_path")) x.path.substringBeforeLast('/', "").let { if (it.isNotEmpty()) info.add(it) }
        view.findViewById<TextView>(R.id.t2).apply {
            text = info.joinToString("  \u00B7  ")
            visibility = if (info.isEmpty()) View.GONE else View.VISIBLE
        }
        if (e != null && e.dur > 0) {
            bar.visibility = View.VISIBLE
            bar.progress = if (done) 1000 else (e.pos * 1000 / e.dur).toInt()
            t3.visibility = View.VISIBLE
            t3.text = if (done) "Watched" else "Resume " + fmt(e.pos)
            t3.setTextColor(if (done) grey else blue)
        } else {
            bar.visibility = View.GONE
            if (x.added > 0 && System.currentTimeMillis() / 1000 - x.added < AppSettings.NEW_DAYS.get(this) * 86400L) {
                t3.visibility = View.VISIBLE; t3.text = "NEW"; t3.setTextColor(blue)
            } else t3.visibility = View.GONE
        }
        if (showThumb) thumb(x, view.findViewById(R.id.img))
    }

    /** Folder card ka chip: sirf latest dekhi video ke folder par ("Resume mm:ss" ya "Last played"). */
    private fun bindLastChip(chip: TextView, isLast: Boolean) {
        chip.visibility = if (isLast) View.VISIBLE else View.GONE
        val le = lastEntry
        chip.text = if (isLast && le != null && le.dur > 0 && !History.finished(le)) "\u25B6 Resume " + fmt(le.pos) else "Last played"
    }

    // ---------- "Folders" view mode: asli folder tree (path wise) ----------
    private fun dirOf(v: Video): String = v.path.substringBeforeLast('/', "")

    private fun treeRoot(): String {
        val dirs = all.map { dirOf(it) }.filter { it.isNotEmpty() }.distinct()
        if (dirs.isEmpty()) return ""
        var common = dirs[0].split('/')
        for (d in dirs) {
            val p = d.split('/')
            var n = 0
            while (n < common.size && n < p.size && common[n] == p[n]) n++
            common = common.subList(0, n)
        }
        val cp = common.joinToString("/")
        val base = Regex("^/storage/[^/]+(/\\d+)?").find(cp)?.value
        return if (base != null && cp.length > base.length) base else cp
    }

    private fun treeUp() {
        val cur = treeDir ?: return
        val root = treeRoot()
        val par = cur.substringBeforeLast('/', "")
        treeDir = if (par == root || par.length < root.length) null else par
        render()
    }

    private fun showTree() {
        setupGrid()
        statCache.clear()
        folderBar.visibility = View.GONE
        val root = treeRoot()
        var cur = treeDir ?: root
        if (!(cur == root || cur.startsWith("$root/"))) cur = root
        treeDir = if (cur == root) null else cur
        val h = hid()
        val here = ArrayList<Video>()
        val sub = LinkedHashMap<String, MutableList<Video>>()
        for (v in all) {
            val d = dirOf(v)
            if (d == cur) { here.add(v); continue }
            if (!d.startsWith("$cur/")) continue
            val child = cur + "/" + d.substring(cur.length + 1).substringBefore('/')
            sub.getOrPut(child) { ArrayList() }.add(v)
        }
        val dirs = sortFolders(sub.map { Folder(it.key, it.value) }.filter { showHid || it.name.substringAfterLast('/') !in h })
        val vids = ordered(Folder(cur, here))
        val items = ArrayList<Any>()
        items.addAll(dirs); items.addAll(vids)
        curVids = vids
        computeLast()
        titleTv.text = if (cur == root) "Folders" else cur.substringAfterLast('/')
        homeBack.visibility = if (treeDir != null || Lib.vmode(this) != 2) View.VISIBLE else View.GONE
        recentBox.visibility = View.GONE
        sortBtn.text = Lib.sortLabel(this)
        sortBtn.visibility = View.VISIBLE
        val fv = favs()
        list.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(i: Int): Any = items[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getViewTypeCount() = 2
            override fun getItemViewType(i: Int) = if (items[i] is Folder) 0 else 1
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val x = items[i]
                if (x is Folder) {
                    val view = v ?: layoutInflater.inflate(if (grid()) R.layout.item_folder_grid else R.layout.item_folder, p, false)
                    val lv = lastVideo
                    val isLast = lv != null && (dirOf(lv) == x.name || dirOf(lv).startsWith(x.name + "/"))
                    view.findViewById<TextView>(R.id.t1).apply { Lib.applyTitle(this, this@MainActivity, grid()); text = x.name.substringAfterLast('/'); setTextColor(if (isLast) blue else txt) }
                    view.findViewById<TextView>(R.id.t2).text =
                        x.videos.size.toString() + (if (x.videos.size == 1) " video" else " videos") +
                            VideoInfo.size(x.videos.sumOf { it.size }).let { z -> if (z.isEmpty()) "" else "  \u00B7  " + z } +
                            watchedInfo(x)
                    val cv = view.findViewById<ImageView>(R.id.cover)
                    val first = x.videos.firstOrNull()
                    if (first != null) thumb(first, cv) else { cv.tag = null; cv.setImageDrawable(null) }
                    bindLastChip(view.findViewById(R.id.last), isLast)
                    return view
                }
                val view = v ?: layoutInflater.inflate(if (grid()) R.layout.item_video_grid else R.layout.item_video, p, false)
                bindVideo(view, x as Video, fv)
                return view
            }
        }
        list.setOnItemClickListener { _, _, i, _ ->
            val x = items[i]
            if (x is Folder) { treeDir = x.name; render() }
            else if (selecting) toggleSel(x as Video)
            else play(vids, vids.indexOf(x as Video).coerceAtLeast(0))
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val x = items[i]
            if (x is Video) { selecting = true; toggleSel(x) }
            true
        }
    }

    // ---------- multiselect ----------
    private fun selVideos(): List<Video> = all.filter { it.uri in sel }

    private fun toggleSel(v: Video) {
        if (!sel.add(v.uri)) sel.remove(v.uri)
        if (sel.isEmpty()) selecting = false
        refreshSel()
    }

    private fun clearSel() { sel.clear(); selecting = false; refreshSel() }

    private fun refreshSel() { updateBars(); renderChips(); (list.adapter as? BaseAdapter)?.notifyDataSetChanged() }

    private fun updateBars() {
        selBar.visibility = if (selecting) View.VISIBLE else View.GONE
        header.visibility = if (selecting) View.GONE else View.VISIBLE
        // 1 video select ho to bar me poora naam dikhao (tap = properties: naam + full path), warna "N selected"
        val one = if (sel.size == 1) all.firstOrNull { it.uri in sel } else null
        if (one != null) {
            selCount.text = one.name
            selCount.textSize = 14f; selCount.maxLines = 3; selCount.ellipsize = android.text.TextUtils.TruncateAt.END
        } else {
            selCount.text = sel.size.toString() + " selected"
            selCount.textSize = 17f; selCount.maxLines = 1
        }
    }

    private fun moreMenu() {
        val vs = selVideos()
        if (vs.isEmpty()) return
        val fv = favs()
        val allFav = vs.all { it.uri in fv }
        val names = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(t: String, f: () -> Unit) { names += t; acts += f }
        add("Video properties") { showInfo(vs) }
        if (vs.size == 1) add("Rename") { renameDialog(vs[0]) }
        add(if (allFav) "Remove from favourites" else "Add to favourites (pin)") {
            val ids = vs.map { it.uri }.toSet()
            setFavs(if (allFav) fv - ids else fv + ids); clearSel(); render()
        }
        add("Mark as watched") {
            vs.forEach { if (it.dur > 0) History.save(this, it.uri, it.dur, it.dur, it.folder, it.name) }
            clearSel(); render()
        }
        add("Reset progress") { vs.forEach { History.remove(this, it.uri) }; clearSel(); render() }
        AlertDialog.Builder(this, DLG).setItems(names.toTypedArray()) { _, i -> acts[i]() }.show()
    }

    private fun showInfo(vs: List<Video>) {
        pool.execute {
            val text = if (vs.size == 1) VideoInfo.describe(this, Uri.parse(vs[0].uri)) else VideoInfo.summary(vs)
            runOnUiThread {
                AlertDialog.Builder(this, DLG).setTitle("Video properties").setMessage(text)
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    // ---------- permission helper (Android 9 aur neeche write permission) ----------
    private fun needsWritePerm() = Build.VERSION.SDK_INT <= 28 &&
        checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED

    private fun withWrite(next: () -> Unit) {
        if (needsWritePerm()) { afterPerm = next; requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2) }
        else next()
    }

    // ---------- delete / rename: apna dialog; Android 11+ par "All files access" ho to system prompt nahi ----------
    /**
     * API 30+: permission ho to direct() chalao; nahi hai aur kabhi poochha nahi to ek baar poochho;
     * "Not now" / na mile / API 29 aur neeche to fallback() (purana flow).
     */
    private fun allFilesFlow(direct: () -> Unit, fallback: () -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { fallback(); return }
        if (AllFiles.granted()) { direct(); return }
        if (AllFiles.asked(this)) { fallback(); return }
        AppDialogs.askAllFiles(this,
            onAllow = {
                AllFiles.markAsked(this)
                afterGrant = { if (AllFiles.granted()) direct() else fallback() }
                AllFiles.open(this, REQ_ALL)
            },
            onNotNow = { AllFiles.markAsked(this); fallback() },
            onDismiss = { fallback() })
    }

    private fun deleteSelected() {
        val vs = selVideos()
        if (vs.isEmpty()) return
        AppDialogs.confirmDelete(this, vs, cache.get(vs[0].uri)) { startDelete(vs) }
    }

    private fun startDelete(vs: List<Video>) {
        pendingDel = vs.map { it.uri }
        allFilesFlow(
            direct = { deleteDirect(vs) },
            fallback = { if (Build.VERSION.SDK_INT >= 30) systemDelete(vs) else withWrite { deleteLegacy() } })
    }

    /** Android 11+ ka system confirm (createDeleteRequest). */
    private fun systemDelete(vs: List<Video>) {
        pendingDel = vs.map { it.uri }
        try {
            val pi = MediaStore.createDeleteRequest(contentResolver, vs.map { Uri.parse(it.uri) })
            startIntentSenderForResult(pi.intentSender, REQ_DEL, null, 0, 0, 0)
        } catch (e: Exception) { Toast.makeText(this, "Could not delete", Toast.LENGTH_SHORT).show() }
    }

    /** All files access ke saath: file hatao + MediaStore row hatao. Jo na hate unke liye system confirm. */
    private fun deleteDirect(vs: List<Video>) {
        val failed = ArrayList<Video>()
        var n = 0
        for (v in vs) {
            var fileGone = false
            try {
                if (v.path.isNotEmpty()) { val f = File(v.path); fileGone = if (f.exists()) f.delete() else true }
            } catch (e: Exception) { }
            var rowGone = false
            try { rowGone = contentResolver.delete(Uri.parse(v.uri), null, null) > 0 } catch (e: Exception) { }
            if (fileGone || rowGone) {
                onDeleted(v.uri); n++
                if (fileGone && v.path.isNotEmpty()) {
                    try { MediaScannerConnection.scanFile(this, arrayOf(v.path), null, null) } catch (e: Exception) { }
                }
            } else failed.add(v)
        }
        if (failed.isEmpty()) finishDelete(n)
        else {
            if (n > 0) Toast.makeText(this, "$n video(s) deleted", Toast.LENGTH_SHORT).show()
            systemDelete(failed)
        }
    }

    private fun onDeleted(uri: String) {
        History.remove(this, uri)
        setFavs(favs() - uri)
        cache.remove(uri)
    }

    private fun deleteLegacy() {
        val left = ArrayList(pendingDel)
        var n = 0
        while (left.isNotEmpty()) {
            val u = left.first()
            try {
                contentResolver.delete(Uri.parse(u), null, null)
                onDeleted(u); left.removeAt(0); n++
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    pendingDel = ArrayList(left)
                    try {
                        startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_DEL29, null, 0, 0, 0)
                    } catch (e2: Exception) { }
                    return
                }
                left.removeAt(0)
            }
        }
        finishDelete(n)
    }

    private fun finishDelete(n: Int) {
        Toast.makeText(this, "$n video(s) deleted", Toast.LENGTH_SHORT).show()
        clearSel(); load()
    }

    // ---------- rename ----------
    private fun renameDialog(v: Video) {
        val dot = v.name.lastIndexOf('.')
        val base = if (dot > 0) v.name.substring(0, dot) else v.name
        val extn = if (dot > 0) v.name.substring(dot) else ""
        val et = EditText(this).apply { setText(base); setTextColor(txt); setSelection(text.length); setSingleLine() }
        AlertDialog.Builder(this, DLG).setTitle("Rename").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (n.isNotEmpty() && n != base) startRename(v, n + extn)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun startRename(v: Video, newName: String) {
        pendingRename = v to newName
        renameViaPrompt = false
        if (Build.VERSION.SDK_INT >= 30) allFilesFlow(direct = { doRename() }, fallback = { renamePrompt(v) })
        else withWrite { doRename() }
    }

    /** Android 11+ ka system "write" confirm. */
    private fun renamePrompt(v: Video) {
        renameViaPrompt = true
        try {
            val pi = MediaStore.createWriteRequest(contentResolver, listOf(Uri.parse(v.uri)))
            startIntentSenderForResult(pi.intentSender, REQ_REN, null, 0, 0, 0)
        } catch (e: Exception) { Toast.makeText(this, "Could not rename", Toast.LENGTH_SHORT).show() }
    }

    @Suppress("DEPRECATION")
    private fun doRename() {
        val (v, n) = pendingRename ?: return
        val uri = Uri.parse(v.uri)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                contentResolver.update(uri, ContentValues().apply { put(Media.DISPLAY_NAME, n) }, null, null)
            } else {
                val old = File(v.path)
                val nw = File(old.parentFile, n)
                if (!old.renameTo(nw)) throw IllegalStateException("rename failed")
                contentResolver.update(uri, ContentValues().apply {
                    put(Media.DISPLAY_NAME, n); put(Media.DATA, nw.absolutePath)
                }, null, null)
            }
            pendingRename = null
            Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
            clearSel(); load()
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try { startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_REN29, null, 0, 0, 0) } catch (e2: Exception) { }
            } else if (Build.VERSION.SDK_INT >= 30 && !renameViaPrompt) renamePrompt(v)
            else Toast.makeText(this, "Could not rename (permission denied)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not rename", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        when (r) {
            REQ_DEL -> if (res == RESULT_OK) { pendingDel.forEach { onDeleted(it) }; finishDelete(pendingDel.size) }
            REQ_DEL29 -> if (res == RESULT_OK) deleteLegacy()
            REQ_REN, REQ_REN29 -> if (res == RESULT_OK) doRename()
            REQ_ALL -> { val f = afterGrant; afterGrant = null; f?.invoke() }
        }
    }

    // ---------- thumbnails ----------
    @Suppress("DEPRECATION")
    private fun thumb(v: Video, iv: ImageView) {
        iv.tag = v.uri
        val hit = cache.get(v.uri)
        iv.setImageBitmap(hit)
        if (hit != null) return
        pool.execute {
            val bm = try {
                if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(Uri.parse(v.uri), Size(256, 160), null)
                else Thumbnails.getThumbnail(contentResolver, v.id, Thumbnails.MINI_KIND, null)
            } catch (e: Exception) { null }
            if (bm != null) {
                cache.put(v.uri, bm)
                runOnUiThread { if (iv.tag == v.uri) iv.setImageBitmap(bm) }
            }
        }
    }
}

/** Natural sort: "Ep 2" < "Ep 10" (1,2,3,...,10), na ki 1,10,2. */
fun natCmp(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        if (a[i].isDigit() && b[j].isDigit()) {
            val si = i
            val sj = j
            while (i < a.length && a[i].isDigit()) i++
            while (j < b.length && b[j].isDigit()) j++
            val x = a.substring(si, i).trimStart('0')
            val y = b.substring(sj, j).trimStart('0')
            if (x.length != y.length) return x.length - y.length
            val c = x.compareTo(y)
            if (c != 0) return c
        } else {
            val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}
