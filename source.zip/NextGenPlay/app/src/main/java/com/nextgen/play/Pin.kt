package com.nextgen.play

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.security.MessageDigest
import java.util.UUID

/** Private vault ka PIN (4 se 8 digit). Salt + SHA-256, apni alag prefs file me (settings export me nahi jaati). */
object Pin {
    private fun sp(c: Context) = c.getSharedPreferences("vault_pin", Context.MODE_PRIVATE)

    fun has(c: Context): Boolean = sp(c).contains("h")

    private fun hash(salt: String, pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var d = (salt + pin).toByteArray()
        repeat(2000) { d = md.digest(d) }
        return d.joinToString("") { b -> "%02x".format(b) }
    }

    fun set(c: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        sp(c).edit().putString("s", salt).putString("h", hash(salt, pin)).remove("fails").remove("until").apply()
    }

    fun verify(c: Context, pin: String): Boolean {
        val s = sp(c).getString("s", null) ?: return false
        val h = sp(c).getString("h", null) ?: return false
        return hash(s, pin) == h
    }

    fun clear(c: Context) { sp(c).edit().clear().apply() }

    private fun dp(a: Activity, x: Int) = AppDialogs.dp(a, x)

    private fun field(a: Activity, tc: Int, hint: String): EditText = EditText(a).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(InputFilter.LengthFilter(8))
        this.hint = hint
        setHintTextColor(0xFF6B6B7A.toInt())
        setTextColor(tc)
        textSize = 22f
        gravity = Gravity.CENTER
        imeOptions = EditorInfo.IME_ACTION_DONE
        setPadding(0, dp(a, 12), 0, dp(a, 12))
    }

    private fun box(a: Activity): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(a, 22), dp(a, 20), dp(a, 22), dp(a, 16))
    }

    /** PIN poochho. Sahi ho to onOk; Cancel / back par onCancel. forgot != null ho to "Forgot PIN?" dikhta hai. */
    fun ask(a: Activity, title: String, forgot: (() -> Unit)?, onOk: () -> Unit, onCancel: () -> Unit) {
        val tc = AppDialogs.col(a, R.attr.appText, Color.WHITE)
        val tc2 = AppDialogs.col(a, R.attr.appText2, 0xFFBBBBCC.toInt())
        val acc = AppDialogs.col(a, R.attr.appAccent, 0xFF5088E0.toInt())
        val line = (tc2 and 0xFFFFFF) or 0x55000000
        val b = box(a)
        b.addView(TextView(a).apply { text = title; setTextColor(tc); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })
        b.addView(TextView(a).apply { text = "Enter your PIN"; setTextColor(tc2); textSize = 14f; setPadding(0, dp(a, 6), 0, dp(a, 8)) })
        val et = field(a, tc, "PIN")
        b.addView(et)
        val err = TextView(a).apply { setTextColor(0xFFE5484D.toInt()); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(a, 6), 0, dp(a, 6)) }
        b.addView(err)
        var done = false
        lateinit var dlg: AlertDialog
        fun attempt() {
            val now = System.currentTimeMillis()
            val until = sp(a).getLong("until", 0L)
            if (now < until) { err.text = "Too many attempts. Try again in " + ((until - now) / 1000 + 1) + " s"; return }
            if (verify(a, et.text.toString())) {
                done = true
                sp(a).edit().remove("fails").remove("until").apply()
                dlg.dismiss(); onOk()
            } else {
                val f = sp(a).getInt("fails", 0) + 1
                if (f >= 5) {
                    sp(a).edit().putInt("fails", 0).putLong("until", now + 30_000L).apply()
                    err.text = "Too many attempts. Try again in 30 s"
                } else {
                    sp(a).edit().putInt("fails", f).apply()
                    err.text = "Wrong PIN"
                }
                et.setText("")
            }
        }
        et.setOnEditorActionListener { _, _, _ -> attempt(); true }
        if (forgot != null) {
            b.addView(TextView(a).apply {
                text = "Forgot PIN?"; setTextColor(acc); textSize = 13f; gravity = Gravity.CENTER
                setPadding(0, dp(a, 4), 0, dp(a, 12))
                setOnClickListener { done = true; dlg.dismiss(); forgot() }
            })
        }
        val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        btns.addView(AppDialogs.pill(a, "Cancel", null, tc, line) { dlg.dismiss() })
        btns.addView(AppDialogs.pill(a, "Unlock", acc, Color.WHITE, acc) { attempt() }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(a, 10) }
        })
        b.addView(btns)
        dlg = AppDialogs.show(a, b, 360)
        dlg.setCanceledOnTouchOutside(false)
        dlg.setOnDismissListener { if (!done) onCancel() }
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        et.requestFocus()
    }

    /** Naya PIN banao (do baar likhna). */
    fun setup(a: Activity, onDone: () -> Unit, onCancel: () -> Unit = {}) {
        val tc = AppDialogs.col(a, R.attr.appText, Color.WHITE)
        val tc2 = AppDialogs.col(a, R.attr.appText2, 0xFFBBBBCC.toInt())
        val acc = AppDialogs.col(a, R.attr.appAccent, 0xFF5088E0.toInt())
        val line = (tc2 and 0xFFFFFF) or 0x55000000
        val b = box(a)
        b.addView(TextView(a).apply { text = "Set a vault PIN"; setTextColor(tc); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })
        b.addView(TextView(a).apply {
            text = "4 to 8 digits. If you forget it, you can reset it with your phone's screen lock."
            setTextColor(tc2); textSize = 13.5f; setPadding(0, dp(a, 6), 0, dp(a, 8))
        })
        val p1 = field(a, tc, "New PIN")
        val p2 = field(a, tc, "Repeat PIN")
        b.addView(p1); b.addView(p2)
        val err = TextView(a).apply { setTextColor(0xFFE5484D.toInt()); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(a, 6), 0, dp(a, 12)) }
        b.addView(err)
        var done = false
        lateinit var dlg: AlertDialog
        fun save() {
            val x = p1.text.toString()
            when {
                x.length < 4 -> err.text = "Use at least 4 digits"
                x != p2.text.toString() -> err.text = "PINs do not match"
                else -> { set(a, x); done = true; dlg.dismiss(); onDone() }
            }
        }
        p2.setOnEditorActionListener { _, _, _ -> save(); true }
        val btns = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        btns.addView(AppDialogs.pill(a, "Cancel", null, tc, line) { dlg.dismiss() })
        btns.addView(AppDialogs.pill(a, "Save", acc, Color.WHITE, acc) { save() }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(a, 10) }
        })
        b.addView(btns)
        dlg = AppDialogs.show(a, b, 360)
        dlg.setCanceledOnTouchOutside(false)
        dlg.setOnDismissListener { if (!done) onCancel() }
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        p1.requestFocus()
    }
}
