package com.nextgen.play

import android.app.Activity
import android.app.Application
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.startapp.sdk.ads.banner.BannerFormat
import com.startapp.sdk.ads.banner.BannerRequest
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener

/**
 * Start.io placement for NextGen Play:
 * - 2 banners on the library screen (home + folders): one at the top, one at the bottom.
 * - 1 full-screen video ad every 3 hours, shown only on the library screen (never during playback).
 * - No rewarded / ad-free system.
 */
object Ads {
    private const val PREFS = "ngp_ads_state"
    private const val KEY_LAST_VIDEO = "last_video_ad_ms"
    private const val OLD_KEY_EXPIRY = "adfree_expiry_ms"      // purana ad-free reward; init me hata diya jata hai
    private const val HOUR_MS = 60 * 60 * 1000L
    private const val VIDEO_GAP_MS = 3 * HOUR_MS
    private const val RETRY_GAP_MS = 60 * 1000L                // load fail hone par dobara try karne se pehle ka gap

    @Volatile private var ready = false
    private var app: Application? = null

    private class Slot { var view: View? = null; var loading = false }
    private val topSlot = Slot()
    private val bottomSlot = Slot()

    private var libraryVisible = false
    private var videoBusy = false
    private var lastVideoAttempt = 0L

    fun init(a: Application) {
        app = a
        try {
            a.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(OLD_KEY_EXPIRY).apply()
        } catch (_: Throwable) { }
        try {
            StartAppSDK.setTestAdsEnabled(BuildConfig.STARTIO_TEST || BuildConfig.DEBUG)
            StartAppSDK.initParams(a, BuildConfig.STARTIO_APP_ID)
                .setReturnAdsEnabled(false)
                .setCallback { ready = true }
                .init()
        } catch (_: Throwable) { ready = false }
    }

    // ---------- Banners: MainActivity ke upar (adBarTop) aur neeche (adBar) ----------
    fun attachBanners(act: Activity) {
        act.findViewById<ViewGroup>(R.id.adBarTop)?.let { attach(act, it, topSlot) }
        act.findViewById<ViewGroup>(R.id.adBar)?.let { attach(act, it, bottomSlot) }
    }

    private fun place(bar: ViewGroup, view: View) {
        try {
            (view.parent as? ViewGroup)?.removeView(view)
            bar.removeAllViews()
            bar.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ))
            bar.visibility = View.VISIBLE
        } catch (_: Throwable) { }
    }

    private fun alive(act: Activity) = !act.isFinishing && !act.isDestroyed

    private fun attach(act: Activity, bar: ViewGroup, slot: Slot) {
        val existing = slot.view
        if (existing != null) { place(bar, existing); return }
        val a = app ?: return
        if (!ready) {
            bar.postDelayed({ if (alive(act)) attach(act, bar, slot) }, 1800L)
            return
        }
        if (slot.loading) return
        slot.loading = true
        try {
            BannerRequest(a).setAdFormat(BannerFormat.BANNER).load { creator, _ ->
                slot.loading = false
                if (creator == null) return@load
                try {
                    val view = creator.create(a, null)
                    slot.view = view
                    act.runOnUiThread { if (alive(act)) place(bar, view) }
                } catch (_: Throwable) { }
            }
        } catch (_: Throwable) { slot.loading = false }
    }

    // ---------- Full video ad: har 3 ghante me 1, sirf library screen par ----------
    fun onLibraryResumed(act: Activity) {
        libraryVisible = true
        attachBanners(act)
        maybeShowVideo(act)
    }

    fun onLibraryPaused() { libraryVisible = false }

    private fun maybeShowVideo(act: Activity) {
        if (!ready || videoBusy || !alive(act)) return
        val prefs = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(KEY_LAST_VIDEO, 0L)
        // Pehli baar (ya phone ki clock peeche gayi): timer abhi se shuru, ad turant nahi.
        if (last == 0L || last > now) { prefs.edit().putLong(KEY_LAST_VIDEO, now).apply(); return }
        if (now - last < VIDEO_GAP_MS) return
        if (now - lastVideoAttempt < RETRY_GAP_MS) return
        lastVideoAttempt = now
        videoBusy = true
        try {
            val ad = StartAppAd(act)
            ad.loadAd(StartAppAd.AdMode.VIDEO, object : AdEventListener {
                override fun onReceiveAd(a: Ad) {
                    // Ad load hone tak user player me chala gaya ho to nahi dikhana; agle resume par dobara try hoga.
                    if (!alive(act) || !libraryVisible) { videoBusy = false; return }
                    try {
                        ad.showAd(object : AdDisplayListener {
                            override fun adDisplayed(a: Ad?) {
                                prefs.edit().putLong(KEY_LAST_VIDEO, System.currentTimeMillis()).apply()
                            }
                            override fun adClicked(a: Ad?) { }
                            override fun adHidden(a: Ad?) { videoBusy = false }
                            override fun adNotDisplayed(a: Ad?) { videoBusy = false }
                        })
                    } catch (_: Throwable) { videoBusy = false }
                }
                override fun onFailedToReceiveAd(a: Ad?) { videoBusy = false }
            })
        } catch (_: Throwable) { videoBusy = false }
    }
}
