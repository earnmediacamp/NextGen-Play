package com.nextgen.play

import android.app.Activity
import android.app.Application
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import com.startapp.sdk.ads.banner.BannerFormat
import com.startapp.sdk.ads.banner.BannerRequest
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener

/**
 * Start.io placement for NextGen Play:
 * - 1 banner, sirf library screen ke neeche (upar wala hata diya: header buttons ke paas galat click hote the).
 * - 1 full-screen video ad, har 40 minute me max 1, sirf jab user player se library par wapas aaye (natural break).
 * - Rewarded video: user khud dekhta hai -> poora ad-free (banner + full-screen band).
 *     1 video = 6 ghante, 2 videos = 12 ghante, 4 videos = 24 ghante. Adhura progress 30 minute saved rehta hai.
 * - Player ke andar kabhi ad nahi.
 */
object Ads {
    private const val PREFS = "ngp_ads_state"
    private const val KEY_LAST_VIDEO = "last_video_ad_ms"
    private const val KEY_UNTIL = "adfree_until_ms"          // ad-free kab tak (trusted time)
    private const val KEY_MAXSEEN = "adfree_maxseen_ms"      // ab tak dekha sabse bada clock (clock peeche karne se time na badhe)
    private const val KEY_DONE = "rw_done"                   // adhure package me kitne videos dekh liye
    private const val KEY_DONE_AT = "rw_done_at"
    private const val HOUR_MS = 60 * 60 * 1000L
    private const val VIDEO_GAP_MS = 40 * 60 * 1000L      // 40 minute (30-45 ke beech)
    private const val RETRY_GAP_MS = 60 * 1000L
    private const val PROGRESS_KEEP_MS = 30 * 60 * 1000L
    private const val MAX_ADFREE_MS = 48 * HOUR_MS           // zyada stack nahi hoga
    private const val BANNER_REFRESH_MS = 60 * 1000L         // banner har 60 sec me naya ad le (pehle ek hi ad atka rehta tha)

    // Unity Ads (primary: rewarded + full-screen; banner: Start.io ke saath alternate)
    private const val UNITY_GAME_ID = "800400880"
    private const val PL_REWARDED = "BP_Rewarded_Android"
    private const val PL_INTERSTITIAL = "BP_Interstitial_Android"
    private const val PL_BANNER = "BP_Banner_Android"
    private const val UNITY_LOAD_TIMEOUT_MS = 8000L          // itne me Unity ka ad na aaye to Start.io par

    /** (videos, hours) */
    private val PACKS = listOf(1 to 6, 2 to 12, 4 to 24)

    @Volatile private var ready = false
    private var app: Application? = null

    private class Slot { var view: View? = null; var loading = false; var loadedAt = 0L; var scheduled = false; var unityTurn = false; var owner: Activity? = null }
    @Volatile private var unityReady = false
    private val main = Handler(Looper.getMainLooper())
    private val bottomSlot = Slot()

    private var libraryVisible = false
    private var videoBusy = false
    private var rewardBusy = false
    private var lastVideoAttempt = 0L
    @Volatile private var playerSeen = false                 // player abhi band hua -> library par ek natural break

    fun init(a: Application) {
        app = a
        try {
            StartAppSDK.setTestAdsEnabled(BuildConfig.STARTIO_TEST || BuildConfig.DEBUG)
            StartAppSDK.initParams(a, BuildConfig.STARTIO_APP_ID)
                .setReturnAdsEnabled(false)
                .setCallback { ready = true }
                .init()
        } catch (_: Throwable) { ready = false }
        try {
            UnityAds.initialize(a, UNITY_GAME_ID, BuildConfig.DEBUG, object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() { unityReady = true }
                override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) { unityReady = false }
            })
        } catch (_: Throwable) { unityReady = false }
    }

    // ---------- Ad-free state ----------
    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Phone ki clock peeche kar do to bhi time wapas nahi aata: hamesha ab tak ka sabse bada time. */
    private fun trustedNow(c: Context): Long {
        val p = sp(c)
        val wall = System.currentTimeMillis()
        val seen = p.getLong(KEY_MAXSEEN, 0L)
        if (wall > seen) { p.edit().putLong(KEY_MAXSEEN, wall).apply(); return wall }
        return seen
    }

    fun adFreeLeftMs(c: Context): Long = maxOf(0L, sp(c).getLong(KEY_UNTIL, 0L) - trustedNow(c))
    fun isAdFree(c: Context): Boolean = adFreeLeftMs(c) > 0L

    private fun grant(c: Context, hours: Int) {
        val now = trustedNow(c)
        val base = maxOf(sp(c).getLong(KEY_UNTIL, 0L), now)
        val until = minOf(base + hours * HOUR_MS, now + MAX_ADFREE_MS)
        sp(c).edit().putLong(KEY_UNTIL, until).putInt(KEY_DONE, 0).putLong(KEY_DONE_AT, 0L).apply()
        Stats.log("adfree_granted", "hours" to hours)
    }

    private fun doneCount(c: Context): Int {
        val p = sp(c)
        val n = p.getInt(KEY_DONE, 0)
        if (n <= 0) return 0
        return if (trustedNow(c) - p.getLong(KEY_DONE_AT, 0L) > PROGRESS_KEEP_MS) {
            p.edit().putInt(KEY_DONE, 0).apply(); 0
        } else n
    }

    private fun fmt(ms: Long): String {
        val m = (ms / 60000L).toInt()
        val h = m / 60
        return if (h >= 1) "${h}h ${m % 60}m" else "${maxOf(1, m)}m"
    }

    /** Header ke neeche wali pill ka text. */
    fun pillText(c: Context): String =
        if (isAdFree(c)) "Ad-free  \u00B7  ${fmt(adFreeLeftMs(c))} left  \u00B7  Add more"
        else "\u25B6  Watch a video  \u00B7  Ad-free up to 24 hours"

    // ---------- Banner: sirf neeche (adBar) ----------
    fun attachBanners(act: Activity) {
        val bar = act.findViewById<ViewGroup>(R.id.adBar) ?: return
        if (isAdFree(act)) { bar.visibility = View.GONE; return }
        attach(act, bar, bottomSlot)
    }

    private fun place(bar: ViewGroup, view: View) {
        try {
            (view.parent as? ViewGroup)?.removeView(view)
            bar.removeAllViews()
            bar.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ))
            bar.visibility = View.VISIBLE
        } catch (_: Throwable) { }
    }

    private fun alive(act: Activity) = !act.isFinishing && !act.isDestroyed

    private fun attach(act: Activity, bar: ViewGroup, slot: Slot) {
        var existing = slot.view
        if (existing is BannerView && slot.owner !== act) {      // purani activity ka Unity banner: naye par nahi lagta
            try { existing.destroy() } catch (_: Throwable) { }
            slot.view = null; existing = null
        }
        if (existing != null) place(bar, existing)
        val a = app ?: return
        if (!ready && !unityReady) {
            bar.postDelayed({ if (alive(act) && !isAdFree(act)) attach(act, bar, slot) }, 1800L)
            return
        }
        val stale = existing == null || System.currentTimeMillis() - slot.loadedAt >= BANNER_REFRESH_MS
        if (stale) loadBanner(act, bar, slot, a)
        scheduleRefresh(act, bar, slot)
    }

    /** Naya banner mangao: har baar baari-baari Start.io / Unity. Jo fail ho, turant dusra. */
    private fun loadBanner(act: Activity, bar: ViewGroup, slot: Slot, a: Application) {
        if (slot.loading) return
        slot.loading = true
        val done = { slot.loading = false }
        val unityFirst = unityReady && (slot.unityTurn || !ready)
        slot.unityTurn = !slot.unityTurn
        if (unityFirst) {
            loadUnityBanner(act, bar, slot) { if (ready) loadStartBanner(act, bar, slot, a, done) else done() }
        } else {
            loadStartBanner(act, bar, slot, a) { if (unityReady) loadUnityBanner(act, bar, slot, done) else done() }
        }
    }

    private fun swapIn(act: Activity, bar: ViewGroup, slot: Slot, view: View) {
        val old = slot.view
        slot.view = view
        slot.owner = act
        slot.loadedAt = System.currentTimeMillis()
        place(bar, view)
        if (old is BannerView && old !== view) { try { old.destroy() } catch (_: Throwable) { } }
    }

    private fun loadStartBanner(act: Activity, bar: ViewGroup, slot: Slot, a: Application, onFail: () -> Unit) {
        try {
            BannerRequest(a).setAdFormat(BannerFormat.BANNER).load { creator, _ ->
                if (creator == null) { act.runOnUiThread(onFail); return@load }
                try {
                    val view = creator.create(a, null)
                    act.runOnUiThread {
                        slot.loading = false
                        if (alive(act) && !isAdFree(act)) swapIn(act, bar, slot, view)
                    }
                } catch (_: Throwable) { act.runOnUiThread(onFail) }
            }
        } catch (_: Throwable) { onFail() }
    }

    private fun loadUnityBanner(act: Activity, bar: ViewGroup, slot: Slot, onFail: () -> Unit) {
        try {
            val bv = BannerView(act, PL_BANNER, UnityBannerSize(320, 50))
            bv.setListener(object : BannerView.Listener() {
                override fun onBannerLoaded(view: BannerView?) {
                    slot.loading = false
                    if (view != null && alive(act) && !isAdFree(act)) swapIn(act, bar, slot, view)
                }
                override fun onBannerFailedToLoad(view: BannerView?, errorInfo: BannerErrorInfo?) {
                    try { view?.destroy() } catch (_: Throwable) { }
                    act.runOnUiThread(onFail)
                }
            })
            bv.load()
        } catch (_: Throwable) { onFail() }
    }

    private fun scheduleRefresh(act: Activity, bar: ViewGroup, slot: Slot) {
        if (slot.scheduled) return
        slot.scheduled = true
        bar.postDelayed({
            slot.scheduled = false
            if (alive(act) && libraryVisible && !isAdFree(act)) attach(act, bar, slot)
        }, BANNER_REFRESH_MS)
    }

    // ---------- Full video ad: sirf player se library wapas aane par, 40 minute me max 1 ----------
    /** PlayerActivity.onPause se: user ne video dekha, ab library par aayega. */
    fun onPlayerLeft() { playerSeen = true }

    fun onLibraryResumed(act: Activity) {
        libraryVisible = true
        attachBanners(act)
        val comingFromPlayer = playerSeen
        playerSeen = false
        if (comingFromPlayer) maybeShowVideo(act)
    }

    fun onLibraryPaused() { libraryVisible = false }

    /**
     * Unity ka full-screen / rewarded ad: load -> show. finish(shown, completed):
     * shown=false  -> Unity se ad nahi chala (load fail / timeout / show fail), fallback karo.
     * shown=true   -> ad chala; completed = poora dekha (rewarded ke liye).
     */
    private fun unityRun(act: Activity, placement: String, canShow: () -> Boolean, onShown: () -> Unit, finish: (Boolean, Boolean) -> Unit) {
        if (!unityReady) { finish(false, false); return }
        val settled = AtomicBoolean(false)
        var started = false
        val timeout = Runnable { if (settled.compareAndSet(false, true)) finish(false, false) }
        main.postDelayed(timeout, UNITY_LOAD_TIMEOUT_MS)
        try {
            UnityAds.load(placement, object : IUnityAdsLoadListener {
                override fun onUnityAdsAdLoaded(placementId: String?) {
                    if (!settled.compareAndSet(false, true)) return
                    main.removeCallbacks(timeout)
                    if (!canShow()) { finish(false, false); return }
                    try {
                        UnityAds.show(act, placement, UnityAdsShowOptions(), object : IUnityAdsShowListener {
                            override fun onUnityAdsShowFailure(placementId: String?, error: UnityAds.UnityAdsShowError?, message: String?) {
                                if (started) finish(true, false) else finish(false, false)
                            }
                            override fun onUnityAdsShowStart(placementId: String?) { started = true; onShown() }
                            override fun onUnityAdsShowClick(placementId: String?) { }
                            override fun onUnityAdsShowComplete(placementId: String?, state: UnityAds.UnityAdsShowCompletionState?) {
                                finish(true, state == UnityAds.UnityAdsShowCompletionState.COMPLETED)
                            }
                        })
                    } catch (_: Throwable) { finish(false, false) }
                }
                override fun onUnityAdsFailedToLoad(placementId: String?, error: UnityAds.UnityAdsLoadError?, message: String?) {
                    if (settled.compareAndSet(false, true)) { main.removeCallbacks(timeout); finish(false, false) }
                }
            })
        } catch (_: Throwable) {
            if (settled.compareAndSet(false, true)) { main.removeCallbacks(timeout); finish(false, false) }
        }
    }

    private fun maybeShowVideo(act: Activity) {
        if ((!ready && !unityReady) || videoBusy || rewardBusy || !alive(act) || isAdFree(act)) return
        val prefs = sp(act)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(KEY_LAST_VIDEO, 0L)
        // Pehli baar (ya phone ki clock peeche gayi): timer abhi se shuru, ad turant nahi.
        if (last == 0L || last > now) { prefs.edit().putLong(KEY_LAST_VIDEO, now).apply(); return }
        if (now - last < VIDEO_GAP_MS) return
        if (now - lastVideoAttempt < RETRY_GAP_MS) return
        lastVideoAttempt = now
        videoBusy = true
        // Unity pehle; na aaye to Start.io
        unityRun(act, PL_INTERSTITIAL, { alive(act) && libraryVisible && !isAdFree(act) },
            { prefs.edit().putLong(KEY_LAST_VIDEO, System.currentTimeMillis()).apply() }) { shown, _ ->
            if (shown) videoBusy = false
            else if (ready && alive(act) && libraryVisible && !isAdFree(act)) startVideo(act, prefs)
            else videoBusy = false
        }
    }

    private fun startVideo(act: Activity, prefs: android.content.SharedPreferences) {
        try {
            val ad = StartAppAd(act)
            ad.loadAd(StartAppAd.AdMode.VIDEO, object : AdEventListener {
                override fun onReceiveAd(a: Ad) {
                    if (!alive(act) || !libraryVisible || isAdFree(act)) { videoBusy = false; return }
                    try {
                        ad.showAd(object : AdDisplayListener {
                            override fun adDisplayed(a: Ad?) {
                                prefs.edit().putLong(KEY_LAST_VIDEO, System.currentTimeMillis()).apply()
                            }
                            override fun adClicked(a: Ad?) { }
                            override fun adHidden(a: Ad?) { videoBusy = false }
                            override fun adNotDisplayed(a: Ad?) { videoBusy = false }
                        })
                    } catch (_: Throwable) { videoBusy = false }
                }
                override fun onFailedToReceiveAd(a: Ad?) { videoBusy = false }
            })
        } catch (_: Throwable) { videoBusy = false }
    }

    // ---------- Rewarded video: "Go ad-free" ----------
    /**
     * target = package me kitne videos chahiye (1 / 2 / 4). Ek video poora dekhne par done++,
     * done >= target hote hi ad-free mil jata hai. onChange: UI refresh. onNext: package adhura hai -> dialog dobara kholo.
     */
    private fun watchOne(act: Activity, target: Int, hours: Int, onChange: () -> Unit, onNext: () -> Unit, retry: Boolean = true) {
        if (rewardBusy) return
        if (doneCount(act) >= target) {          // pehle ka progress hi kaafi hai
            grant(act, hours)
            Toast.makeText(act, "Ad-free for $hours hours", Toast.LENGTH_LONG).show()
            onChange(); return
        }
        if (!ready && !unityReady) {
            Toast.makeText(act, "Ads are still loading. Try again in a moment.", Toast.LENGTH_SHORT).show(); return
        }
        rewardBusy = true
        if (retry) Toast.makeText(act, "Loading video\u2026", Toast.LENGTH_SHORT).show()
        // Unity primary; ad na aaye to Start.io fallback
        unityRun(act, PL_REWARDED, { alive(act) }, { }) { shown, completed ->
            if (shown) {
                rewardBusy = false
                act.runOnUiThread {
                    if (completed) rewardComplete(act, target, hours, onChange, onNext)
                    else Toast.makeText(act, "Watch the full video to get the reward", Toast.LENGTH_LONG).show()
                }
            } else if (ready && alive(act)) startRewarded(act, target, hours, onChange, onNext, retry)
            else {
                rewardBusy = false
                act.runOnUiThread { Toast.makeText(act, "No video available right now. Please try again later.", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun rewardComplete(act: Activity, target: Int, hours: Int, onChange: () -> Unit, onNext: () -> Unit) {
        val p = sp(act)
        Stats.log("rewarded_complete", "pack" to target)
        val n = doneCount(act) + 1
        p.edit().putInt(KEY_DONE, n).putLong(KEY_DONE_AT, trustedNow(act)).apply()
        if (n >= target) {
            grant(act, hours)
            Toast.makeText(act, "Done! Ad-free for $hours hours", Toast.LENGTH_LONG).show()
            onChange()
        } else {
            Toast.makeText(act, "$n of $target watched", Toast.LENGTH_SHORT).show()
            onChange(); onNext()
        }
    }

    private fun startRewarded(act: Activity, target: Int, hours: Int, onChange: () -> Unit, onNext: () -> Unit, retry: Boolean) {
        rewardBusy = true
        try {
            val ad = StartAppAd(act)
            var completed = false
            ad.setVideoListener { completed = true }
            ad.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
                override fun onReceiveAd(a: Ad) {
                    if (!alive(act)) { rewardBusy = false; return }
                    try {
                        ad.showAd(object : AdDisplayListener {
                            override fun adDisplayed(a: Ad?) { }
                            override fun adClicked(a: Ad?) { }
                            override fun adHidden(a: Ad?) {
                                rewardBusy = false
                                if (!completed) {            // skip / close: reward nahi
                                    act.runOnUiThread {
                                        Toast.makeText(act, "Watch the full video to get the reward", Toast.LENGTH_LONG).show()
                                    }
                                    return
                                }
                                act.runOnUiThread { rewardComplete(act, target, hours, onChange, onNext) }
                            }
                            override fun adNotDisplayed(a: Ad?) { rewardBusy = false }
                        })
                    } catch (_: Throwable) { rewardBusy = false }
                }
                override fun onFailedToReceiveAd(a: Ad?) {
                    rewardBusy = false
                    val why = try { a?.errorMessage } catch (_: Throwable) { null }
                    Stats.log("rewarded_nofill", "why" to (why ?: "unknown").takeLast(90))
                    if (retry) {                           // pehli request aksar fail hoti hai: ek baar 2 sec baad dobara
                        act.window?.decorView?.postDelayed({
                            if (alive(act)) startRewarded(act, target, hours, onChange, onNext, false)
                        }, 2000L)
                        return
                    }
                    act.runOnUiThread {
                        Toast.makeText(act, "No video available right now. Please try again later.", Toast.LENGTH_LONG).show()
                    }
                }
            })
        } catch (_: Throwable) { rewardBusy = false }
    }

    /** Pill par tap: 3 options wala dialog. */
    fun showAdFreeDialog(act: Activity, onChange: () -> Unit) {
        if (!alive(act)) return
        val dp = { x: Int -> AppDialogs.dp(act, x) }
        val text = AppDialogs.col(act, R.attr.appText, Color.WHITE)
        val text2 = AppDialogs.col(act, R.attr.appText2, Color.GRAY)
        val accent = AppDialogs.col(act, R.attr.appAccent, Color.parseColor("#32A8FF"))
        val soft = AppDialogs.col(act, R.attr.appAccentSoft, Color.parseColor("#3332A8FF"))
        val done = doneCount(act)
        var dlg: android.app.AlertDialog? = null

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
        }
        box.addView(TextView(act).apply {
            this.text = "Go ad-free"; setTextColor(text); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
        })
        val status = when {
            isAdFree(act) -> "Ad-free now \u00B7 ${fmt(adFreeLeftMs(act))} left. Watch more to add time."
            else -> "Watch short videos to remove all banner and video ads for a while."
        }
        box.addView(TextView(act).apply {
            this.text = status; setTextColor(text2); textSize = 13f
            setPadding(0, dp(6), 0, dp(if (done > 0) 6 else 14))
        })
        if (done > 0) box.addView(TextView(act).apply {
            this.text = "Progress saved: $done video${if (done > 1) "s" else ""} watched"
            setTextColor(accent); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(12))
        })

        for ((n, h) in PACKS) {
            val left = maxOf(0, n - done)
            val label = when {
                left == 0 -> "Claim $h hours ad-free"
                left == n -> "Watch $n video${if (n > 1) "s" else ""}  \u2192  $h hours ad-free"
                else -> "Watch $left more  \u2192  $h hours ad-free"
            } + if (n == 4) "  (best value)" else ""
            box.addView(AppDialogs.pill(act, label, soft, accent, accent) {
                dlg?.dismiss()
                watchOne(act, n, h, onChange, onNext = { showAdFreeDialog(act, onChange) })
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        box.addView(TextView(act).apply {
            this.text = "Videos must be watched fully. Ads come back when the time ends."
            setTextColor(text2); textSize = 11f; setPadding(0, dp(4), 0, dp(10))
        })
        box.addView(AppDialogs.pill(act, "Not now", null, text2, text2) { dlg?.dismiss() },
            LinearLayout.LayoutParams(-1, -2))
        dlg = AppDialogs.show(act, box)
    }
}
