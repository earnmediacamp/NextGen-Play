package com.nextgen.play

import android.app.Activity
import android.app.Application
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import com.startapp.sdk.ads.banner.BannerFormat
import com.startapp.sdk.ads.banner.BannerRequest
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.VideoListener
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener

/**
 * Limited Start.io placement for NextGen Play:
 * - Banner only on the library screen (the same bottom bar is visible on home and inside folders).
 * - No automatic/interstitial ads anywhere.
 * - User-initiated rewarded offers: 1 completed video = 12h Ad-Free; 3 completed videos = 24h Ad-Free.
 * - Rewards extend the current expiry instead of replacing remaining time.
 */
object Ads {
    private const val PREFS = "ngp_ads_state"
    private const val KEY_EXPIRY = "adfree_expiry_ms"
    private const val HOUR_MS = 60 * 60 * 1000L

    @Volatile private var ready = false
    private var app: Application? = null
    private var banner: View? = null
    private var bannerLoading = false

    fun init(a: Application) {
        app = a
        try {
            StartAppSDK.setTestAdsEnabled(BuildConfig.STARTIO_TEST || BuildConfig.DEBUG)
            StartAppSDK.initParams(a, BuildConfig.STARTIO_APP_ID)
                .setReturnAdsEnabled(false)
                .setCallback { ready = true }
                .init()
        } catch (_: Throwable) { ready = false }
    }

    fun isAdFree(activity: Activity): Boolean = isAdFree(activity as android.content.Context)
    fun isAdFree(context: android.content.Context): Boolean =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .getLong(KEY_EXPIRY, 0L) > System.currentTimeMillis()

    fun remainingAdFreeMs(context: android.content.Context): Long =
        (context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .getLong(KEY_EXPIRY, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    private fun grantAdFree(context: android.content.Context, hours: Int) {
        val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val oldExpiry = prefs.getLong(KEY_EXPIRY, 0L)
        val base = maxOf(now, oldExpiry)
        prefs.edit().putLong(KEY_EXPIRY, base + hours * HOUR_MS).apply()
    }

    // ---------- Banner: only MainActivity's bottom adBar ----------
    fun attachBanner(act: Activity, bar: ViewGroup) {
        if (isAdFree(act)) {
            bar.visibility = View.GONE
            return
        }
        val existing = banner
        if (existing != null) {
            try {
                (existing.parent as? ViewGroup)?.removeView(existing)
                bar.removeAllViews()
                bar.addView(existing, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.Gravity.CENTER
                ))
                bar.visibility = View.VISIBLE
            } catch (_: Throwable) { }
            return
        }
        val a = app ?: return
        if (!ready) {
            bar.postDelayed({ if (!act.isFinishing && !act.isDestroyed) attachBanner(act, bar) }, 1800L)
            return
        }
        if (bannerLoading) return
        bannerLoading = true
        try {
            BannerRequest(a).setAdFormat(BannerFormat.BANNER).load { creator, _ ->
                bannerLoading = false
                if (creator == null || act.isFinishing || act.isDestroyed || isAdFree(act)) return@load
                try {
                    val view = creator.create(a, null)
                    banner = view
                    act.runOnUiThread {
                        if (act.isFinishing || act.isDestroyed || isAdFree(act)) return@runOnUiThread
                        try {
                            (view.parent as? ViewGroup)?.removeView(view)
                            bar.removeAllViews()
                            bar.addView(view, FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                android.view.Gravity.CENTER
                            ))
                            bar.visibility = View.VISIBLE
                        } catch (_: Throwable) { }
                    }
                } catch (_: Throwable) { }
            }
        } catch (_: Throwable) { bannerLoading = false }
    }

    /** Kept as a no-op for the existing PlayerActivity call; automatic interstitials are intentionally disabled. */
    fun playerClosed() = Unit

    /** Called when MainActivity resumes. Only syncs the banner; never shows a full-screen ad automatically. */
    fun onLibraryResumed(act: Activity) {
        val bar = act.findViewById<ViewGroup>(R.id.adBar) ?: return
        attachBanner(act, bar)
    }

    /**
     * Explicit user opt-in flow. Only fully completed rewarded videos count.
     * If a load/show fails, no reward is granted. For the 3-ad offer, all three must complete.
     */
    fun requestAdFree(activity: Activity, adCount: Int, hours: Int, onResult: (Boolean) -> Unit) {
        if (adCount !in listOf(1, 3) || hours !in listOf(12, 24)) {
            onResult(false); return
        }
        if (!ready) {
            Toast.makeText(activity, "Ads are not ready yet. Please try again.", Toast.LENGTH_LONG).show()
            onResult(false); return
        }
        var completed = 0
        var finished = false
        fun end(success: Boolean) {
            if (finished) return
            finished = true
            if (success) {
                grantAdFree(activity, hours)
                val bar = activity.findViewById<ViewGroup>(R.id.adBar)
                bar?.visibility = View.GONE
            }
            onResult(success)
        }
        lateinit var showNext: () -> Unit
        showNext = next@{
            if (activity.isFinishing || activity.isDestroyed) { end(false); return@next }
            if (completed >= adCount) { end(true); return@next }
            val rewarded = try { StartAppAd(activity) } catch (_: Throwable) { end(false); return@next }
            try {
                rewarded.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
                    override fun onReceiveAd(ad: Ad) {
                        if (activity.isFinishing || activity.isDestroyed) { end(false); return }
                        var videoCompleted = false
                        var handled = false
                        fun afterAd(success: Boolean) {
                            if (handled) return
                            handled = true
                            activity.runOnUiThread {
                                if (!success) { end(false); return@runOnUiThread }
                                completed++
                                if (completed >= adCount) end(true) else showNext()
                            }
                        }
                        try {
                            rewarded.setVideoListener(object : VideoListener {
                                override fun onVideoCompleted() { videoCompleted = true }
                            })
                            rewarded.showAd(object : AdDisplayListener {
                                override fun adDisplayed(ad: Ad?) { }
                                override fun adClicked(ad: Ad?) { }
                                override fun adHidden(ad: Ad?) { afterAd(videoCompleted) }
                                override fun adNotDisplayed(ad: Ad?) { afterAd(false) }
                            })
                        } catch (_: Throwable) { afterAd(false) }
                    }
                    override fun onFailedToReceiveAd(ad: Ad?) { end(false) }
                })
            } catch (_: Throwable) { end(false) }
        }
        showNext()
    }
}
