package com.nextgen.play

import android.app.Activity
import android.app.Application
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.startapp.sdk.ads.banner.BannerFormat
import com.startapp.sdk.ads.banner.BannerRequest
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener

/**
 * Start.io ads. Rules (player ka kaam na bigde):
 *  - Banner sirf library screen (MainActivity) ke neeche. Player me koi ad nahi.
 *  - Interstitial sirf tab jab user player band karke library par wapas aaye; kam se kam 3 exit + 5 minute ke gap ke baad.
 *  - Har cheez try/catch me: SDK fail ho, ad na mile ya network na ho to app normal chalta hai.
 *  - Return ads / splash ads manifest me band hain.
 */
object Ads {
    private const val MIN_EXITS = 3
    private const val MIN_GAP_MS = 5 * 60_000L
    private const val K_EXITS = "ads_exits"
    private const val K_LAST = "ads_last_ms"

    @Volatile private var ready = false
    private var app: Application? = null
    private var interstitial: StartAppAd? = null
    private var interstitialReady = false
    private var loading = false
    private var showing = false
    private var pendingExit = false
    private var banner: View? = null
    private var bannerLoading = false

    fun init(a: Application) {
        app = a
        try {
            StartAppSDK.setTestAdsEnabled(BuildConfig.STARTIO_TEST || BuildConfig.DEBUG)
            StartAppSDK.initParams(a, BuildConfig.STARTIO_APP_ID)
                .setReturnAdsEnabled(false)
                .setCallback { ready = true; loadInterstitial() }
                .init()
        } catch (t: Throwable) { ready = false }
    }

    // ---------- banner ----------
    fun attachBanner(act: Activity, bar: ViewGroup) {
        val a = app ?: return
        try {
            banner?.let { v -> (v.parent as? ViewGroup)?.removeView(v); bar.addView(v); bar.visibility = View.VISIBLE; return }
            if (bannerLoading) return
            bannerLoading = true
            fun go() {
                BannerRequest(a).setAdFormat(BannerFormat.BANNER).load { creator, _ ->
                    bannerLoading = false
                    if (creator == null || act.isFinishing || act.isDestroyed) return@load
                    try {
                        val v = creator.create(a, null)
                        banner = v
                        bar.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER))
                        bar.visibility = View.VISIBLE
                    } catch (t: Throwable) { }
                }
            }
            if (ready) go() else bar.postDelayed({ if (ready) go() else bannerLoading = false }, 2500)
        } catch (t: Throwable) { bannerLoading = false }
    }

    // ---------- interstitial ----------
    private fun loadInterstitial() {
        val a = app ?: return
        if (loading || interstitialReady) return
        loading = true
        try {
            val ad = StartAppAd(a)
            ad.loadAd(object : AdEventListener {
                override fun onReceiveAd(p0: Ad) { interstitial = ad; interstitialReady = true; loading = false }
                override fun onFailedToReceiveAd(p0: Ad?) { loading = false }
            })
        } catch (t: Throwable) { loading = false }
    }

    /** PlayerActivity.onPause (finishing) se: user ne video band kiya. */
    fun playerClosed() {
        val a = app ?: return
        pendingExit = true
        val sp = AppSettings.sp(a)
        sp.edit().putInt(K_EXITS, sp.getInt(K_EXITS, 0) + 1).apply()
    }

    /** MainActivity.onResume se. Player se aaye hain tabhi; shart poori ho to ad dikhao, warna kuch nahi. */
    fun onLibraryResumed(act: Activity) {
        if (!pendingExit) return
        pendingExit = false
        val a = app ?: return
        val sp = AppSettings.sp(a)
        val now = System.currentTimeMillis()
        if (!ready || showing || act.isFinishing || act.isDestroyed) return
        if (sp.getInt(K_EXITS, 0) < MIN_EXITS || now - sp.getLong(K_LAST, 0L) < MIN_GAP_MS) { loadInterstitial(); return }
        val ad = interstitial
        if (!interstitialReady || ad == null) { loadInterstitial(); return }
        try {
            showing = true
            interstitialReady = false; interstitial = null
            ad.showAd(object : AdDisplayListener {
                override fun adHidden(p0: Ad?) { showing = false; loadInterstitial() }
                override fun adDisplayed(p0: Ad?) { sp.edit().putInt(K_EXITS, 0).putLong(K_LAST, System.currentTimeMillis()).apply() }
                override fun adClicked(p0: Ad?) {}
                override fun adNotDisplayed(p0: Ad?) { showing = false; loadInterstitial() }
            })
        } catch (t: Throwable) { showing = false }
    }
}
