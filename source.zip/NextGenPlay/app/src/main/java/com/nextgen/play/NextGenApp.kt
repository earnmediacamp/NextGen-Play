package com.nextgen.play

import android.app.Application

class NextGenApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Ads.init(this)
    }
}
