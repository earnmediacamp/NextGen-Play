package com.nextgen.play

import android.app.Application

class NextGenApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Stats.init(this)
        Ads.init(this)
    }
}
