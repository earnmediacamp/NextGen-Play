# libass (ass-media / ass-kt): native (JNI) + reflection ke liye
-keep class io.github.peerless2012.ass.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn io.github.peerless2012.**

# FFmpeg audio extension (LGPL): DefaultRenderersFactory reflection se load karta hai, JNI naam se dhoondta hai
-keep class androidx.media3.decoder.ffmpeg.** { *; }
# media3 decoder buffers: native code in fields ko naam se access karta hai
-keep class androidx.media3.decoder.** { *; }
# HLS: DefaultMediaSourceFactory reflection se load karta hai
-keep class androidx.media3.exoplayer.hls.** { *; }

# Start.io: SDK pehle se obfuscated aur apne consumer rules ke saath aata hai; sirf warnings band
-dontwarn com.startapp.**
-keep class com.startapp.** { *; }
