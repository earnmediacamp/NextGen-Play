# NextGen Play (dev notes)

## libass (ASS/SSA) support (v6)
- Player ab libass use karta hai (`io.github.peerless2012:ass-media:0.5.1`). MKV ke andar ke ASS tracks aur bahar se khuli .ass/.ssa dono libass se render hote hain.
- Default mode = CUES: static render, purane subtitle pipeline (delay, ON/OFF, track select) ke saath poora compatible.
- 3-dot menu me naya toggle "Animated ASS (libass)": ON karne par overlay mode (karaoke, moving text, animations). Toggle karte hi player usi position par dobara banta hai (decoder toggle jaisa).
- ASS tracks apne style/font/position use karti hain, isliye Customization (size/colour/font) sirf SRT/VTT par lagta hai.
- Animated mode me embedded ASS par subtitle delay nahi chalta (external file par chalta hai, kyunki file ke timestamps shift hote hain).
- Build changes: Media3 1.4.1 -> 1.8.0, Kotlin 1.9.24 -> 2.2.0, compileSdk 35 (targetSdk 34 hi), proguard-rules.pro naya.

1. Android Studio -> File > Open -> project folder (Gradle sync hone do)
2. Phone connect karo -> Run
3. Release APK: Build > Generate Signed Bundle / APK

## Side panels + left rail + pull to refresh (v4)
- Library: list ko neeche kheench kar refresh karo (nayi / delete files MediaStore me scan hoti hain).
- Player: CC button = right side panel "Subtitle" (Open, Track, Settings > Synchronization / Show subtitles / Customization).
- Player: top-right 3-dot = right side panel with icon grid (Queue, Aspect, Display, Subtitle, Audio, Speed, Playback, Info, Share, Screenshot, PiP, Quit) + toggles (Subtitles, Shortcuts, Auto-play next).
- Player: shortcuts ab LEFT side vertical rail me: Mute, Sleep timer, Audio, Rotate, Lock, PiP (chevron se collapse; 3-dot menu ke "Shortcuts" toggle se poora hide/show).
- Back button pehle side panel band karta hai.

## Light theme + Grid view (v1.4)
- Home screen ke header me naya menu button (teen dots): Theme = Dark / Light / Follow system, aur View = List / Grid.
- Light theme sirf library screen par; player hamesha dark rehta hai (video ke liye behtar).
- Grid view: folders aur videos 2+ columns me cards (screen width ke hisaab se), list view bhi waisa hi rehta hai.

## Player + library upgrades (v1.3)
- Double-tap +-10s instant: fast keyframe seek, taps accumulate (+10, +20, +30), side feedback, aur uske baad single taps bhi skip karte hain.
- Press-and-hold = 2x speed (chhodte hi normal). Brightness/volume ka level bar. Swipe-seek me target time.
- Seekbar drag par thumbnail preview. Har video ki saved speed. A-B repeat. Queue/Playlist list. Subtitle style presets.
- Crash-safe resume (har 10 sec save). Friendly error messages.
- Library: folder sort (Name / Most videos / Newest), folder hide/unhide (long-press), NEW badge, duration badge, size, tez thumbnails.

## Modern UI + auto orientation (latest)
- Auto orientation: vertical video -> portrait, horizontal video -> landscape (har video ke hisab se, next episode par bhi). Rotate button dabane par us video tak manual rehta hai.
- Double-tap play/pause ab symbol (animated) dikhata hai, letters nahi. Transport buttons rounded symbols hain.
- Poora naya look: dark premium theme + violet accent, rounded cards (folders, videos, Continue Watching), gradient player controls, icon buttons (search, share, delete, more), rounded dialogs, naya app icon.

## Naye features
- Subtitle delay / Audio delay: Settings (tune icon) -> Subtitles / Audio -> -1s, -0.1, +0.1, +1s, Reset (MX Player jaisa, har video ka alag, sirf current session me).
  - Audio delay sirf decoded (PCM) audio par chalta hai, passthrough par nahi.
  - External subtitle file: + aur - dono delay. Embedded subtitle (mkv ke andar): sirf + (late) delay.
- Subtitle ON/OFF: right rail ka CC button ya Settings -> Subtitles -> ON/OFF.
- Collapsible: Settings ke sab sections (tap karke khulo/band, yaad rehta hai), player ka right rail (chevron), home par "Continue Watching".

## Library / manage features
- Multiselect: video par long-press -> baaki par tap. Top bar: All, Share, Delete, More, X. (Back = select mode band)
- Delete: Android 11+ par system ka confirm dialog; Android 9 aur neeche write permission maangta hai.
- Share: ek ya kai videos. Player ke Settings -> Video me current video share bhi hota hai.
- Properties: size, duration, resolution, codec, fps, bitrate, audio tracks (More -> Properties, ya player Settings -> Video).
- More menu: Rename, Favourite (pin, upar aata hai + home par "Favourites" folder), Mark as watched, Reset progress.
- Search: header ka Search button, sab videos me naam se dhundhta hai.
- Player: beech me double-tap = play/pause, left/right double-tap = -10s/+10s, Settings -> Playback me auto-play next ON/OFF aur sleep timer, rail me screenshot button (Pictures/NextGenPlay).

## Release + auto-update (sirf mobile se, GitHub Actions)
Repo: github.com/earnmediacamp/NextGen-Play (public hona chahiye)
1. Repo me file banao `.github/workflows/build.yml` (Add file > Create new file, naam me slash likho) aur `build.yml` ka content paste karo.
2. Repo me `source.zip` upload karo (Add file > Upload files). Naya code aaye to isi naam se dobara upload karke replace karo.
3. Repo Settings > Secrets and variables > Actions me 2 secrets: `KS_PASS` aur `KS_B64` (values `github-secrets.txt` me hain).
4. Actions tab > "Build and Release APK" > Run workflow > version (jaise 1.2) aur changelog likho.
5. 3-5 min me Releases me APK + version.json aa jata hai. Phone par APK download karke install karo.
6. Uske baad app me "v1.x" chip ya app khulte hi update khud dikhega.
Purane app se alag id hai (com.nextgen.play): naya app alag install hota hai, purana uninstall kar do. `nextgen-release.jks` + password ka backup rakho.

## Fix: external subtitle select nahi hota tha
- Subtitle file open karne par ab uska track khud select hota hai (pehle mkv ke embedded track ya purane Track-override ki wajah se select nahi hota tha).
- Galat / unreadable subtitle file par ab "Subtitle file samajh nahi aayi" message aata hai.

## Redesign Stage 1 + 2
- Subtitle / Font ab popup (radio list + accent button). Track list me file ka poora naam, corner badge "Sub / Font".
- Fonts: Default + system fonts + `app/src/main/assets/fonts/*.ttf` (koi bhi ttf/otf yahan daalo, list me aa jayegi) + Custom Font.
- Added subtitle har video ke liye save hota hai (dobara add nahi karna padta); panel me "Remove added subtitle".
- Player controls: rounded soft buttons, accent play button, -10s / +10s buttons, rounded side panel + card rows.

## Redesign Stage 3 (library)
- Library pehle se mockup ke style me tha (dark #070B12, accent blue, "NextGen"+"Play" brand). Sirf polish: cards radius 20dp, thumbnails 14dp, badge 8dp, list thumb thoda bada, "Continue Watching" heading bada.

## Batch 4
- Subtitle Position + Opacity (Customization).
- Audio / subtitle language yaad: agle episodes par wahi language apne aap.
- Skip button (rail me "+85s"), length Playback panel me badal sakte ho.

## Night mode, frame step, auto sync, translate, live resume
- Player shortcuts row (title ke neeche): Mute, Sleep, **Night mode**, **Frame back / Frame forward**. Frame buttons: tap = 1 frame, dabaye rakho = lagataar (video pause ho jata hai).
- Night mode: warm (kam blue light) + dim video + dim subtitles. Strength: Display panel > Night mode. Quick settings me bhi toggle.
- Subtitle panel > **Auto sync**: video ki awaaz (speech) se external subtitle ka delay + speed (fps mismatch) apne aap theek. Reset button bhi.
- Subtitle panel > **Translate**: external subtitle poori file translate (SRT/VTT/ASS, yaad rehti hai); embedded text subtitle live translate. Google Translate web endpoint, INTERNET chahiye.
- Library: folder card par resume indicator sirf latest dekhi video ke folder par ("Resume mm:ss"); baaki folders me resume sirf video par. Player save hote hi (pause / 5 sec / back) library real-time update hoti hai.

## Library menu (Phase 1)
- Header ka sort button ab menu kholta hai: **View Mode** (All folders / Files / Folders = asli path tree), **Layout** (List / Grid), **Sort** (Title, Date, Played time, Status, Length, Size, Resolution, Path, Frame rate, Type) + A-Z / Z-A, **Fields** (Thumbnail, Length, File extension, Played time, Resolution, Frame rate, Path, Size, Date). Cancel = kuch nahi badalta, Done = save.
- Frame rate MediaStore me nahi hota: pehli baar background me nikalke cache hota hai (Frame rate field ya sort chunne par).
- Folders me bhi wahi sort lagta hai (Title = naam, Date = newest, Size / Length = total, Played time = last played).
- Purana "View" item 3-dot menu se hata diya (ab Layout isi menu me hai).

## Licence + Start.io ads (v7)
- NextLib (GPL-3.0) hata diya; app ab GPL-bound nahi. FFmpeg audio ke liye LGPL AAR: `tools/build_ffmpeg_lgpl.sh` -> `app/libs/media3-decoder-ffmpeg-lgpl.aar` (na ho to app phone ke decoders se chalta hai).
- Start.io SDK `com.startapp:inapp-sdk:5.2.2` (pinned). App ID: `gradle.properties` me `startioAppId=...` (na ho to demo ID + test ads).
- Ads: 2 banner library/folder screen par (1 upar, 1 neeche). Har 3 ghante me 1 full-screen video ad, sirf library screen par (pehli baar install ke 3 ghante baad se gino). Player ke andar koi ad nahi. Return/splash ads manifest me off.
- Rewarded Ad-Free system hata diya gaya hai.
- Release se pehle: real App ID, test ads band hona, Play Console Data safety + Ads declaration update.
